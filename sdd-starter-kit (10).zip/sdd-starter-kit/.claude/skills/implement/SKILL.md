---
name: implement
description: 承認済みの計画に沿って要求IDを実装し、受入基準ごとに確認方法を報告する。
argument-hint: "[要求ID 例: FR-001]"
disable-model-invocation: true
---
docs/02-spec/ の要求 $ARGUMENTS を実装してください。

手順：
1. 実装計画と、要求IDとの対応表を先に出す（コードはまだ書かない）
2. 私の承認後に実装する
3. `python -m pytest -q` と `python tools/spec_lint.py` を実行する
4. 完了時、受入基準ごとに「確認方法」と「結果」を表で示す
5. 変更したファイルと、差分の要点を一覧にする（私が差分を読む）

禁止：
- 仕様にない機能の追加（「親切な追加」も含む）
- tests/ の既存の期待値の変更・削除・スキップ
- 新しいライブラリの追加（必要なら、実在・ライセンス・理由を示して承認を求める）
