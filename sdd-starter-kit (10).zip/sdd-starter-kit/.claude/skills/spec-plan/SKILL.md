---
name: spec-plan
description: 要求IDの実装計画・対応表・疑問点を出す。コードは書かない。
argument-hint: "[要求ID 例: FR-001]"
disable-model-invocation: true
---
<context>
仕様の正は docs/02-spec/ 配下の .md です。合意事項は docs/01-agreement/ です。
</context>

<task>
$ARGUMENTS を実装する前に、次を出力してください。
1. 実装計画（変更するファイルと手順）
2. 要求ID・受入基準と、実装・テストの対応表
3. 仕様が曖昧・不足している点（未決事項の候補）と、確認すべき質問
4. 影響範囲（既存機能・テスト）とリスク
</task>

<constraints>
- まだコードは書かない。ファイルも変更しない
- 仕様にない機能は追加しない
- 不明点は推測せず、質問として列挙する
</constraints>
