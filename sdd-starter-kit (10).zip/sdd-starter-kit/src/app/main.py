"""研修アンケート要約ツール CLI

使い方：python -m app.main data/sample.csv [--dry-run]
終了コード：0 成功／1 入力エラー／2 要約失敗
"""
from __future__ import annotations

import argparse
import json
import logging
import sys

from .loader import LoadError, group_by_question, load_rows
from .masking import mask_names
from .summarize import SummarizeError, summarize, summarize_rule_based

log = logging.getLogger("app")


def run(path: str, dry_run: bool, client=None, out=sys.stdout) -> int:
    try:
        rows = load_rows(path)
    except LoadError as e:
        print(str(e), file=sys.stderr)
        return 1

    groups = group_by_question(rows)
    log.info("読み込み完了：%d行、設問%d件", len(rows), len(groups))  # 個人名は出さない（NFR-003）

    summaries = []
    for q, answers in groups.items():
        try:
            s = summarize_rule_based(q, answers) if dry_run else summarize(client, q, answers)
        except SummarizeError as e:
            print(str(e), file=sys.stderr)
            return 2
        summaries.append({"question": mask_names(q), "summary": s})

    print(json.dumps({"summaries": summaries}, ensure_ascii=False, indent=2), file=out)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="研修アンケート要約ツール")
    p.add_argument("csv")
    p.add_argument("--dry-run", action="store_true", help="AIを使わずにルールで要約する")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    client = None
    if not a.dry_run:
        try:
            import anthropic  # 実APIを使うときだけ必要
        except ImportError:
            print("anthropic パッケージがありません。--dry-run で試すか、インストールしてください", file=sys.stderr)
            return 1
        client = anthropic.Anthropic()  # APIキーは環境変数 ANTHROPIC_API_KEY から
    return run(a.csv, a.dry_run, client)


if __name__ == "__main__":
    sys.exit(main())
