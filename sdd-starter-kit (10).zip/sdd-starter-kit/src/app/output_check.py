"""AI出力の形式と不変条件の検査（FR-002, FR-003）"""
from __future__ import annotations

import json

from .masking import contains_name

MAX_SUMMARY_CHARS = 200  # Q-002 で確定予定（暫定）


def check_output(text: str, n_questions: int) -> list[str]:
    """{"summaries": [...]} 形式のJSONを検査し、問題点の一覧を返す（空なら合格）"""
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return ["JSONとして解釈できない"]
    items = data.get("summaries") if isinstance(data, dict) else None
    if not isinstance(items, list):
        return ["summaries が配列でない"]

    errors: list[str] = []
    if len(items) != n_questions:
        errors.append(f"件数が不一致: {len(items)} != {n_questions}")
    for i, s in enumerate(items):
        if not isinstance(s, str) or not s.strip():
            errors.append(f"{i}件目が空")
        elif len(s) > MAX_SUMMARY_CHARS:
            errors.append(f"{i}件目が長すぎる（{len(s)}字）")
        elif contains_name(s):
            errors.append(f"{i}件目に個人名の疑い")
    return errors
