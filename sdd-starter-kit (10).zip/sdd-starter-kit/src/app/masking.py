"""FR-003 個人名のマスキング / NFR-003 セキュリティ

注意：正規表現による簡易検出です。見逃しがありうるため、人の確認と併用します。
"""
from __future__ import annotations

import re

MASK = "[氏名]"
HONORIFICS = ("さん", "様", "氏", "殿", "くん", "ちゃん", "先生")
# 置き換えない一般語（敬称の形をしているが個人名ではない）
ALLOW = {"客様", "皆様", "皆さん", "各位様"}  # 「お客様」は「お」が対象外の文字なので「客様」で判定

# ひらがなは含めない（「講師の先生」「お疲れ様」の誤検出を避けるため。ひらがな表記の名前は見逃す）
_NAME_CHARS = r"[一-龥々ァ-ヶーA-Za-zＡ-Ｚａ-ｚ]"
_PATTERN = re.compile(rf"{_NAME_CHARS}{{1,10}}?(?:{'|'.join(HONORIFICS)})")


def _replace(m: re.Match[str]) -> str:
    word = m.group(0)
    return word if word in ALLOW else MASK


def mask_names(text: str) -> str:
    """敬称つきの個人名を [氏名] に置き換える。2回かけても結果は同じ（冪等）。"""
    prev = None
    out = text
    # 置き換えで新しい一致が生まれても安定するまで繰り返す（最大3回）
    for _ in range(3):
        if out == prev:
            break
        prev, out = out, _PATTERN.sub(_replace, out)
    return out


def contains_name(text: str) -> bool:
    """マスキング漏れの機械検査（出力・ログの点検用）"""
    return mask_names(text) != text
