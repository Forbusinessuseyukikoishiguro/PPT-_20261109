"""実APIの評価セット（AI出力の品質）。費用がかかるため、人の承認後に手動で実行する。

使い方：python eval/run_eval.py --i-approve-cost
- 1回の成否ではなく、同じ入力を N_RUNS 回試した「合格率」で見る
- 合格するまで再実行しない（品質の保証にならない）
- モデル名・プロンプト版・結果を eval/eval_log.jsonl に残す
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from app.masking import contains_name  # noqa: E402
from app.output_check import MAX_SUMMARY_CHARS  # noqa: E402
from app.summarize import PROMPT_VERSION, model_name, summarize  # noqa: E402

N_RUNS = 5        # 例：同じ入力を何回試すか（人が決める）
THRESHOLD = 0.9   # 例：合格率の基準（人が決める）


def check(output: str, case: dict) -> bool:
    if not output or len(output) > MAX_SUMMARY_CHARS or contains_name(output):
        return False
    if any(w in output for w in case.get("must_not_include", [])):
        return False
    inc = case.get("must_include_any")
    return not inc or any(w in output for w in inc)


def run_eval(cases, run_agent, meta, n_runs=N_RUNS, log_path=ROOT / "eval" / "eval_log.jsonl"):
    results = []
    for c in cases:
        passes = sum(bool(check(run_agent(c), c)) for _ in range(n_runs))
        results.append({"id": c["id"], "kind": c.get("kind"), "pass_rate": passes / n_runs})
    overall = sum(r["pass_rate"] for r in results) / len(results)
    record = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), **meta, "overall": overall, "results": results}
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return overall >= THRESHOLD, results


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--i-approve-cost", action="store_true", help="API費用の発生を承認する")
    a = ap.parse_args()
    if not a.i_approve_cost:
        print("実APIを呼びます。費用を承認する場合は --i-approve-cost を付けてください")
        return 1
    import anthropic

    client = anthropic.Anthropic()
    cases = [json.loads(l) for l in (ROOT / "eval" / "cases.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    ok, results = run_eval(cases, lambda c: summarize(client, c["question"], c["answers"]),
                           {"model": model_name(), "prompt_version": PROMPT_VERSION})
    for r in results:
        print(f'{r["id"]:<10} {r["kind"]:<5} 合格率 {r["pass_rate"]:.0%}')
    print("基準を満たす" if ok else "基準未達", "（最終判断は人の採点と合わせて行う）")
    return 0 if ok else 3


if __name__ == "__main__":
    sys.exit(main())
