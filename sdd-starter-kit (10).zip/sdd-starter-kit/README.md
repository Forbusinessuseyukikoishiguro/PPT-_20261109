# AI仕様駆動開発 スターターキット（VS Code × Claude Code）

うさうさ研修工房 Udemy講座「DXエンジニアのためのAI仕様駆動開発」の演習用キットです。
題材は「研修アンケート要約ツール」。ヒアリング → 合意 → 仕様 → 計画 → 実装 → テスト → 評価 → 納品説明 までの .md 一式と、動くサンプルコードが入っています。

> Claude Code の機能・設定の書式は更新が速い分野です。実行前に公式ドキュメント（https://code.claude.com/docs ）で最新を確認してください。
> 規格の本文は有償です。本キットは「規格の考え方を参考にした書き方」であり、準拠を証明するものではありません。

## 1. 準備（約15分）
1. VS Code（1.98.0 以上）をインストール
2. 拡張機能「Claude Code」（発行元 Anthropic）をインストール（`.vscode/extensions.json` で推奨表示されます）
3. このフォルダを VS Code で開く（`code .`）
4. Python 3.10 以上で `pip install -r requirements.txt`
5. 動作確認：`cd src && python -m app.main ../data/sample.csv --dry-run`
6. テスト：プロジェクト直下で `python -m pytest -q`、仕様点検：`python tools/spec_lint.py`

**おすすめ設定**：計画を先に出させるため、VS Code のユーザー設定でプランモードを初期値にできます（設定名は公式で確認：`claudeCode.initialPermissionMode`）。

## 2. フォルダ構成
```
CLAUDE.md                 共通ルール（毎回読まれる）
.claude/skills/*/SKILL.md 自作スラッシュコマンド（/spec-plan など）
.claude/agents/*.md       読み取り専用のレビュー担当（サブエージェント）
.claude/settings.json     読ませないファイルの指定
docs/00-hearing/          ヒアリングシート
docs/01-agreement/        合意事項シート・議事録・変更要求票（CR）
docs/02-spec/             仕様（正）：概要・機能・非機能・受入基準
docs/03-decisions/        決定記録（DEC）・ADR
docs/04-test/             テスト戦略・トレーサビリティ・テストケース
docs/05-eval/             品質評価レポート・レビュー記録・出荷判定・欠陥票
docs/06-delivery/         納品説明・納品物一覧
src/app/                  サンプル実装（読み込み・マスキング・要約・出力検査）
tests/                    pytest（境界値・異常系・モック・プロパティ）
eval/                     実APIの評価セット（人の承認後に実行）
tools/spec_lint.py        仕様の機械点検（曖昧語・ID・受入基準・テスト対応）
```

## 3. 進め方（講座の流れと同じ）
| 段階 | 人がやること | Claude Code への頼み方 |
|---|---|---|
| ヒアリング | `docs/00-hearing/hearing-sheet.md` で聞く | `/hearing-organize docs/00-hearing/memo.md` |
| 合意 | 合意事項シートに顧客の承認をもらう | （AIは下書きまで） |
| 仕様 | 草案をレビューし、未決事項を決める | `/spec-draft` → `/spec-review` |
| 計画 | 計画・疑問点に答える | `/spec-plan FR-001` |
| テスト設計 | 期待結果が仕様から来ているか確認 | `/test-design FR-001` |
| 実装 | 差分を全部読む | `/implement FR-001` |
| エラー | 原因を確定し、修正を承認する | `/error-triage` |
| 評価 | 受入基準で確認し、合否を決める | `test-reviewer` に点検させる |
| 納品 | 説明・既知の課題を正直に伝える | `/delivery-doc` |

## 4. 3原則
1. 仕様は `.md` で渡す 2. エラーはエンジニアが直す 3. 評価は人がする

## 5. うさうさ仕様駆動工房（ブラウザツール）
`tools/sdd-koubou.html` をブラウザで開くだけで動きます（外部通信なし。v1.5 から文字コードの宣言つきの単体のHTMLにしました。v1.4 以前で文字化けした場合は、この版に差し替えてください）。共用のPCでは、使い終わったら 🐞 の画面の「このブラウザから工房のデータを消す」で消してください。記事・研修資料6本の全文を読める「学習」タブがあります（同じ全文は `docs/articles/` にも .md で入っています）。

v1.4 で「議事録」タブを追加しました。会議メモ（◎ 決定／？ 未決／→ アクション）から Slack 投稿文・Notion 用 .md・要件書と仕様書の草案を作り、Notion から書き出した .md や保存した .json を読み込めます。右上の「？ 使い方」で各タブの使い方、「🔊 音」で効果音のオン・オフ、「🐞」で操作とエラーのログ（本文は記録しない）を見られます。この機能の仕様書は `tools/koubou-spec/MIN-議事録/` にあります。

v1.5 で「ソース改修支援」タブを追加しました。既存のソース（HTML・CSS・JS・Python・SQL）を貼ると、構造・既存の書き方・エラー原因の仮説・テーブル設計の指摘を出し、テーブルの段階的な変え方（DBMS別のSQL・確認・戻し方）、差分の制約点検（テストの期待値・関数の形・依存・DB・書き方・秘密情報）、改修仕様書（影響範囲・順番・優先・3点見積もり・仕様を詰める質問・根拠の論文）、Claude Code への依頼文を作ります。仕様書は `tools/koubou-spec/CODE-ソース改修支援/` です。仕様の点検は `python tools/spec_lint.py --spec tools/koubou-spec/CODE-ソース改修支援 --tests tools/koubou-spec/CODE-ソース改修支援` のように、仕様書のフォルダごとに行います。
仕様チェッカー（spec_lint と同じ規則）／ヒアリングシート／要求文ビルダー／テスト設計／Claude Code への依頼文／テンプレート28種・仕様書サンプル5種（金融・保険ほか）／AIガイドライン点検（AI事業者ガイドライン 第1.2版 別添7 の趣旨をテスト観点に変換）／出荷判定／規格早見表／理解度テスト。
回帰テスト：`node tools/koubou-tests/test_logic.js`（ロジック）、`python tools/koubou-tests/ui_check.py tools/sdd-koubou.html`（Playwright）、`python tools/koubou-tests/bench_accuracy.py tools/sdd-koubou.html`（関数の見つけ方の精度。正解は Python の ast）
