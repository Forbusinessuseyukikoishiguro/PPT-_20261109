"""FR-003 個人名のマスキング（同値分割）"""
import pytest

from app.masking import contains_name, mask_names


# TC-020（FR-003）敬称つきの個人名を置き換える
@pytest.mark.parametrize("src, expected", [
    ("山田さんの説明が良かった", "[氏名]の説明が良かった"),
    ("田中様に感謝", "[氏名]に感謝"),
    ("スズキ先生の演習", "[氏名]の演習"),
    ("Tanakaさん", "[氏名]"),
])
def test_masks_names_with_honorifics(src, expected):
    assert mask_names(src) == expected


# TC-021（FR-003）一般語は置き換えない
@pytest.mark.parametrize("src", ["お客様の声", "皆様ありがとう", "皆さん元気", "講師の先生", "お疲れ様でした"])
def test_keeps_common_words(src):
    assert mask_names(src) == src


# TC-022（FR-003）冪等：2回かけても同じ
@pytest.mark.parametrize("src", ["山田さんと佐藤様", "", "皆様", "あいうえお", "[氏名]さん"])
def test_idempotent_examples(src):
    once = mask_names(src)
    assert mask_names(once) == once


def test_contains_name():
    assert contains_name("山田さん")
    assert not contains_name("名前なし")
