"""FR-003 プロパティベーステスト（hypothesis が無ければこのファイルだけスキップ）"""
import pytest

hypothesis = pytest.importorskip("hypothesis")
from hypothesis import given, strategies as st  # noqa: E402

from app.masking import mask_names  # noqa: E402

# TC-023（FR-003）どんな文字列でも：例外にならない・冪等
JP = st.text(alphabet="山田佐藤さん様氏殿先生のおお客皆ア イ A b。、[]氏名", max_size=40)


@given(st.one_of(st.text(), JP))
def test_mask_is_idempotent(s):
    once = mask_names(s)
    assert mask_names(once) == once


@given(st.text())
def test_mask_never_raises(s):
    mask_names(s)
