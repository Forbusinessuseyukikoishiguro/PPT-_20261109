"""ソース改修支援の「関数の見つけ方」の精度を、実在のコードで測る。

正解は Python 標準の構文解析（ast）。この PC に入っている Python 標準ライブラリの30ファイルを使う。
JS は、acorn（構文解析器）のパスを環境変数 ACORN に入れたときだけ測る（任意）。

使い方：
  python tools/koubou-tests/bench_accuracy.py tools/sdd-koubou.html
  ACORN=/path/to/node_modules/acorn python tools/koubou-tests/bench_accuracy.py tools/sdd-koubou.html

終了コード：0 = Python の再現率・適合率がともに 0.98 以上／1 = 下回った
"""
from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
import sysconfig
import tempfile
from pathlib import Path

MODULES = ["json/decoder.py", "json/encoder.py", "csv.py", "textwrap.py", "shlex.py", "string.py", "glob.py",
           "fnmatch.py", "heapq.py", "bisect.py", "base64.py", "calendar.py", "difflib.py", "argparse.py",
           "configparser.py", "dataclasses.py", "functools.py", "gettext.py", "ipaddress.py", "pprint.py",
           "queue.py", "secrets.py", "statistics.py", "tempfile.py", "uuid.py", "zipfile/__init__.py",
           "logging/__init__.py", "http/cookies.py", "email/utils.py", "urllib/parse.py"]

MEASURE_JS = r"""
const fs=require('fs'),vm=require('vm');const html=fs.readFileSync(process.argv[2],'utf8');
const grab=id=>html.match(new RegExp('<script id="'+id+'"[^>]*>([\\s\\S]*?)</script>'))[1];
const ctx={module:{}};vm.createContext(ctx);vm.runInContext(grab('logic')+';this.SDD=SDD;',ctx);const S=ctx.SDD;
const data=JSON.parse(fs.readFileSync(process.argv[3],'utf8')); let tp=0,fp=0,fn=0; const t0=Date.now();
for (const f of data){ const a=S.analyzeCode('=== ファイル: '+f.name+' ===\n'+f.text);
  const got=new Set(a.funcs.map(x=>x.name+'@'+x.line)), truth=new Set(f.truth.map(x=>x[0]+'@'+x[1]));
  got.forEach(g=>{ if(truth.has(g)) tp++; else fp++; }); truth.forEach(t=>{ if(!got.has(t)) fn++; }); }
console.log(JSON.stringify({tp,fp,fn,ms:Date.now()-t0,files:data.length}));
"""

JS_TRUTH = r"""
const acorn=require(process.env.ACORN); const fs=require('fs');
const walk=(n,f)=>{ if(!n||typeof n.type!=='string')return; f(n); for(const k in n){ const v=n[k]; if(Array.isArray(v)) v.forEach(c=>c&&typeof c.type==='string'&&walk(c,f)); else if(v&&typeof v.type==='string') walk(v,f);} };
const out=[]; for (const p of process.argv.slice(2)){ const src=fs.readFileSync(p,'utf8'); let ast;
  for (const st of ['module','script']){ try{ ast=acorn.parse(src,{ecmaVersion:'latest',sourceType:st,locations:true,allowHashBang:true}); break; }catch(e){} }
  if(!ast) continue; const t=[];
  walk(ast,n=>{ if(n.type==='FunctionDeclaration'&&n.id) t.push([n.id.name,n.loc.start.line]);
    else if(n.type==='VariableDeclarator'&&n.id.type==='Identifier'&&n.init&&/Function|Arrow/.test(n.init.type)) t.push([n.id.name,n.loc.start.line]);
    else if(n.type==='MethodDefinition'&&n.key&&n.key.name&&n.kind==='method') t.push([n.key.name,n.loc.start.line]);
    else if(n.type==='Property'&&n.key&&(n.key.name||n.key.value)&&n.value&&/Function|Arrow/.test(n.value.type)) t.push([n.key.name||n.key.value,n.loc.start.line]); });
  out.push({name:'x/'+p.split('/').pop().replace(/\.cjs$/,'.js'),text:src,truth:t}); }
process.stdout.write(JSON.stringify(out));
"""


def run_node(script: str, *args: str, env: dict | None = None) -> str:
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
        f.write(script)
        path = f.name
    try:
        return subprocess.run(["node", path, *args], capture_output=True, text=True, check=True, env=env).stdout
    finally:
        os.unlink(path)


def measure(html: str, data: list[dict]) -> dict:
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as f:
        json.dump(data, f)
        path = f.name
    try:
        return json.loads(run_node(MEASURE_JS, html, path))
    finally:
        os.unlink(path)


def report(label: str, r: dict) -> tuple[float, float]:
    recall = r["tp"] / max(1, r["tp"] + r["fn"])
    precision = r["tp"] / max(1, r["tp"] + r["fp"])
    print(f"{label}: {r['files']}ファイル 再現率 {recall:.3f} 適合率 {precision:.3f}（正 {r['tp']}・誤検出 {r['fp']}・見落とし {r['fn']}）{r['ms']}ms")
    return recall, precision


def main() -> int:
    html = sys.argv[1] if len(sys.argv) > 1 else "tools/sdd-koubou.html"
    stdlib = Path(sysconfig.get_paths()["stdlib"])
    data = []
    for m in MODULES:
        p = stdlib / m
        if not p.exists():
            continue
        src = p.read_text(encoding="utf-8")
        truth = [[n.name, n.lineno] for n in ast.walk(ast.parse(src)) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        data.append({"name": "x/" + m, "text": src, "truth": truth})
    rec, pre = report("Python（正解：ast）", measure(html, data))
    acorn = os.environ.get("ACORN")
    if acorn:
        js_files = sys.argv[2:] or []
        if js_files:
            js = json.loads(run_node(JS_TRUTH, *js_files, env={**os.environ, "ACORN": acorn}))
            report("JS（正解：acorn。constructor は正解に含めない）", measure(html, js))
    ok = rec >= 0.98 and pre >= 0.98
    print("判定：", "合格" if ok else "不合格（0.98 未満）")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
