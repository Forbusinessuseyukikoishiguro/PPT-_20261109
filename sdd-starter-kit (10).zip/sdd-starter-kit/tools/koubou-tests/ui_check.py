"""画面層のシステムテスト（Playwright + Chromium）。全タブを開き、操作し、エラーが出ないことを確かめる"""
import sys, pathlib
from playwright.sync_api import sync_playwright
html = pathlib.Path(sys.argv[1]).resolve()
shots = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
src = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'></head><body>" + html.read_text(encoding="utf-8") + "</body></html>"
errors, n = [], 0
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, scheme in [(1280, "light"), (390, "dark")]:
        pg = b.new_page(viewport={"width": w, "height": 900}, color_scheme=scheme)
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("console", lambda m: m.type == "error" and errors.append(m.text))
        pg.set_content(src)
        tabs = pg.locator("nav button")
        assert tabs.count() == 14, tabs.count()
        for i in range(tabs.count()):
            tabs.nth(i).click(); n += 1
            sw = pg.evaluate("document.documentElement.scrollWidth"); cw = pg.evaluate("document.documentElement.clientWidth")
            assert sw <= cw + 1, f"横スクロール {w}px tab{i}: {sw}>{cw}"
            if shots: pg.screenshot(path=str(shots / f"tab{i}-{w}.png"), full_page=False)
        # 学習（記事全文）
        tabs.nth(0).click(); assert pg.locator("[data-art]").count() == 6; n += 1
        pg.click("[data-art='a3']"); assert "AI事業者ガイドライン" in pg.inner_text("#lnToc"); n += 1
        assert pg.locator("#lnDoc .mm").count() >= 3; assert pg.locator("#lnDoc .codeblk").count() >= 10; n += 1
        pg.locator("#lnToc [data-read]").first.check(); assert "読了 1/" in pg.inner_text("[data-art='a3']"); n += 1
        pg.fill("#lnSearch", "FISC"); pg.locator("[data-hit]").first.click(); assert "金融" in pg.inner_text("#lnDoc"); n += 1
        # 仕様書サンプル：記事の原文
        tabs.nth(1).click(); assert pg.locator("[data-ab]").count() >= 60; n += 1
        pg.select_option("#abArt", "a5"); pg.locator("[data-ab]").first.click(); pg.click("#abRead"); assert pg.locator("#lnDoc").count() == 1; n += 1
        tabs.nth(1).click(); pg.click("[data-s='1']"); pg.click("#smpRead"); assert "振込依頼" in pg.inner_text("#lnDoc"); n += 1
        # 仕様チェッカー
        tabs.nth(2).click(); pg.click("#lintGood"); assert "指摘はありません" in pg.inner_text("#lintOut"); n += 1
        pg.click("#lintBad"); assert "重複" in pg.inner_text("#lintOut"); n += 1
        pg.select_option("#lintSample", "fin"); assert "指摘はありません" in pg.inner_text("#lintOut"); n += 1
        # 仕様書サンプル → チェッカー・依頼文へ
        tabs.nth(1).click(); pg.click("[data-s='2']"); assert "保険" in pg.inner_text("#smpInfo"); assert "FR-008" in pg.inner_text("#smpReqs"); n += 1
        pg.click("#smpLint"); assert "SPEC-INS-001" in pg.input_value("#specIn"); assert "指摘はありません" in pg.inner_text("#lintOut"); n += 1
        tabs.nth(1).click(); pg.click("#smpHoles"); assert "二重処理" in pg.inner_text("#pOut"); n += 1
        # ヒアリング
        tabs.nth(3).click(); pg.fill("#h_a3", "なるべく速く"); assert "M/S/C/W" in pg.inner_text("#hFollow"); n += 1
        # 要求文ビルダー
        tabs.nth(5).click(); pg.fill("#rAction", "結果を表示する"); assert "表示しなければならない" in pg.inner_text("#rOut"); n += 1
        # テスト設計
        tabs.nth(6).click(); pg.fill("#bMax", "300"); assert "301行" in pg.inner_text("#bOut"); n += 1
        # プロンプト
        tabs.nth(7).click(); pg.select_option("#pKind", "error"); assert "まだ修正はしないでください" in pg.inner_text("#pOut"); n += 1
        # テンプレート
        tabs.nth(9).click(); pg.click("[data-t='2']"); assert "合意事項シート" in pg.inner_text("#tOut"); n += 1
        # 出荷判定
        tabs.nth(10).click()
        for c in pg.locator("[data-g]").all(): c.check()
        assert "判定会に出せます" in pg.inner_text("#gVerdict"); n += 1
        # AIガイドライン点検
        tabs.nth(11).click(); assert "判断者が空" in pg.inner_text("#gwIssues"); n += 1
        pg.fill("#gwOwner", "石黒"); pg.select_option("[data-b='H-08']", "非該当")
        assert "非該当の理由がない" in pg.inner_text("#gwIssues"); n += 1
        pg.fill("[data-b='H-08'][data-k='reason']", "基盤モデルを開発しない"); assert "基盤モデルを開発しない" in pg.inner_text("#gwOut"); n += 1
        # 規格
        tabs.nth(12).click(); pg.select_option("#sPhase", "テスト"); assert "29119" in pg.inner_text("#sBody"); n += 1
        pg.select_option("#sPhase", "すべて"); pg.select_option("#sKind", "金融・保険"); assert "FISC" in pg.inner_text("#sBody"); n += 1
        # クイズ
        tabs.nth(13).click(); pg.locator("[data-q='0'][data-o='0']").click(); assert "1 / 23" in pg.inner_text("#qScore"); n += 1
        # v1.4 議事録
        tabs.nth(4).click(); assert "議事録" in pg.inner_text("nav button[aria-selected='true']"); n += 1
        pg.click("#mSample"); assert "期限がない" in pg.inner_text("#mIssues"); n += 1
        assert "✅ 合意：入力はCSV" in pg.inner_text("#mOut"); n += 1
        pg.click("[data-mo='spec']"); out = pg.inner_text("#mOut"); assert "## FR-001" in out and "## NFR-001" in out and "次回の打合せ" not in out; n += 1
        pg.click("#mToLint"); assert "FR-001" in pg.input_value("#specIn"); n += 1
        tabs.nth(4).click(); pg.click("[data-mo='req']"); assert "REQ-001" in pg.inner_text("#mOut") and "次回の打合せ" in pg.inner_text("#mOut"); n += 1
        pg.click("[data-mo='notion']"); notion = pg.inner_text("#mOut"); assert "## 決定事項" in notion and "- [ ]" in notion; n += 1
        # インポート：Notion 書式の .md
        nmd = "# 定例 議事録\n\n日付: 10/30\n\n## 決定事項\n- 画面に検索ボタンを追加する（要望が多い）\n\n## 未決\n- 権限の範囲\n\n## アクション\n- [ ] 画面案を作る @C 11/2\n"
        pg.set_input_files("#mFile", files=[{"name": "notion.md", "mimeType": "text/markdown", "buffer": nmd.encode("utf-8")}])
        pg.wait_for_timeout(200); assert "読み込みました" in pg.inner_text("#mStatus"); assert pg.input_value("#m_title") == "定例"; assert "@C" in pg.input_value("#mMemo") or "C 11/2" in pg.input_value("#mMemo"); n += 1
        pg.set_input_files("#mFile", files=[{"name": "bad.json", "mimeType": "application/json", "buffer": b"{oops"}])
        pg.wait_for_timeout(200); assert "読み込めませんでした" in pg.inner_text("#mStatus"); n += 1
        pg.set_input_files("#mFile", files=[{"name": "x.png", "mimeType": "image/png", "buffer": b"123"}])
        pg.wait_for_timeout(200); assert ".md／.txt／.json" in pg.inner_text("#mStatus"); n += 1
        # 保存（ブラウザのダウンロード）
        with pg.expect_download() as dl: pg.click("#mSaveJson")
        assert dl.value.suggested_filename.endswith(".json"); n += 1
        with pg.expect_download() as dl: pg.click("#mTplNotion")
        assert "Notion用_議事録テンプレ" in dl.value.suggested_filename; n += 1
        # v1.5 ソース改修支援
        pg.click("nav button[data-tab='code']"); pg.wait_for_timeout(300)
        assert "5 ファイル" in pg.inner_text("#cSrcInfo"); n += 1
        assert "SQLを文字列の連結" in pg.inner_text("#cView") and "#count がHTMLにない" in pg.inner_text("#cView"); n += 1
        pg.click("[data-co='conv']"); assert "インデント（Python）" in pg.inner_text("#cOutConv"); n += 1
        pg.click("[data-co='err']"); assert "辞書に、そのキーがない" in pg.inner_text("#cOutErr") and "load_answers" in pg.inner_text("#cOutErr"); n += 1
        pg.click("[data-co='db']"); assert "answer_text IS NOT body" in pg.inner_text("#cOutDb"); n += 1
        pg.select_option("#dbOp", "add_index"); pg.select_option("#dbDbms", "postgresql"); pg.fill("#dbCol", "question_id"); pg.press("#dbCol", "Tab")
        assert "CONCURRENTLY" in pg.inner_text("#cOutDb"); assert "answers" in pg.inner_text("#cOutSchema"); n += 1
        pg.click("[data-co='diff']"); dt = pg.inner_text("#cView"); assert "制約に反する変更があります" in dt and "pandas" in dt; n += 1
        pg.uncheck("#cc_deps"); pg.wait_for_timeout(100); pg.click("[data-co='diff']"); assert "pandas" not in pg.inner_text("#cView"); pg.check("#cc_deps"); n += 1
        pg.click("[data-co='est']"); before = pg.inner_text("#cView")
        inp = pg.locator("[data-est='T5'][data-k='m']"); inp.fill("20"); inp.dispatch_event("change"); pg.wait_for_timeout(100)
        assert pg.inner_text("#cView") != before and "仕様を詰める質問" in pg.inner_text("#cView"); n += 1
        pg.click("[data-co='spec']"); sp = pg.inner_text("#cOutSpec"); assert "## 12. 根拠" in sp and "| T5 |" in sp and "| 20 |" in sp; n += 1
        pg.click("#cToLint"); assert "改修仕様書" in pg.input_value("#specIn"); n += 1
        pg.click("nav button[data-tab='code']"); pg.click("[data-co='prompt']"); pg.select_option("#cPkind", "error"); assert "まだ修正はしないでください" in pg.inner_text("#cOutPrompt"); n += 1
        pg.click("[data-co='refs']"); assert "Zeller" in pg.inner_text("#cView") and "書籍" in pg.inner_text("#cView"); n += 1
        pg.set_input_files("#cFiles", files=[{"name": "extra.py", "mimeType": "text/x-python", "buffer": "def added_func(x):\n    return x\n".encode()}, {"name": "x.exe", "mimeType": "application/octet-stream", "buffer": b"MZ"}])
        pg.wait_for_timeout(300); assert "6 ファイル" in pg.inner_text("#cSrcInfo") and "読み込めない 1" in pg.inner_text("#cSrcInfo"); n += 1
        pg.click("[data-co='arch']"); assert "added_func" in pg.inner_text("#cView"); n += 1
        with pg.expect_download() as dl: pg.click("[data-co='spec']"); pg.click("[data-csave='cOutSpec']")
        assert dl.value.suggested_filename.endswith(".md"); n += 1
        # スパルタレビューの修正：キーでタブ移動・データの消去・利用上の注意
        pg.focus("nav button[data-tab='learn']"); pg.keyboard.press("ArrowRight"); assert pg.get_attribute("nav button[data-tab='samples']", "aria-selected") == "true"; n += 1
        pg.keyboard.press("End"); assert pg.get_attribute("nav button[data-tab='quiz']", "aria-selected") == "true" and pg.evaluate("document.activeElement.dataset.tab") == "quiz"; n += 1
        pg.keyboard.press("Home"); assert pg.get_attribute("nav button[data-tab='learn']", "aria-selected") == "true"; n += 1
        assert pg.locator("nav button[tabindex='0']").count() == 1 and pg.get_attribute("#panel", "aria-labelledby") == "tab-learn"; n += 1
        pg.click("#btnHelp"); ht = pg.inner_text("#helpDlg"); assert "利用上の注意" in ht and "更新履歴" in ht and "v1.5" in ht; pg.keyboard.press("Escape"); n += 1
        pg.evaluate("localStorage.setItem('sdd:test','1')") if pg.evaluate("(()=>{try{localStorage.setItem('x','1');return true}catch(e){return false}})()") else None
        pg.click("#btnBug"); pg.click("#bugWipe"); assert "もう一度押すと消します" in pg.inner_text("#bugWipe"); pg.click("#bugWipe"); assert "消しました" in pg.inner_text("#bugWipeMsg"); n += 1
        pg.keyboard.press("Escape")
        # 使い方・音・🐞
        pg.click("#btnHelp"); assert pg.locator("#helpDlg[open]").count() == 1 and "いまここ" in pg.inner_text("#helpDlg"); n += 1
        pg.locator("#helpDlg [data-close]").click(); assert pg.locator("#helpDlg[open]").count() == 0; n += 1
        pg.click("#btnSound"); assert pg.get_attribute("#btnSound", "aria-pressed") == "false"; pg.click("#btnSound"); assert pg.get_attribute("#btnSound", "aria-pressed") == "true"; n += 1
        pg.click("#btnBug"); txt = pg.inner_text("#bugDlg"); assert "議事録の読み込み失敗" in txt and "タブ：" in txt; n += 1
        assert "notion.md" not in txt and "研修アンケート要約ツール" not in txt, "ログにファイル名・会議名が残っている"; n += 1
        pg.select_option("#bugLv", "エラー"); assert "タブ：" not in pg.inner_text("#bugDlg .loglist"); n += 1
        with pg.expect_download() as dl: pg.click("#bugSave")
        assert dl.value.suggested_filename.startswith("工房ログ_"); n += 1
        pg.keyboard.press("Escape"); assert pg.locator("#bugDlg[open]").count() == 0; n += 1
        assert pg.get_attribute("#btnBug", "data-err") not in (None, "0"); n += 1
        # コピー
        tabs.nth(9).click(); pg.click("[data-copy='tOut']"); pg.wait_for_timeout(200); n += 1
        if shots: pg.screenshot(path=str(shots / f"final-{w}.png"))
        pg.close()
    b.close()
assert not errors, errors
print(f"OK {n} UI checks, no page errors")
