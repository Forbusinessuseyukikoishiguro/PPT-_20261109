// うさうさ仕様駆動工房 ロジック層の回帰テスト（node だけで動く。DOM不要）
const fs = require("fs"), vm = require("vm"), assert = require("assert");
const html = fs.readFileSync(process.argv[2] || __dirname + "/../sdd-koubou.html", "utf8");
const grab = id => html.match(new RegExp('<script id="' + id + '"[^>]*>([\\s\\S]*?)</script>'))[1];
const ctx = {module:{}}; vm.createContext(ctx);
vm.runInContext(grab("logic") + "\n;this.SDD=SDD;", ctx);
vm.runInContext(grab("data") + "\n;this.DATA=DATA;", ctx);
vm.runInContext(grab("samples") + "\n;this.SAMPLES=SAMPLES;", ctx);
const ARTS = JSON.parse(html.match(/<script id="articles" type="application\/json">([\s\S]*?)<\/script>/)[1]);
// 画面層も構文だけ確認
new vm.Script(grab("ui"));
const S = ctx.SDD, D = ctx.DATA, SM = ctx.SAMPLES;
let n = 0; const t = (name, fn) => { fn(); n++; };

t("悪い例：重複・GWTなし・曖昧語・テストなしを検出", () => {
  const r = S.lintSpec(D.sampleSpec, D.sampleTrace), c = S.countBy(r.findings);
  const msg = r.findings.map(f => f.message).join("\n");
  assert(/重複/.test(msg)); assert(/Given/.test(msg)); assert(/いい感じ/.test(msg)); assert(/速く/.test(msg));
  assert(/複数の動作/.test(msg)); assert(/欠番：FR-003, FR-004/.test(msg));
  assert(r.reqs.find(q => q.id === "FR-005").tested === true);
  assert(r.reqs.find(q => q.id === "FR-002").tested === false);
  assert(c["高"] >= 4);
});
t("良い例：指摘0件", () => {
  const r = S.lintSpec(D.goodSpec, "FR-001 FR-002 FR-003");
  assert.strictEqual(r.findings.length, 0, JSON.stringify(r.findings));
});
t("テスト一覧が空なら『テストなし』は出さない", () => {
  const r = S.lintSpec(D.goodSpec, "");
  assert(!r.findings.some(f => /テストが1つもない/.test(f.message)));
});
t("要求見出しがない", () => assert.strictEqual(S.lintSpec("# なにか", "").findings[0].level, "高"));
t("測定環境なしの時間基準は低", () => {
  const r = S.lintSpec("## FR-001 a\nシステムは、読み込まなければならない。\n- Given x / When y / Then 5秒以内に完了する", "");
  assert(r.findings.some(f => f.level === "低" && /測定環境/.test(f.message)));
});
t("活用：する／五段／一段", () => {
  assert.strictEqual(S.obligationPhrase("読み込む"), "読み込まなければならない");
  assert.strictEqual(S.obligationPhrase("表示する", "してはならない"), "表示してはならない");
  assert.strictEqual(S.obligationPhrase("置き換える"), "置き換えなければならない");
  assert.strictEqual(S.obligationPhrase("送る", "してもよい"), "送ってもよい");
  assert.strictEqual(S.obligationPhrase("出力する", "することが望ましい"), "出力することが望ましい");
  assert.strictEqual(S.obligationPhrase("読み込む", "してはならない"), "読み込んではならない");
});
t("要求文ビルダーの出力は点検を通る", () => {
  const md = S.buildRequirement({id:"FR-001", title:"CSV読み込み", action:"UTF-8のCSVを読み込む", given:"1000行のCSV", when:"読み込む", then:"5秒以内に完了する", env:"Windows 11"});
  assert(/読み込まなければならない。/.test(md));
  assert.strictEqual(S.lintSpec(md, "").findings.length, 0, JSON.stringify(S.lintSpec(md, "").findings));
});
t("境界値：0〜1000（下限の直前は除く）", () => {
  const b = S.boundaryCases(0, 1000, {req:"FR-001"});
  assert.deepStrictEqual(Array.from(b.cases.map(c => c.value)), [0, 1, 999, 1000, 1001]);
  assert.strictEqual(b.cases[4].valid, false); assert.strictEqual(b.cases[0].id, "TC-001");
});
t("境界値：1〜3 で重複を除く", () => {
  const b = S.boundaryCases(1, 3);
  assert.deepStrictEqual(Array.from(b.cases.map(c => c.value)), [0, 1, 2, 3, 4]);
  assert.strictEqual(b.cases[0].valid, false);
});
t("境界値：入力エラー", () => assert(S.boundaryCases(10, 1).error));
t("デシジョンテーブル：2条件で4ケース・5条件はエラー", () => {
  const d = S.decisionTable(["A", "B"]);
  assert.strictEqual(d.cols, 4); assert(/\| A \| Y \| Y \| N \| N \|/.test(d.md)); assert(/\| B \| Y \| N \| Y \| N \|/.test(d.md));
  assert(S.decisionTable(["a","b","c","d","e"]).error); assert(S.decisionTable([""]).error);
});
t("曖昧語から質問を作る", () => {
  const f = S.followUps("いい感じに速くしたい");
  assert.deepStrictEqual(Array.from(f.map(x => x.word)), ["いい感じ", "速く"]);
});
t("ヒアリング記録に聞き返しが入る・表の区切りを壊さない", () => {
  const md = S.hearingToMd(D.hearing, {a2:"いい感じ|に"});
  assert(/「いい感じ」/.test(md)); assert(/いい感じ／に/.test(md));
});
t("出荷判定：全部済みでのみ ready", () => {
  const all = {}; S.GATES.forEach(g => all[g.id] = true);
  assert.strictEqual(S.gateVerdict(all).ready, true);
  delete all.G4; const r = S.gateVerdict(all);
  assert.strictEqual(r.ready, false); assert.strictEqual(r.missing.length, 1); assert(/決定者/.test(r.md));
});
t("プロンプト：全種類が要求IDを含み、判断を人に残す", () => {
  Object.keys(S.PROMPTS).forEach(k => {
    const p = S.buildPrompt(k, {id:"FR-009", extra:"補足X"});
    assert(p.length > 50, k);
    if (!["options","hearing","delivery","review","aigl"].includes(k)) assert(p.includes("FR-009"), k);
    assert(/(私|人|推奨は書かない|推測)/.test(p), k);
    assert(!/\n\n\n/.test(p), k);
  });
  assert(S.buildPrompt("plan", {id:"FR-1"}).includes("まだコードは書かない"));
  assert(S.buildPrompt("error", {}).includes("まだ修正はしないでください"));
});
t("データ：クイズの正解番号が範囲内・テンプレに本文", () => {
  D.quiz.forEach((q, i) => assert(q.a >= 0 && q.a < q.o.length, "quiz " + i));
  D.templates.forEach(x => assert(x.body.length > 20, x.id));
  assert(D.standards.length >= 12);
});
t("版数は APP にだけ書く（直書き禁止）", () => {
  const outside = html.replace(grab("logic"), "");
  assert(!/PRO v\d/.test(outside));
});
t("仕様書サンプル：5件、理由・意図つきで指摘0件", () => {
  assert(SM.length >= 5);
  SM.forEach(x => {
    const r = S.lintSpec(x.spec, "", {reason:true});
    assert.strictEqual(r.findings.length, 0, x.id + " " + JSON.stringify(r.findings));
    assert(r.reqs.length >= 3, x.id); assert(x.judge.length >= 2, x.id);
    assert(/架空|研修用/.test(x.spec) || x.id === "survey", x.id);
  });
});
t("理由・意図の点検はオプション", () => {
  const md = "## FR-001 a\nシステムは、読み込まなければならない。\n- Given x / When y / Then z";
  assert.strictEqual(S.lintSpec(md, "").findings.length, 0);
  assert(S.lintSpec(md, "", {reason:true}).findings.some(f => /理由・意図/.test(f.message)));
});
t("規格マップ：分類ごとに揃っている", () => {
  ["国際","AI","国内","金融・保険"].forEach(k => assert(D.standards.filter(x => x.kind === k).length >= 4, k));
  assert(D.standards.some(x => /非機能要求グレード/.test(x.code)));
  assert(D.templates.length >= 28); assert(D.quiz.length >= 23);
});
t("穴探しの依頼文は推奨・条文引用をさせない", () => {
  const p = S.buildPrompt("holes", {id:"FR-003"});
  assert(/推奨は書かない/.test(p) && /条文を記憶で引用しない/.test(p) && /二重処理/.test(p));
  assert(/条項番号や文言を引用しない/.test(S.buildPrompt("review", {})));
});
t("AIガイドライン点検：未判断・理由なし・判断者なしを検出", () => {
  const empty = S.guidelineIssues({});
  assert(empty.some(i => i.id === "全体" && i.level === "高"));
  assert.strictEqual(empty.filter(i => /^G-/.test(i.id)).length, 9);
  assert.strictEqual(empty.filter(i => /^H-/.test(i.id)).length, 12);
  const st = {owner:"石黒", a:{}, b:{}};
  S.AIGL_7A.forEach(g => st.a[g.id] = {status:"確認済", criteria:"個人情報0件"});
  S.AIGL_7B.forEach(h => st.b[h.id] = {apply:"該当", reason:"自社の範囲で実施"});
  assert.strictEqual(S.guidelineIssues(st).length, 0);
  st.b["H-08"] = {apply:"非該当", reason:""};
  assert(S.guidelineIssues(st).some(i => i.id === "H-08" && i.level === "高"));
  st.a["G-03"] = {status:"確認済", criteria:""};
  assert(S.guidelineIssues(st).some(i => i.id === "G-03" && /合格基準/.test(i.message)));
  const md = S.guidelineMd(st);
  assert(/第1\.2版/.test(md) && /自己点検/.test(md) && /\| G-09 \|/.test(md) && /⑫/.test(md));
  assert(S.buildPrompt("aigl", {}).includes("該当判断（該当／非該当）は書かない"));
  assert(S.GATES.some(g => g.id === "A6"));
});
t("学習：6本の全文が入り、本文の行がすべて表示に出る（消えていない）", () => {
  assert.strictEqual(ARTS.length, 6);
  const dec = h => h.replace(/<[^>]+>/g, "").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&amp;/g,"&").replace(/\s+/g,"");
  ARTS.forEach(a => {
    const r = S.mdToHtml(a.md, a.id), text = dec(r.html);
    let inCode = false, checked = 0, missing = [];
    a.md.split("\n").forEach(l => {
      if (/^```/.test(l)) { inCode = !inCode; return; }
      if (inCode) { const y = l.replace(/\s+/g, "").slice(0, 18); if (y) { checked++; if (text.indexOf(y.replace(/&/g,"&")) < 0) missing.push(y); } return; }
      let x = l.replace(/^>\s?/, "").replace(/^#{1,6}\s+|^\s*[-*]\s+(\[.\]\s+)?|^\s*\d+\.\s+|^>\s?|^:::(message alert|message|details)\s*|:::$/g, "").replace(/\*\*/g, "").replace(/`/g, "");
      if (!inCode && /^\s*\|/.test(l)) x = l.split("|").map(c => c.replace(/\*\*/g,"").replace(/`/g,"").trim()).filter(c => c && !/^:?-+:?$/.test(c)).join(" ");
      if (/^(flowchart|stateDiagram|graph )/.test(l.trim()) || (inCode && /-->|\[\*\]/.test(l))) return;
      x = x.replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, "$1").replace(/<br>/g, " ").replace(/\s+/g, " ").trim();
      if (!x || /^-{3,}$/.test(x)) return;
      const probe = x.replace(/\s+/g, "").slice(0, 18); checked++;
      if (text.indexOf(probe) < 0) missing.push(probe);
    });
    assert.strictEqual(missing.length, 0, a.id + " missing: " + JSON.stringify(missing.slice(0, 5)));
    assert(checked > 50, a.id);
  });
});
t("学習：見出し・表・コード・メッセージ・mermaid を描画", () => {
  const r = S.mdToHtml("## A\n\n| a | b |\n|---|---|\n| 1 | **2** |\n\n```python:x.py\nprint(1<2)\n```\n\n:::message alert\n注意 **重要**\n:::\n\n:::details 答え例\n答え\n:::\n\n- [ ] チェック\n1. 一\n2. 二", "t");
  assert(/<h3 id="t-s1">A<\/h3>/.test(r.html) && /<td><strong>2<\/strong><\/td>/.test(r.html) && /print\(1&lt;2\)/.test(r.html));
  assert(/md-msg alert/.test(r.html) && /<details class="md-details"><summary>答え例/.test(r.html) && /☐/.test(r.html) && /<ol>/.test(r.html));
  const m = S.mermaidToHtml("flowchart LR\n  A[要求] --> B[仕様]\n  B --> C[評価]\n  C -->|ずれ| B");
  assert(/mm-box">要求/.test(m) && /mm-box">評価/.test(m) && /ずれ/.test(m));
  assert(/今の状態/.test(S.mermaidToHtml("stateDiagram-v2\n  [*] --> 受付\n  受付 --> 完了: 終了")));
  assert(!/<script/i.test(S.mdToHtml("<script>alert(1)</script>").html));
});
t("学習：検索と、記事からの原文抽出", () => {
  const hits = S.searchArticles(ARTS, "非該当");
  assert(hits.length > 3 && hits.some(h => h.id === "a3"));
  assert.strictEqual(S.searchArticles(ARTS, "x").length, 0);
  const all = []; ARTS.forEach(a => S.extractBlocks(a.md).forEach(b => all.push(b)));
  assert(all.length >= 60);
  assert(all.some(b => /## FR-001 CSV読み込み/.test(b.body)));
  assert(all.some(b => /ADR-001 重複送信の防止方式/.test(b.body)));
});

// ===== v1.4 議事録 =====
const MEMO = "◎ 入力はCSVのみとする（費用のため）［決定: 課長］\n◎ 1000行を5秒以内に読み込む（最大人数から）［決定: 課長］\n◎ 次回の打合せは10/24に行う\n？ 外部AIへの送信可否 → 必要: 情報システム部の確認 ／情報システム部 ／10/24まで\n？ 文字数\n→ 仕様書を送付する @B 10/20\n→ 確認ポイントを作る @B\n雑談メモ";
t("議事録：記号で3つの箱に分ける（理由・決定者・担当・期限）", () => {
  const m = S.parseMinutesMemo(MEMO);
  assert.strictEqual(m.decisions.length, 3); assert.strictEqual(m.open.length, 2); assert.strictEqual(m.actions.length, 2); assert.strictEqual(m.other.length, 1);
  assert.strictEqual(m.decisions[0].reason, "費用のため"); assert.strictEqual(m.decisions[0].by, "課長");
  assert.strictEqual(m.open[0].owner, "情報システム部"); assert.strictEqual(m.open[0].due, "10/24"); assert.strictEqual(m.open[0].need, "情報システム部の確認");
  assert.strictEqual(m.actions[0].owner, "B"); assert.strictEqual(m.actions[0].due, "10/20"); assert.strictEqual(m.actions[0].task, "仕様書を送付する");
});
t("議事録：Slack記号（✅ ❓ ☑️）とリスト記号も読める", () => {
  const m = S.parseMinutesMemo("- ✅ A\n・❓ B（Cさん／11/1まで）\n1. ☑️ D ｜ @E ｜ 2026-11-02まで");
  assert.strictEqual(m.decisions[0].text, "A"); assert.strictEqual(m.open[0].owner, "Cさん"); assert.strictEqual(m.open[0].due, "11/1");
  assert.strictEqual(m.actions[0].due, "2026-11-02"); assert.strictEqual(m.actions[0].owner, "E");
});
t("議事録の点検：担当・期限なし、断定なし、記号なし行、空", () => {
  const m = S.parseMinutesMemo(MEMO + "\n◎ 来月から始める方向で検討する");
  const msg = S.minutesIssues({title:"x"}, m).map(i => i.level + i.message).join("\n");
  assert(/高.*アクション2.*期限がない/.test(msg)); assert(/中.*未決2.*担当がない/.test(msg)); assert(/断定されていない/.test(msg)); assert(/記号のない行/.test(msg));
  assert(S.minutesIssues({}, S.parseMinutesMemo("")).some(i => i.level === "高" && /1つもない/.test(i.message)));
});
t("決定の仮分類：機能・非機能・合意", () => {
  assert.strictEqual(S.classifyDecision("検索画面にボタンを追加する"), "機能");
  assert.strictEqual(S.classifyDecision("1000行を5秒以内に読み込む"), "非機能");
  assert.strictEqual(S.classifyDecision("次回の打合せは10/24に行う"), "合意");
  assert.strictEqual(S.classifyDecision("見積を来週送る"), "合意");
});
t("Slack・Notion に出して読み込むと同じ内容に戻る（超短縮以外の全種別）", () => {
  const m = S.parseMinutesMemo(MEMO.split("\n").filter(l => l !== "雑談メモ").join("\n"));
  const J = JSON.stringify, base = J({d:m.decisions, o:m.open, a:m.actions});
  S.MIN_KINDS.filter(k => k.id !== "short").forEach(k => {
    const r = S.parseMinutesFile(S.minutesToSlack(k.id, {title:"T", date:"10/17"}, m), "s.md"); assert(r.ok, k.id);
    const b = S.parseMinutesMemo(r.state.memo); assert.strictEqual(J({d:b.decisions, o:b.open, a:b.actions}), base, k.id);
    const n = S.parseMinutesFile(S.minutesToNotion(k.id, {title:"T", date:"10/17"}, m), "n.md"); assert(n.ok);
    const c = S.parseMinutesMemo(n.state.memo); assert.strictEqual(J({d:c.decisions, o:c.open, a:c.actions}), base, "notion " + k.id);
    assert.strictEqual(n.state.kind, k.id); assert.strictEqual(n.state.meta.title, "T"); assert.strictEqual(n.state.meta.date, "10/17");
  });
});
t("Notion から書き出した .md（見出しの下の箇条書き・完了チェック）を読める", () => {
  const md = "# 定例 議事録\n\n日付: 2026/10/30\n参加者: A, B\n\n## 決定事項\n- 画面に検索ボタンを追加する（要望が多い）\n\n## 未決\n- 権限の範囲\n\n## ToDo\n- [x] 画面案を作る @C 11/2\n- [ ] 見積 @D\n\n## メモ\n- 雑談";
  const r = S.parseMinutesFile(md, "export.md"); assert(r.ok);
  const m = S.parseMinutesMemo(r.state.memo);
  assert.strictEqual(r.state.meta.title, "定例"); assert.strictEqual(r.state.meta.date, "2026/10/30");
  assert.strictEqual(m.decisions.length, 1); assert.strictEqual(m.open.length, 1); assert.strictEqual(m.actions.length, 2);
  assert(/（完了）/.test(m.actions[0].task)); assert.strictEqual(m.other.length, 0);
});
t("空のNotionテンプレは読み込まない（ひな形の行を拾わない）", () => {
  const r = S.parseMinutesFile(S.minutesToNotion("std", {}, null), "tpl.md");
  assert.strictEqual(r.ok, false); assert(/見つかりません/.test(r.error));
});
t("JSONの保存と復元、壊れたJSON・別形式・大きすぎは理由つきで拒否", () => {
  const st = {kind:"poc", meta:{title:"T"}, memo:"◎ A"};
  const r = S.parseMinutesFile(S.minutesToJson(st), "a.json"); assert(r.ok); assert.strictEqual(r.state.kind, "poc"); assert.strictEqual(r.state.memo, "◎ A");
  assert(/JSONとして読めません/.test(S.parseMinutesFile("{oops", "a.json").error));
  assert(/format/.test(S.parseMinutesFile('{"a":1}', "a.json").error));
  assert.strictEqual(S.parseMinutesFile('{"format":"usausa-minutes","kind":"zzz","memo":"◎ A"}', "a.json").state.kind, "std");
  assert(/大きすぎ/.test(S.parseMinutesFile("x".repeat(500001), "a.md").error));
});
t("要件書：要求候補・合意事項・未決・宿題に分ける", () => {
  const m = S.parseMinutesMemo(MEMO), md = S.minutesToRequirements({title:"T", date:"10/17"}, m);
  assert(/REQ-001 \| 入力はCSVのみとする \| 機能/.test(md)); assert(/REQ-002 .* 非機能/.test(md));
  assert(/## 3\. 合意事項[\s\S]*次回の打合せ/.test(md)); assert(/Q-002 \| 文字数 \| （記入） \| 担当未定 \| 期限未定/.test(md));
  assert(/確認ポイントを作る \| B \| 期限未定/.test(md));
});
t("仕様書の草案：仕様チェッカーで読め、合意事項は入らない", () => {
  const m = S.parseMinutesMemo(MEMO), md = S.minutesToSpec({title:"T"}, m), r = S.lintSpec(md, "", {reason:true});
  assert.strictEqual(r.reqs.map(q => q.id).join(","), "FR-001,NFR-001");
  assert(!/次回の打合せ/.test(md)); assert(/理由・意図：費用のため/.test(md));
});
t("AIへの依頼文：発言にないことを補わない・作業の約束を除く・伏せる", () => {
  const p = S.minutesPrompt({title:"T"});
  assert(/発言にないことを補わない/.test(p)); assert(/作業や日程の約束/.test(p)); assert(/伏せてから/.test(p));
});
t("版数は APP.version だけに書く", () => {
  const v = S.APP.version; assert(/^\d+\.\d+$/.test(v));
  const rest = html.replace(/<script id="articles"[\s\S]*?<\/script>/, "").replace(/<script id="samples"[\s\S]*?<\/script>/, "").replace('version:"' + v + '"', "");
  assert(!new RegExp("\\bv" + v.replace(".", "\\.") + "\\b|version:\"\\d+\\.\\d+\"").test(rest));
});
t("義務表現：濁音の形（〜んではならない／〜んでもよい）も認める", () => {
  ["読み込んではならない","読んでもよい","送信してはならない"].forEach(w => {
    const r = S.lintSpec("## FR-001 a\nシステムは、ファイルを"+w+"。\n- Given x / When y / Then z", "");
    assert(!r.findings.some(f => /義務表現/.test(f.message)), w);
  });
});

// ===== v1.5 ソース改修支援 =====
const CS = D.codeSample;
t("ソース：ファイルに分けて言語を判定する", () => {
  const f = S.splitSources(CS.source);
  assert.strictEqual(f.map(x => x.lang).join(","), "python,sql,html,js,css");
  assert.strictEqual(S.detectLang("a.txt", "def x():\n  pass"), "python");
  assert.strictEqual(S.detectLang("", "CREATE TABLE t (id INT);"), "sql");
});
t("ソース：関数の位置・長さ・引数・呼び出し関係", () => {
  const a = S.analyzeCode(CS.source), f = n => a.funcs.find(x => x.name === n);
  assert.strictEqual(f("load_answers").line, 4); assert.strictEqual(f("load_answers").end, 13);
  assert.strictEqual(f("list_answers").params, "db_path, question_id");
  assert.strictEqual(f("loadList").calls.join(), "renderList"); assert.strictEqual(f("renderList").callers.join(), "loadList");
});
t("ソース：セキュリティと整合の指摘（SQL連結・XSS・存在しないID・except:）", () => {
  const msg = S.analyzeCode(CS.source).findings.map(x => x.level + " " + x.file + ":" + x.line + " " + x.msg).join("\n");
  assert(/高 app\/survey.py:19 SQLを文字列の連結/.test(msg)); assert(/高 app.js:10 innerHTML/.test(msg));
  assert(/#count がHTMLにない/.test(msg)); assert(/except:/.test(msg)); assert(/\.old-banner/.test(msg));
  assert(!/\.answer-list がHTML/.test(msg), "使われているクラスを未使用と言わない");
});
t("ソース：JSの文字列・コメントの中の { } や関数風の文字を数えない", () => {
  const a = S.analyzeCode("=== ファイル: a.js ===\nfunction a() {\n  const s = '}{ function fake() {';\n  // function b() {\n  return 1;\n}\nfunction c() { return a(); }");
  assert.strictEqual(a.funcs.map(f => f.name).join(","), "a,c"); assert.strictEqual(a.funcs[0].end, 5); assert.strictEqual(a.funcs[1].calls.join(), "a");
});
t("ソース：長い関数・分岐の多い関数に印を付ける", () => {
  const body = Array.from({length: 60}, (_, i) => "    if x == " + i + ":\n        y = " + i).join("\n");
  const a = S.analyzeCode("=== ファイル: big.py ===\ndef big(x):\n" + body + "\n    return y\n");
  const msg = a.findings.map(f => f.level + f.msg).join("\n");
  assert(/高関数 big が 1\d\d 行/.test(msg)); assert(/高関数 big の分岐の目安が 61/.test(msg));
});
t("テーブル：主キー・外部キー・インデックス・型の点検", () => {
  const a = S.analyzeCode(CS.source), msg = a.findings.filter(f => f.kind === "DB設計").map(f => f.level + f.msg).join("\n");
  assert(/中answers.created_at が文字列型/.test(msg)); assert(/中answers.question_id（外部キー）にインデックスがない/.test(msg));
  const b = S.analyzeCode("=== ファイル: s.sql ===\nCREATE TABLE orders (\n  price FLOAT,\n  user_id INT\n);\nCREATE INDEX idx_o ON orders (user_id);");
  const m2 = b.findings.map(f => f.level + f.msg).join("\n");
  assert(/高テーブル「orders」に主キーがない/.test(m2)); assert(/高orders.price が浮動小数点型/.test(m2));
  assert.strictEqual(S.parseSchema("CREATE TABLE t (id INT, a INT, PRIMARY KEY (id), FOREIGN KEY (a) REFERENCES u(id));").tables[0].fks[0].ref, "u");
});
t("既存の書き方：言語ごとのインデント・引用符・関数名を数える", () => {
  const r = S.detectConventions(CS.source).rules, g = k => (r.find(x => x.item === k) || {}).value;
  assert.strictEqual(g("インデント（Python）"), "空白4つ"); assert.strictEqual(g("インデント（JS）"), "空白2つ");
  assert(/単一引用符/.test(g("JSの引用符"))); assert(/snake_case/.test(g("関数名"))); assert(/f-string/.test(g("Pythonの文字列の組み立て")));
});
t("エラー：Pythonのトレースバックから場所・関数・仮説3つ", () => {
  const a = S.analyzeCode(CS.source), r = S.errorReport(CS.error, a);
  assert.strictEqual(r.at.file, "app/survey.py"); assert.strictEqual(r.at.line, 9);
  assert(/load_answers（4〜13行目/.test(r.md)); assert(/辞書に、そのキーがない/.test(r.md)); assert((r.md.match(/\| H\d \|/g) || []).length === 3);
  assert(/まだ修正しない/.test(r.md)); assert(/デルタデバッグ/.test(r.md));
});
t("エラー：JSのスタックと、種類の判定", () => {
  const p = S.parseError("Uncaught TypeError: Cannot read properties of null (reading 'textContent')\n    at renderList (app.js:11:37)\n    at loadList (app.js:5:23)");
  assert.strictEqual(p.frames[0].file, "app.js"); assert.strictEqual(p.frames[0].line, 11);
  assert(p.kinds.some(k => /null／undefined/.test(k.type)));
  assert(S.parseError("sqlite3.OperationalError: no such column: instructor").kinds.some(k => k.type === "列がない"));
  assert(/貼ると/.test(S.errorReport("", null).md));
});
t("DB変更：名前の変更は段階的（追加→コピー→切り替え→削除）。DBMSごとの書き方", () => {
  const a = S.analyzeCode(CS.source);
  const p = S.dbChangePlan({op:"rename_column", dbms:"sqlite", table:"answers", column:"body", newName:"answer_text"}, a.schema, a);
  assert.strictEqual(p.steps.length, 6); assert(/ADD COLUMN answer_text TEXT/.test(p.md)); assert(/answer_text IS NOT body/.test(p.md));
  assert(p.md.indexOf("ADD COLUMN") < p.md.indexOf("DROP COLUMN body"));
  assert(/CONCURRENTLY/.test(S.dbChangePlan({op:"add_index", dbms:"postgresql", table:"answers", column:"question_id"}, a.schema, a).md));
  assert(/ALGORITHM=INPLACE/.test(S.dbChangePlan({op:"add_index", dbms:"mysql", table:"answers", column:"question_id"}, a.schema, a).md));
  assert(/作り直す/.test(S.dbChangePlan({op:"add_not_null", dbms:"sqlite", table:"answers", column:"body"}, a.schema, a).md));
  assert(/列「nope」はテーブル「answers」にありません/.test(S.dbChangePlan({op:"drop_column", table:"answers", column:"nope"}, a.schema, a).warnings.join()));
});
t("DB変更：列の削除はコードの参照を探す（HTMLの <body> タグは数えない）", () => {
  const a = S.analyzeCode(CS.source), p = S.dbChangePlan({op:"drop_column", dbms:"postgresql", table:"answers", column:"body", sourceText:CS.source}, a.schema, a);
  assert(p.refs.some(r => /^app\/survey.py:19/.test(r))); assert(p.refs.some(r => /^app.js:10/.test(r))); assert(!p.refs.some(r => /index.html/.test(r)));
});
t("差分の点検：テストの期待値変更・引数の追加・名前変更・新しい依存", () => {
  const a = S.analyzeCode(CS.source), r = S.checkDiff(CS.diff, {conventions:S.detectConventions(CS.source), analysis:a, constraints:{}});
  const msg = r.findings.map(f => f.level + f.rule + " " + f.msg).join("\n");
  assert(/高tests テストのアサーションを 1 行/.test(msg)); assert(/高api 関数 list_answers の引数を変えている.*既定値のない引数/.test(msg));
  assert(/高db 名前の変更を含む/.test(msg)); assert(/中deps 新しい依存（pandas）/.test(msg));
  const off = S.checkDiff(CS.diff, {conventions:S.detectConventions(CS.source), analysis:a, constraints:{deps:false, db:false}});
  assert(!off.findings.some(f => f.rule === "deps" || f.rule === "db"));
});
t("差分の点検：既定値つきの引数の追加は中、秘密情報は伏せて表示", () => {
  const d = "--- a/x.py\n+++ b/x.py\n-def f(a):\n+def f(a, b=None):\n+API_KEY = \"sk-abcdefghijklmnopqrstu\"\n--- a/tests/test_x.py\n+++ b/tests/test_x.py\n+    assert f(1) == 1";
  const r = S.checkDiff(d, {constraints:{}}), m = r.findings.map(f => f.level + f.rule + f.msg).join("\n");
  assert(/中api関数 f の引数/.test(m)); assert(/高secret/.test(m)); assert(!/sk-abcdefghijklmnopqrstu/.test(m));
});
t("影響範囲・質問・工数（PERT）", () => {
  const a = S.analyzeCode(CS.source), imp = S.impactOf(CS.request, a);
  assert(imp.tables.some(x => x.name === "answers"));
  const qs = S.clarifyQuestions(CS.request, a, {db:true});
  assert(qs.some(q => /いい感じ/.test(q.q))); assert(qs.some(q => /速く/.test(q.q))); assert(qs.some(q => /止められますか/.test(q.q)));
  const tk = S.estimate({impacted:2, loc:40, dbSteps:6, questions:5}), tot = S.pertTotals(tk);
  assert(tk.some(x => x.id === "T4" && x.pri === "必須")); assert(tk.every(x => x.o <= x.m && x.m <= x.p));
  const one = [{o:2, m:4, p:12}]; assert.strictEqual(S.pertTotals(one).e, 5); assert.strictEqual(S.pertTotals(one).sd, 1.7);
  assert(!S.estimate({impacted:1, loc:10, dbSteps:0}).some(x => x.id === "T4"));
});
t("改修仕様書：12の章、制約・既存の書き方・工数・質問・根拠が入り、仕様チェッカーで高の指摘なし", () => {
  const a = S.analyzeCode(CS.source), imp = S.impactOf(CS.request, a), conv = S.detectConventions(CS.source), qs = S.clarifyQuestions(CS.request, a, {});
  const tk = S.estimate({impacted:3, loc:30}); S.pertTotals(tk);
  const md = S.codeSpecMd({request:CS.request, analysis:a, impact:imp, conventions:conv, questions:qs, tasks:tk, constraints:{deps:false}, extraConstraints:"帳票の列の順番は変えない"});
  for (let i = 1; i <= 12; i++) assert(new RegExp("## " + i + "\\. ").test(md), "章 " + i);
  assert(/帳票の列の順番は変えない/.test(md)); assert(!/新しいライブラリ・外部サービスを足さない/.test(md));
  assert(/Karlsson/.test(md) && /Malcolm/.test(md)); assert(/インデント（Python）/.test(md));
  assert(!S.lintSpec(md, "", {reason:true}).findings.some(f => f.level === "高" && !/要求/.test(f.message)));
});
t("依頼文：種類ごとに「まだ変更しない」と制約・既存の書き方を入れる", () => {
  const conv = S.detectConventions(CS.source);
  ["analyze", "plan", "error", "db", "review"].forEach(k => { const p = S.codePrompt(k, {request:"x", conventions:conv, constraints:{}}); assert(/既存のテストの期待値/.test(p), k); assert(/インデント/.test(p), k); });
  assert(/まだ修正はしないでください/.test(S.codePrompt("error", {error:"KeyError"}))); assert(/手順1」だけ/.test(S.codePrompt("implement", {})));
});
t("根拠：査読論文と書籍を分け、全ステップの根拠が文献一覧にある", () => {
  const refs = S.CODE_REFS; assert(Object.keys(refs).filter(k => refs[k].peer).length >= 18); assert(Object.keys(refs).filter(k => !refs[k].peer).every(k => /書籍/.test(refs[k].cite)));
  S.CODE_STEPS.forEach(s => s.refs.forEach(r => assert(refs[r], r)));
});
t("大きな入力でも止まらない（約1万行）", () => {
  const big = "=== ファイル: big.js ===\n" + Array.from({length: 2000}, (_, i) => "function f" + i + "(a) {\n  if (a) { return f" + (i + 1) + "(a - 1); }\n  return 0;\n}\n").join("");
  const t0 = Date.now(); const a = S.analyzeCode(big); S.detectConventions(big);
  assert.strictEqual(a.funcs.length, 2000); assert(Date.now() - t0 < 8000, "遅すぎる：" + (Date.now() - t0) + "ms");
});

// ===== v1.5 スパルタレビューで見つけた不具合の回帰テスト =====
t("Python：r\"\"\" などの接頭辞つき文字列の後ろの関数を見落とさない", () => {
  const src = "\nr\"\"\"\nmodule doc with ' and \"\n\"\"\"\nimport re\n\ndef a(x):\n    return rb'\\\\'  # comment \"\"\"\n\ndef b(\n        y,\n        z=1,\n):\n    s = f\"{y!r}\"\n    return s\n";
  const a = S.analyzeCode("=== ファイル: m.py ===\n" + src), f = a.funcs.map(x => x.name + "@" + x.line + "(" + x.params + ")").join(" ");
  assert.strictEqual(f, "a@7(x) b@10(y, z=1)");
});
t("先頭の空行を消さない（行番号がずれない）", () => {
  const a = S.analyzeCode("=== ファイル: m.py ===\n\n\ndef a():\n    pass\n");
  assert.strictEqual(a.funcs[0].line, 3);
});
t("JS：正規表現リテラル・テンプレート文字列の中で構造を見誤らない", () => {
  const src = "const re = /['\"{]/g;\nconst t = `a ${ {k: 1}.k } }{ ${fn(`x${'}'}`)}`;\nfunction a() {\n  return re.test(t);\n}\nfunction b() { return '/*'; }\nfunction c() { return 1; }";
  const a = S.analyzeCode("=== ファイル: m.js ===\n" + src);
  assert.strictEqual(a.funcs.map(f => f.name + "@" + f.line + "-" + f.end).join(" "), "a@3-5 b@6-6 c@7-7");
});
t("JS：クラスの static・async・# メソッド、オブジェクトの関数プロパティ、行番号は名前の行", () => {
  const src = "class K {\n  /**\n   * doc\n   */\n  static make(a) { return new K(); }\n  async load() {\n    return 1;\n  }\n  #hidden(x) { return x; }\n}\nconst o = {\n  run: function (n) { return n; },\n  go: (m) => m * 2,\n  'quoted': async () => 0\n};\nmodule.exports.helper = function (h) { return h; };";
  const a = S.analyzeCode("=== ファイル: k.js ===\n" + src), got = a.funcs.map(f => f.name + "@" + f.line).join(" ");
  assert.strictEqual(got, "make@5 load@6 #hidden@9 run@12 go@13 quoted@14 helper@16");
});
t("エラー：長い入力は末尾1万字だけ見る（極端な入力でも1秒以内）", () => {
  const t0 = Date.now(); const r = S.parseError("\"" + "\\".repeat(200000) + "\nKeyError: 'x'");
  assert(Date.now() - t0 < 1000, "遅い"); assert(/KeyError/.test(r.message));
});
t("既存の書き方：解析結果を受け取れる（同じソースを2回解析しない）", () => {
  const a = S.analyzeCode(CS.source); assert.strictEqual(JSON.stringify(S.detectConventions(CS.source, a).rules), JSON.stringify(S.detectConventions(CS.source).rules));
});
t("更新履歴は APP.history から作る（版の直書きなし）", () => {
  assert(S.APP.history.length >= 3); assert.strictEqual(S.APP.history[0][0], S.APP.version);
});
console.log("OK " + n + " tests");
