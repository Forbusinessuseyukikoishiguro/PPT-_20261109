#!/usr/bin/env python3
"""PPTX の「微調整」を機械で揃える。文字には一切触れない（verify_text.py で再確認できる）。

  python polish.py deck.pptx -o deck.pptx [--plan plan.json] [--only indent,grid,align,icons,table,title]
                   [--icon-color 0E6464] [--report polish.json]

このスキルで作ったデッキにも、人が作った既存の PPTX にも使える（--plan が無ければ値を推定）。

やること（--only で選べる。既定は全部）
  sanitize  段落の途中に紛れた <a:pPr> を除く（pptxgenjs の癖。残すと箇条書き記号が消える）
  indent    箇条書きのインデントを階層ごとに統一（左余白 = 記号幅 + 階層×段差、ぶら下げ = 記号幅）
            記号も階層ごとに統一（● – ・）、記号の色と大きさを揃える
  grid      位置と大きさを 0.05in の格子に吸着（アイコンは後で中心合わせ）
  align     左端・上端がわずかにずれた図形を揃える／同じ大きさのカードが3つ以上並ぶ行は間隔を均等に
  icons     アイコンの大きさを役割ごとに統一し、丸の中心に置き直す。行頭アイコンは1行目の文字の中心に合わせる
            --icon-color を付けるとアイコンの色も1色に塗り直す
  table     表のセル余白を統一、数値の列は右揃え、見出し行は太字
  title     同じ種類のスライドのタイトル位置・大きさをそろえる
"""
import argparse, copy, io, json, re
from collections import Counter, defaultdict
from pathlib import Path
from pptx import Presentation
from pptx.util import Emu
from lxml import etree

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS = {"a": A}
IN = 914400
q = lambda t: f"{{{A}}}{t}"
BUL = ["●", "–", "・"]


def emu(i):
    return int(round(i * IN))


class Log:
    def __init__(self):
        self.c = Counter(); self.items = []

    def add(self, op, msg=None):
        self.c[op] += 1
        if msg and len(self.items) < 400:
            self.items.append(f"[{op}] {msg}")


def cluster(vals, tol):
    """近い値をまとめて、各値 → 代表値（最頻値、同数なら小さい方）"""
    vals = sorted(vals)
    groups, cur = [], []
    for v in vals:
        if cur and v - cur[-1] > tol:
            groups.append(cur); cur = []
        cur.append(v)
    if cur:
        groups.append(cur)
    m = {}
    for g in groups:
        rep = Counter(g).most_common()
        top = max(c for _, c in rep)
        r = min(v for v, c in rep if c == top)
        for v in g:
            m[v] = r
    return m


def sanitize(prs, log):
    for si, s in enumerate(prs.slides, 1):
        for p in s._element.iter(q("p")):
            kids = list(p)
            for k in kids[1:]:
                if k.tag == q("pPr"):
                    p.remove(k); log.add("sanitize")
            if kids and kids[0].tag != q("pPr"):
                pp = p.find(q("pPr"))
                if pp is not None and p.index(pp) != 0:
                    p.remove(pp); p.insert(0, pp)


def indent(prs, log, grid, primary, BUL=BUL):
    hang, step = emu(grid["bulletHang"]), emu(grid["indentStep"])
    for si, s in enumerate(prs.slides, 1):
        for sh in s.shapes:
            if not sh.has_text_frame:
                continue
            for p in sh.text_frame._txBody.iter(q("p")):
                pPr = p.find(q("pPr"))
                if pPr is None:
                    continue
                bu = pPr.find(q("buChar")) if pPr.find(q("buChar")) is not None else pPr.find(q("buAutoNum"))
                if bu is None:
                    # 記号なし段落：インデントの残りかすを 0 に
                    for k in ("marL", "indent"):
                        if pPr.get(k) not in (None, "0"):
                            pPr.set(k, "0"); log.add("indent", f"slide{si} {sh.name}: 記号なし段落の {k} を0に")
                    continue
                lvl = int(pPr.get("lvl", "0"))
                marL, ind = str(hang + lvl * step), str(-hang)
                if pPr.get("marL") != marL or pPr.get("indent") != ind:
                    log.add("indent", f"slide{si} {sh.name}: L{lvl} marL {pPr.get('marL')}→{marL}")
                    pPr.set("marL", marL); pPr.set("indent", ind)
                # 記号の色・大きさ・字形を階層ごとに統一
                for t in ("buClr", "buSzPct", "buSzPts", "buFont"):
                    e = pPr.find(q(t))
                    if e is not None:
                        pPr.remove(e)
                pos = list(pPr).index(bu)
                clr = etree.Element(q("buClr")); sc = etree.SubElement(clr, q("srgbClr")); sc.set("val", primary)
                sz = etree.Element(q("buSzPct")); sz.set("val", "85000" if bu.tag == q("buChar") else "100000")
                pPr.insert(pos, clr); pPr.insert(pos + 1, sz)
                if bu.tag == q("buChar") and bu.get("char") != BUL[min(lvl, 2)]:
                    bu.set("char", BUL[min(lvl, 2)]); log.add("indent", f"slide{si}: L{lvl} の記号を {BUL[min(lvl,2)]} に統一")


def kind(sh):
    n = sh.name or ""
    if n.startswith("icon:"):
        return "icon"
    if n.startswith("iconbg:"):
        return "iconbg"
    if n.startswith(("deco:", "logo:", "photo:")):
        return "deco"
    if n.startswith("meta:"):
        return "meta"
    if sh.shape_type == 13 and sh.width < emu(1.3) and abs(sh.width - sh.height) < emu(0.08):
        return "icon"  # 既存デッキの小さい正方形画像はアイコン扱い
    return "box"


def grid_snap(prs, log, unit):
    u = emu(unit)
    for si, s in enumerate(prs.slides, 1):
        for sh in s.shapes:
            if kind(sh) in ("icon", "deco"):
                continue
            for attr in (("left", "top") if kind(sh) == "iconbg" else ("left", "top", "width", "height")):
                v = getattr(sh, attr)
                if v is None:
                    continue
                nv = int(round(v / u) * u)
                if attr in ("width", "height") and nv == 0 and v > 0:
                    nv = v
                if abs(nv - v) > 600:  # 0.0007in 以上ずれていたら
                    setattr(sh, attr, Emu(nv)); log.add("grid")


def align(prs, log, tol_in=0.12):
    tol = emu(tol_in)
    for si, s in enumerate(prs.slides, 1):
        shapes = [sh for sh in s.shapes if kind(sh) in ("box", "iconbg", "icon") and sh.left is not None]
        # 左端
        m = cluster([sh.left for sh in shapes], tol)
        for sh in [x for x in shapes if kind(x) in ("box", "icon")]:
            if m[sh.left] != sh.left:
                log.add("align", f"slide{si} {sh.name}: 左端 {sh.left/IN:.2f}→{m[sh.left]/IN:.2f}in")
                dx = m[sh.left] - sh.left
                sh.left = Emu(m[sh.left])
                if kind(sh) == "box" and sh.width and sh.has_text_frame:
                    sh.width = Emu(sh.width - dx)  # 文字の右端は動かさない
        # 上端（同じ行・ほぼ同じ高さの図形どうしだけ。高さの違う丸と文字は中心で合わせるので対象外）
        boxes = [sh for sh in shapes if kind(sh) == "box" and sh.height]
        m = {}
        hgroups = defaultdict(list)
        hm = cluster([sh.height for sh in boxes], emu(0.25))
        for sh in boxes:
            hgroups[hm[sh.height]].append(sh)
        for grp in hgroups.values():
            m.update({id(sh): v for sh, v in ((sh, cluster([x.top for x in grp], tol)[sh.top]) for sh in grp)})
        for sh in boxes:
            if m[id(sh)] != sh.top:
                log.add("align", f"slide{si} {sh.name}: 上端 {sh.top/IN:.2f}→{m[id(sh)]/IN:.2f}in")
                sh.top = Emu(m[id(sh)])
        # 同じ大きさのカードが3つ以上並ぶ行 → 間隔を均等に
        rows = defaultdict(list)
        for sh in shapes:
            if (sh.name or "").startswith("panel:card") or (kind(sh) == "box" and sh.shape_type == 1):
                rows[(sh.top, round(sh.width / emu(0.1)), round(sh.height / emu(0.1)))].append(sh)
        for key, row in rows.items():
            if len(row) < 3:
                continue
            row.sort(key=lambda x: x.left)
            span = row[-1].left + row[-1].width - row[0].left
            gap = (span - sum(r.width for r in row)) / (len(row) - 1)
            x = row[0].left
            for r in row:
                if abs(r.left - x) > 2000:
                    # カードの中身（同じ範囲にある図形）も一緒に動かす
                    dx = int(x - r.left)
                    for other in s.shapes:
                        if other is not r and other.left is not None and r.left <= other.left < r.left + r.width and r.top <= other.top < r.top + r.height:
                            other.left = Emu(other.left + dx)
                    r.left = Emu(int(x)); log.add("align", f"slide{si}: カード間隔を均等化")
                x += r.width + gap


def first_line_center(sh):
    sz = 1800
    for r in sh.text_frame._txBody.iter(q("rPr")):
        if r.get("sz"):
            sz = int(r.get("sz")); break
    lh = sz / 100 * 1.2 * 1.1 / 72
    return sh.top + emu(lh / 2)


def icons(prs, log, color=None):
    # 役割 = 丸の大きさ（直径を0.05in単位で丸める）。役割ごとに丸・アイコンの大きさを統一。
    pairs = []
    for si, s in enumerate(prs.slides):
        bgs = [sh for sh in s.shapes if kind(sh) == "iconbg"]
        for ic in [sh for sh in s.shapes if kind(sh) == "icon"]:
            cx, cy = ic.left + ic.width / 2, ic.top + ic.height / 2
            host = None
            for b in bgs:
                if b.left <= cx <= b.left + b.width and b.top <= cy <= b.top + b.height:
                    host = b; break
            pairs.append((si, ic, host))
    roles = defaultdict(list)
    loose = cluster([ic.width for _, ic, h in pairs if h is None], emu(0.2))  # 丸の無いアイコン：近い大きさは同じ役割
    for si, ic, host in pairs:
        key = ("c", round(host.width / emu(0.05))) if host else ("free", loose[ic.width])
        roles[key].append((si, ic, host))
    for key, items in roles.items():
        # 丸の直径：同じ役割なら完全に同じ値に
        if items[0][2] is not None:
            d = Counter(h.width for _, _, h in items if h).most_common(1)[0][0]
            for si, ic, h in items:
                if h and (h.width != d or h.height != d):
                    cx, cy = h.left + h.width / 2, h.top + h.height / 2
                    h.width = h.height = Emu(d); h.left = Emu(int(cx - d / 2)); h.top = Emu(int(cy - d / 2))
                    log.add("icons", f"slide{si+1}: 丸の直径を統一")
        isz = Counter(ic.width for _, ic, _ in items).most_common(1)[0][0]
        for si, ic, h in items:
            if ic.width != isz or ic.height != isz:
                log.add("icons", f"slide{si+1} {ic.name}: 大きさ {ic.width/IN:.2f}→{isz/IN:.2f}in")
                cx, cy = ic.left + ic.width / 2, ic.top + ic.height / 2
                ic.width = ic.height = Emu(isz)
                if h is None:  # 左端は保ち、縦は中心を保つ
                    ic.top = Emu(int(cy - isz / 2))
            if h is not None:
                nx = int(h.left + (h.width - isz) / 2); ny = int(h.top + (h.height - isz) / 2)
                if abs(ic.left - nx) > 6000 or abs(ic.top - ny) > 6000:
                    log.add("icons", f"slide{si+1} {ic.name}: 丸の中心へ")
                ic.left, ic.top = Emu(nx), Emu(ny)
    # 行頭アイコン：右隣の文字の1行目の中心に合わせる（タイトル・カード上のアイコンは対象外）
    for si, s in enumerate(prs.slides):
        texts = [sh for sh in s.shapes if sh.has_text_frame and (sh.name or "").startswith("src:")]
        for b in [sh for sh in s.shapes if kind(sh) == "iconbg" and "-r" in (sh.name or "")]:
            right = [t for t in texts if 0 <= t.left - (b.left + b.width) <= emu(0.6) and abs(t.top - b.top) < emu(0.5)]
            if not right:
                continue
            t = min(right, key=lambda t: t.left)
            target = first_line_center(t) - b.height / 2
            if abs(b.top - target) > 3000:
                dy = int(target - b.top)
                b.top = Emu(int(target))
                for ic in s.shapes:
                    if kind(ic) == "icon" and b.left <= ic.left + ic.width / 2 <= b.left + b.width and abs(ic.top + ic.height / 2 - (b.top - dy + b.height / 2)) < b.height:
                        ic.top = Emu(ic.top + dy)
                log.add("icons", f"slide{si+1}: 行頭アイコンを1行目の中心に")
    for si, s in enumerate(prs.slides):
        texts = [sh for sh in s.shapes if sh.has_text_frame and sh.text_frame.text.strip() and not (sh.name or "").startswith("meta:")]
        bgs = [sh for sh in s.shapes if kind(sh) == "iconbg"]
        for ic in [sh for sh in s.shapes if kind(sh) == "icon"]:
            cx, cy = ic.left + ic.width / 2, ic.top + ic.height / 2
            if any(b.left <= cx <= b.left + b.width and b.top <= cy <= b.top + b.height for b in bgs):
                continue
            right = [t for t in texts if 0 <= t.left - (ic.left + ic.width) <= emu(0.8) and abs(t.top - ic.top) < emu(0.5)]
            if not right:
                continue
            t = min(right, key=lambda t: t.left)
            target = int(first_line_center(t) - ic.height / 2)
            if abs(ic.top - target) > 3000:
                ic.top = Emu(target); log.add("icons", f"slide{si+1} {ic.name}: 右の文字の1行目の中心に合わせた")
    if color:
        recolor(prs, log, color)


def recolor(prs, log, hexc):
    from PIL import Image
    rgb = tuple(int(hexc[i:i + 2], 16) for i in (0, 2, 4))
    for si, s in enumerate(prs.slides, 1):
        for sh in list(s.shapes):
            if kind(sh) != "icon" or sh.shape_type != 13:
                continue
            # 丸の上のアイコン（白抜き）は塗り直さない
            if any(kind(b) == "iconbg" and b.left <= sh.left + sh.width / 2 <= b.left + b.width and b.top <= sh.top + sh.height / 2 <= b.top + b.height for b in s.shapes):
                continue
            im = Image.open(io.BytesIO(sh.image.blob)).convert("RGBA")
            alpha = im.split()[3]
            out = Image.new("RGBA", im.size, rgb + (0,)); out.putalpha(alpha)
            bio = io.BytesIO(); out.save(bio, "PNG"); bio.seek(0)
            pic = s.shapes.add_picture(bio, sh.left, sh.top, sh.width, sh.height)
            pic.name = sh.name
            old = sh._element; old.addprevious(pic._element); old.getparent().remove(old)
            log.add("icons", f"slide{si}: アイコンの色を {hexc} に")


NUM = re.compile(r"^[\s¥$€￥+\-−]?[\d,.]+\s*(%|円|件|名|人|時間|分|日|h|ms|GB|MB)?$")


def tables(prs, log):
    for si, s in enumerate(prs.slides, 1):
        for sh in s.shapes:
            if not getattr(sh, "has_table", False) or not sh.has_table:
                continue
            t = sh.table
            nr, nc = len(t.rows), len(t.columns)
            for c in range(nc):
                vals = [t.cell(r, c).text.strip() for r in range(1, nr)]
                numeric = vals and all((not v) or NUM.match(v) for v in vals)
                for r in range(nr):
                    cell = t.cell(r, c)
                    for k, v in (("marL", 0.1), ("marR", 0.1), ("marT", 0.06), ("marB", 0.06)):
                        tcPr = cell._tc.get_or_add_tcPr()
                        if tcPr.get(k) != str(emu(v)):
                            tcPr.set(k, str(emu(v))); log.add("table")
                    if r > 0 and numeric:
                        for p in cell.text_frame.paragraphs:
                            pPr = p._p.get_or_add_pPr()
                            if pPr.get("algn") != "r":
                                pPr.set("algn", "r"); log.add("table", f"slide{si}: 数値の列{c}を右揃え")
                    if r == 0:
                        for p in cell.text_frame.paragraphs:
                            for run in p.runs:
                                if not run.font.bold:
                                    run.font.bold = True; log.add("table", f"slide{si}: 見出し行を太字")


def titles(prs, log):
    # タイトル = src:/rep: で上端が 1.3in より上にある文字図形（既存デッキは title プレースホルダ）
    found = []
    for si, s in enumerate(prs.slides):
        for sh in s.shapes:
            n = sh.name or ""
            is_t = (sh.is_placeholder and sh.placeholder_format.type in (1, 3)) or \
                   ((n.startswith("src:") or n.startswith("rep:")) and sh.top is not None and sh.top < emu(1.3) and sh.has_text_frame)
            if is_t:
                found.append((si, sh))
        if not any(f[0] == si for f in found):
            # 名前の無い既存デッキ：上部 1.3in 以内で一番大きい文字の図形をタイトルとみなす
            cand = []
            for sh in s.shapes:
                if sh.has_text_frame and sh.text_frame.text.strip() and sh.top is not None and sh.top < emu(1.3) and not (sh.name or "").startswith("meta:"):
                    szs = [r.font.size.pt for p in sh.text_frame.paragraphs for r in p.runs if r.font.size]
                    cand.append((max(szs) if szs else 18, sh))
            if cand:
                found.append((si, max(cand, key=lambda c: c[0])[1]))
    if len(found) < 3:
        return
    for attr in ("left", "top", "width", "height"):
        mode = Counter(getattr(sh, attr) for _, sh in found).most_common(1)[0][0]
        for si, sh in found:
            v = getattr(sh, attr)
            if v != mode and abs(v - mode) < emu(0.5):
                setattr(sh, attr, Emu(mode)); log.add("title", f"slide{si+1}: タイトル {attr} を統一")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--plan", default=None)
    ap.add_argument("--only", default="sanitize,indent,grid,align,icons,table,title")
    ap.add_argument("--icon-color", default=None)
    ap.add_argument("--report", default=None)
    a = ap.parse_args()
    prof = json.loads((Path(__file__).resolve().parent.parent / "assets" / "profiles.json").read_text(encoding="utf-8"))
    grid, primary = prof["grid"], None
    if a.plan:
        pl = json.loads(Path(a.plan).read_text(encoding="utf-8"))
        grid = pl["profile"]["grid"]; primary = pl["profile"]["palette"]["primary"]
        bullets = pl["profile"].get("bullets")
    bullets = locals().get("bullets") or BUL
    prs = Presentation(a.deck)
    if primary is None:  # 既存デッキ：最も多い塗り色を主色とみなす
        cnt = Counter()
        for s in prs.slides:
            for e in s._element.iter(q("srgbClr")):
                v = e.get("val", "").upper()
                if v not in ("FFFFFF", "000000") and e.getparent().tag == q("solidFill") and e.getparent().getparent().tag.endswith("spPr"):
                    cnt[v] += 1
        primary = cnt.most_common(1)[0][0] if cnt else "333333"
    ops = set(a.only.split(","))
    log = Log()
    if "sanitize" in ops: sanitize(prs, log)
    if "indent" in ops: indent(prs, log, grid, primary, bullets)
    if "grid" in ops: grid_snap(prs, log, grid["unit"])
    if "align" in ops: align(prs, log)
    if "title" in ops: titles(prs, log)
    if "icons" in ops: icons(prs, log, a.icon_color)
    if "table" in ops: tables(prs, log)
    out = a.out or a.deck
    prs.save(out)
    print(f"[polish] -> {out}  " + "  ".join(f"{k}:{v}" for k, v in sorted(log.c.items())) if log.c else f"[polish] -> {out}  変更なし")
    for it in log.items[:30]:
        print("  ", it)
    if len(log.items) > 30:
        print(f"   …ほか {len(log.items)-30} 件（--report で全件）")
    if a.report:
        Path(a.report).write_text(json.dumps({"counts": log.c, "changes": log.items}, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
