#!/usr/bin/env python3
"""デザインの点検（人の目の前に機械で落とせる不具合を落とす）。文字は読むだけで変えない。

  python check_design.py deck.pptx [--plan plan.json] [--report design.json]

項目と基準（根拠は references/*.md）
  contrast   文字と背景のコントラスト比。本文 4.5:1 以上、大きい文字（18pt以上 / 14pt以上の太字）3:1 以上（WCAG 2.2 1.4.3）
  icon-contrast  アイコンの丸と背景 3:1 以上（WCAG 2.2 1.4.11 非テキスト）
  size       本文の下限（plan があれば persona の下限、無ければ 14pt）。表は 12pt、ページ番号などは対象外
  margin     スライド端から 0.5in 以内に文字がない（装飾・全面背景・ページ番号は対象外）
  overlap    文字どうしが重なっていない
  align      1枚の中の左端の種類（少ないほど揃っている）、格子(0.05in)から外れた図形の数
  icons      アイコンの大きさ・丸の直径の種類（役割ごとに1種類が理想）
  color      デッキ全体の塗り色の種類（白・黒・グレー以外で 6 色以内）
  density    1枚あたりの文字数（plan があれば persona の上限と比較）
  title      タイトル位置のぶれ
"""
import argparse, json, re
from collections import Counter, defaultdict
from pathlib import Path
from pptx import Presentation

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
IN = 914400


def lum(hexc):
    def ch(v):
        v = v / 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hexc[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def ratio(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def solid(el):
    if el is None:
        return None
    sf = el.find(f"{A}solidFill")
    if sf is None:
        return None
    c = sf.find(f"{A}srgbClr")
    if c is None:
        return None
    alpha = c.find(f"{A}alpha")
    if alpha is not None and int(alpha.get("val", "100000")) < 50000:
        return None
    return c.get("val").upper()


def slide_bg(slide):
    bg = slide._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}bg")
    if bg is not None:
        c = bg.find(f".//{A}srgbClr")
        if c is not None:
            return c.get("val").upper()
    return "FFFFFF"


def icon_color(blob):
    from PIL import Image
    import io
    im = Image.open(io.BytesIO(blob)).convert("RGBA").resize((64, 64))
    raw = im.tobytes()
    px = [tuple(raw[i:i + 3]) for i in range(0, len(raw), 4) if raw[i + 3] > 200]
    if not px:
        return None
    r, g, b = (sum(c[i] for c in px) // len(px) for i in range(3))
    return f"{r:02X}{g:02X}{b:02X}"


def palette_check(profiles):
    """profiles.json の全ペルソナで、実際に使う色の組み合わせを WCAG で判定する。"""
    pairs = [("text", "bg", 4.5), ("text", "surface", 4.5), ("muted", "bg", 4.5), ("muted", "surface", 4.5),
             ("primary", "bg", 4.5), ("primary", "surface", 4.5), ("onPrimary", "primary", 4.5),
             ("onAccent", "accent", 3.0), ("codeText", "codeBg", 4.5), ("support", "primary", 3.0),
             ("primary", "support", 3.0), ("onPrimary", "primary", 3.0)]
    ok = True
    for pid, per in profiles["personas"].items():
        P = per["palette"]
        bad = [f"{a}/{b} {ratio(P[a], P[b]):.2f}<{n}" for a, b, n in pairs if ratio(P[a], P[b]) < n]
        print(f"  {pid:10s} {'OK ' if not bad else 'NG '} " + ("  ".join(bad) if bad else
              f"本文 {ratio(P['text'], P['bg']):.1f}:1 / 補足 {ratio(P['muted'], P['bg']):.1f}:1 / 主色上の白 {ratio(P['onPrimary'], P['primary']):.1f}:1"))
        ok = ok and not bad
    return ok


def box(sh):
    return (sh.left or 0, sh.top or 0, (sh.left or 0) + (sh.width or 0), (sh.top or 0) + (sh.height or 0))


def inside(pt, b):
    return b[0] <= pt[0] <= b[2] and b[1] <= pt[1] <= b[3]


def inter(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0]); h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0, w) * max(0, h)


def gray(h):
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return max(r, g, b) - min(r, g, b) < 18


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck", nargs="?"); ap.add_argument("--plan"); ap.add_argument("--report")
    ap.add_argument("--palettes", action="store_true", help="profiles.json の配色だけを判定する")
    a = ap.parse_args()
    if a.palettes or not a.deck:
        prof = json.loads((Path(__file__).resolve().parent.parent / "assets" / "profiles.json").read_text(encoding="utf-8"))
        print("[palette] WCAG 2.2 判定（本文 4.5:1・大きい文字/図形 3:1）")
        raise SystemExit(0 if palette_check(prof) else 1)
    prs = Presentation(a.deck)
    W, H = prs.slide_width, prs.slide_height
    floor, maxc = 14, None
    if a.plan:
        pl = json.loads(Path(a.plan).read_text(encoding="utf-8"))
        floor = pl["profile"]["density"]["floorPt"]; maxc = pl["profile"]["density"]["maxChars"]
    issues = defaultdict(list)
    fills = Counter(); icon_sizes = Counter(); circle_d = Counter(); titles = []
    stats = {"slides": len(prs.slides)}
    for si, s in enumerate(prs.slides, 1):
        bgc = slide_bg(s)
        shapes = list(s.shapes)
        filled = []
        for sh in shapes:
            if sh.has_text_frame or sh.shape_type in (1,):
                c = solid(sh._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}spPr"))
                if c:
                    filled.append((box(sh), c, sh))
                    if not gray(c):
                        fills[c] += 1
        lefts = set(); offgrid = 0; chars = 0
        texts = []
        for sh in shapes:
            n = sh.name or ""
            b = box(sh)
            if n.startswith("iconbg:"):
                circle_d[round(sh.width / IN, 2)] += 1
            if not n.startswith(("logo:", "photo:")) and (n.startswith("icon:") or (sh.shape_type == 13 and sh.width < 1.3 * IN)):
                icon_sizes[round(sh.width / IN, 2)] += 1
                # アイコンの線の色 と 下地（丸 → 塗り図形 → スライド背景）のコントラスト（WCAG 1.4.11 非テキスト 3:1）
                try:
                    fg = icon_color(sh.image.blob)
                except Exception:
                    fg = None
                if fg:
                    under = bgc
                    c0 = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
                    for fb, fc, fsh in sorted(filled, key=lambda t: (t[0][2] - t[0][0]) * (t[0][3] - t[0][1]), reverse=True):
                        if inside(c0, fb):
                            under = fc
                    for o in shapes:
                        if (o.name or "").startswith("iconbg:") and inside(c0, box(o)):
                            under = solid(o._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}spPr")) or under
                    if ratio(fg, under) < 3.0:
                        issues["icon-contrast"].append(f"slide{si} {n}: アイコン {fg} と下地 {under} = {ratio(fg, under):.2f}:1（3:1 未満）")
            if not n.startswith(("deco:", "icon:", "logo:", "photo:")) and not (sh.shape_type == 13 and sh.width < 1.3 * IN) and sh.left is not None:
                if round(sh.left / (0.05 * IN), 3) % 1 or round(sh.top / (0.05 * IN), 3) % 1:
                    offgrid += 1
            if getattr(sh, "has_table", False) and sh.has_table:
                for r in sh.table.rows:
                    for cell in r.cells:
                        cf = solid(cell._tc.find(f"{A}tcPr")) or bgc
                        for p in cell.text_frame.paragraphs:
                            for run in p.runs:
                                col = solid(run._r.find(f"{A}rPr")) or "000000"
                                pt = run.font.size.pt if run.font.size else 18
                                need = 3.0 if pt >= 18 or (pt >= 14 and run.font.bold) else 4.5
                                if run.text.strip() and ratio(col, cf) < need:
                                    issues["contrast"].append(f"slide{si} 表: 「{run.text[:12]}」{col} on {cf} = {ratio(col, cf):.2f}:1")
                                if run.text.strip() and pt < 12:
                                    issues["size"].append(f"slide{si} 表: {pt}pt（12pt 未満）")
                        chars += len(cell.text)
                lefts.add(sh.left)
                continue
            if not sh.has_text_frame or not sh.text_frame.text.strip():
                continue
            meta = n.startswith("meta:")
            if not meta:
                chars += len(sh.text_frame.text); lefts.add(sh.left); texts.append((b, sh))
                if n.startswith(("src:", "rep:")) and sh.top is not None and sh.top < 1.3 * IN:
                    titles.append((si, sh.left, sh.top))
            # 背景色：この図形の塗り → 下にある塗り図形（中心が入るもの） → スライド背景
            under = solid(sh._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}spPr"))
            if not under:
                under = bgc
                center = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
                for fb, fc, fsh in filled:
                    if fsh is not sh and inside(center, fb):
                        under = fc
            for p in sh.text_frame.paragraphs:
                for run in p.runs:
                    if not run.text.strip():
                        continue
                    col = solid(run._r.find(f"{A}rPr")) or "000000"
                    pt = run.font.size.pt if run.font.size else 18
                    big = pt >= 18 or (pt >= 14 and bool(run.font.bold))
                    need = 3.0 if big else 4.5
                    r = ratio(col, under)
                    if r < need:
                        issues["contrast"].append(f"slide{si} {n}: 「{run.text[:12]}」{col} on {under} = {r:.2f}:1（{need}:1 必要）")
                    lat = run._r.find(f"{A}rPr/{A}latin")
                    mono = lat is not None and re.search(r"UDゴシック|Mono|Courier|Consolas|ＭＳ ゴシック|MS ゴシック", lat.get("typeface", "")) and "UDP" not in lat.get("typeface", "")
                    lim = 12 if mono else floor
                    if not meta and pt < lim:
                        issues["size"].append(f"slide{si} {n}: 「{run.text[:12]}」{pt:g}pt（下限 {lim}pt）")
            if not meta:
                m = 0.5 * IN - 2000
                if b[0] < m or b[1] < m * 0.85 or W - b[2] < m or H - b[3] < m * 0.6:
                    issues["margin"].append(f"slide{si} {n}: 端に近い（{b[0]/IN:.2f},{b[1]/IN:.2f}〜{b[2]/IN:.2f},{b[3]/IN:.2f}in）")
        for i in range(len(texts)):
            for j in range(i + 1, len(texts)):
                ov = inter(texts[i][0], texts[j][0])
                if ov > 0.02 * IN * IN:
                    issues["overlap"].append(f"slide{si}: {texts[i][1].name} と {texts[j][1].name} が重なる")
        if len(lefts) > 6:
            issues["align"].append(f"slide{si}: 左端が {len(lefts)} 種類（揃える余地あり）")
        if offgrid:
            issues["align"].append(f"slide{si}: 格子から外れた図形 {offgrid} 個（polish.py の grid で直る）")
        if maxc and chars > maxc * 1.25:
            issues["density"].append(f"slide{si}: {chars} 字（目安 {maxc} 字の 1.25 倍超）")
    roles_icon = len(icon_sizes); roles_circle = len(circle_d)
    if roles_icon > 6:
        issues["icons"].append(f"アイコンの大きさが {roles_icon} 種類 {dict(icon_sizes)}")
    if roles_circle > 6:
        issues["icons"].append(f"丸の直径が {roles_circle} 種類 {dict(circle_d)}")
    if len(fills) > 6:
        issues["color"].append(f"有彩色の塗りが {len(fills)} 色 {dict(fills.most_common(10))}（6色以内に）")
    tpos = Counter((round(l / IN, 2), round(t / IN, 2)) for _, l, t in titles)
    if len(tpos) > 1:
        issues["title"].append(f"タイトル位置が {len(tpos)} 種類 {dict(tpos)}")
    order = ["contrast", "icon-contrast", "size", "overlap", "margin", "density", "align", "icons", "color", "title"]
    bad = sum(len(issues[k]) for k in order[:5])
    print(f"[design] {'PASS' if bad == 0 else 'NEEDS FIX'}  slides={stats['slides']}  " +
          "  ".join(f"{k}:{len(issues[k])}" for k in order))
    print(f"  アイコン寸法 {dict(icon_sizes)} / 丸の直径 {dict(circle_d)} / 有彩色 {len(fills)} 色")
    for k in order:
        for m in issues[k][:12]:
            print(f"  [{k}] {m}")
        if len(issues[k]) > 12:
            print(f"  [{k}] …ほか {len(issues[k]) - 12} 件")
    if a.report:
        Path(a.report).write_text(json.dumps(issues, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
