#!/usr/bin/env python3
"""source.json → plan.json。どのブロックをどのスライドに、どのレイアウトで置くかだけを決める。

  python plan_deck.py source.json --persona shinjin --purpose training -o plan.json

文字には触れない。長すぎる段落を分けるときは「。」「．」「. 」の直後だけで切り、
分けた部品をつなげると原文と一字一句同じになることをここで確認してから書き出す。

plan.json は人が直してよい（layout の差し替え、icon の差し替え、スライドの統合・分割）。
ただし runs / text は編集しない。verify_text.py が最後に照合する。
"""
import argparse, json, math, re, sys, unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROFILES = json.loads((HERE.parent / "assets" / "profiles.json").read_text(encoding="utf-8"))
ICONMAP = json.loads((HERE.parent / "assets" / "icon_keywords.json").read_text(encoding="utf-8"))


def units(s):
    u = 0.0
    for ch in s:
        if ch == "\n":
            continue
        w = unicodedata.east_asian_width(ch)
        u += 1.0 if w in ("W", "F") else (0.32 if ch == " " else 0.56)
    return u


def size(b):
    """スライドの埋まり具合の目安（全角換算の文字数）。"""
    if b["kind"] == "table":
        return sum(units(c) + 2 for r in b["rows"] for c in r)
    if b["kind"] == "code":
        return sum(max(units(l), 10) for l in b["text"].split("\n")) * 0.9
    return units(b["text"]) + 6 * b["text"].count("\n")


SENT = re.compile(r"(?<=[。．！？!?])|(?<=\. )")


def split_text(text, limit):
    """文末の直後だけで切る。つなげると原文と同一であることを保証。"""
    pieces = [p for p in SENT.split(text) if p != ""]
    parts, cur = [], ""
    for p in pieces:
        if cur and units(cur + p) > limit:
            parts.append(cur); cur = p
        else:
            cur += p
    if cur:
        parts.append(cur)
    assert "".join(parts) == text, "split changed text"
    return parts


def pick_icon(text, used, default):
    t = text.lower()
    best = None
    for icon, kws in ICONMAP["map"].items():
        for kw in kws:
            kl = kw.lower()
            if kl.isascii():
                mm = re.search(r"(?<![a-z0-9])" + re.escape(kl) + r"(?![a-z0-9])", t)
                pos = mm.start() if mm else -1
            else:
                pos = t.find(kl)
            if pos >= 0:
                if icon not in used and (best is None or pos < best[0]):
                    best = (pos, icon)
                break
    ic = best[1] if best else default
    used.add(ic)
    return ic


def chunks_of(items):
    """塊 = 第1階層の箇条書き1項目（子を含む）、段落1つ、表1つ、コード1つ。"""
    groups, cur = [], None
    for b in items:
        if b["kind"] == "li" and b.get("level", 0) > 0 and cur is not None and cur[0]["kind"] == "li":
            cur.append(b)
        else:
            cur = [b]; groups.append(cur)
    return groups


def choose_layout(groups, prof):
    kinds = [g[0]["kind"] for g in groups]
    flat = [b for g in groups for b in g]
    n = len(groups)
    if kinds == ["table"]:
        return "table"
    if "code" in kinds and all(k in ("code", "p") for k in kinds) and kinds.count("code") == 1:
        return "code"
    if all(k == "li" for k in kinds):
        gsz = [sum(units(b["text"]) for b in g) for g in groups]
        if all(g[0].get("ordered") for g in groups) and 3 <= n <= 6 and max(gsz) <= 70:
            return "steps"
        if 2 <= n <= 4 and max(gsz) <= 110:
            return "cards"
        if 5 <= n <= 6 and max(gsz) <= 46 and all(len(g) == 1 for g in groups):
            return "cards"
        return "list"
    if all(k in ("p", "quote") for k in kinds) and n <= 2 and sum(units(b["text"]) for b in flat) <= 150:
        return "statement"
    if kinds[0] in ("p", "quote") and "li" in kinds and all(k in ("p", "li", "quote") for k in kinds[1:]):
        return "split"
    return "list"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    ap.add_argument("--persona", default="shinjin", choices=list(PROFILES["personas"]))
    ap.add_argument("--purpose", default="training", choices=list(PROFILES["purposes"]))
    ap.add_argument("--no-sections", action="store_true", help="h2 を中扉にしない")
    ap.add_argument("--no-pageno", action="store_true", help="ページ番号（数字のみ）を付けない")
    ap.add_argument("--font", default=None, choices=[None, "meiryo", "yugothic", "noto"], help="フォント差し替え")
    ap.add_argument("--brand", default=None, help="会社独自デザインルール YAML（色・フォント・グリッド・記号を上書き）")
    ap.add_argument("-o", "--out", default="plan.json")
    a = ap.parse_args()

    src = json.loads(Path(a.source).read_text(encoding="utf-8"))
    blocks = src["blocks"]
    per = dict(PROFILES["personas"][a.persona])
    pur = PROFILES["purposes"][a.purpose]
    d = dict(per["density"])
    d["maxChars"] = int(d["maxChars"] * pur["charScale"])
    d["maxChunks"] = d["maxChunks"] + pur["chunkDelta"]
    d["bodyPt"] = d["bodyPt"] + pur["ptDelta"]
    d["floorPt"] = max(14, d["floorPt"] + min(0, pur["ptDelta"]))
    if a.purpose in ("handout", "review"):
        d["tableRows"] = int(d["tableRows"] * 1.5); d["codeLines"] = int(d["codeLines"] * 1.3)
    fonts = dict(PROFILES["fonts"])
    alt = {"meiryo": ("メイリオ", "メイリオ", "MS ゴシック"), "yugothic": ("游ゴシック", "游ゴシック", "BIZ UDゴシック"),
           "noto": ("Noto Sans CJK JP", "Noto Sans CJK JP", "Noto Sans Mono CJK JP")}
    if a.font:
        fonts["head"], fonts["body"], fonts["mono"] = alt[a.font]

    logo_reserve = None
    palette = dict(per["palette"]); grid = dict(PROFILES["grid"]); bullets = ["●", "–", "・"]; brand_name = None
    if a.brand:
        sys.path.insert(0, str(HERE))
        import brand as brandmod
        bd = brandmod.load(a.brand)
        errs, _ = brandmod.cmd_check(bd)
        if errs:
            sys.exit("[plan] brand YAML に誤り（brand.py check で確認）:\n  " + "\n  ".join(errs))
        palette.update({k: bd["colors"][k] for k in palette if k in bd["colors"]})
        fonts.update({k: bd["fonts"][k] for k in ("head", "body", "mono")})
        L = bd.get("layout", {})
        grid.update({k2: L[k1] for k1, k2 in (("margin_in", "marginX"), ("grid_unit_in", "unit"), ("indent_step_in", "indentStep"), ("bullet_hang_in", "bulletHang")) if k1 in L})
        bullets = L.get("bullets", bullets)
        brand_name = bd["brand"]["name"]
        logo_reserve = brandmod.logo_box(bd)

    h2count = sum(1 for b in blocks if b["kind"] == "h2")
    use_sections = (not a.no_sections) and h2count >= 3

    slides = []
    section_no = 0
    title_ref = None
    pending = []
    cover_done = False

    def emit(title, items):
        if not items and title is None:
            return
        if not items:
            # 見出しだけの節は中扉的な「見出しスライド」に
            slides.append({"layout": "heading", "title": title, "items": []}); return
        groups = chunks_of(items)
        # 大きすぎる塊を先に割る（表の行、コードの行、長い段落の文末）
        expanded = []
        for g in groups:
            b = g[0]
            if b["kind"] == "table" and len(b["rows"]) - 1 > d["tableRows"]:
                body = list(range(1, len(b["rows"])))
                for k in range(0, len(body), d["tableRows"]):
                    expanded.append([{**b, "rowsel": [0] + body[k:k + d["tableRows"]]}])
            elif b["kind"] == "code" and b["text"].count("\n") + 1 > d["codeLines"]:
                ls = b["text"].split("\n")
                parts = ["\n".join(ls[k:k + d["codeLines"]]) for k in range(0, len(ls), d["codeLines"])]
                assert "\n".join(parts) == b["text"]
                for pi, ptxt in enumerate(parts):
                    expanded.append([{**b, "part": pi + 1, "parts": len(parts), "text": ptxt, "runs": [{"t": ptxt, "code": True}]}])
            elif b["kind"] in ("p", "quote") and units(b["text"]) > d["maxChars"] and "\n" not in b["text"] and len(b["runs"]) == 1:
                parts = split_text(b["text"], d["maxChars"] * 0.85)
                for pi, ptxt in enumerate(parts):
                    expanded.append([{**b, "part": pi + 1, "parts": len(parts), "text": ptxt, "runs": [{**b["runs"][0], "t": ptxt}]}])
            else:
                expanded.append(g)
        # 容量で詰める（表・コードは単独、段落＋コードは同居可）
        def weight(g):
            # 20字以内・子なしの短い箇条書きは、並びとして1つのまとまりに見えるので 0.5 塊（ゲシュタルトの類同・近接）
            return 0.5 if g[0]["kind"] == "li" and len(g) == 1 and units(g[0]["text"]) <= 20 else 1.0
        # 連続する箇条書き（第1階層）の「並び」ごとの残り量。並びの途中で切らないための目安
        run_rest = [None] * len(expanded)
        i = len(expanded) - 1
        acc_w, acc_s = 0.0, 0.0
        while i >= 0:
            g = expanded[i]
            if g[0]["kind"] == "li":
                acc_w += weight(g); acc_s += sum(size(b) for b in g)
                run_rest[i] = (acc_w, acc_s)
            else:
                acc_w, acc_s = 0.0, 0.0
            i -= 1
        pages, cur, cur_sz, cur_w = [], [], 0.0, 0.0
        for gi, g in enumerate(expanded):
            gs = sum(size(b) for b in g)
            solo = g[0]["kind"] == "table" or (g[0]["kind"] == "code" and gs > d["maxChars"] * 0.6)
            starts_run = g[0]["kind"] == "li" and (gi == 0 or expanded[gi - 1][0]["kind"] != "li")
            run_breaks = False
            if cur and starts_run and run_rest[gi]:
                rw, rs = run_rest[gi]
                fits_here = cur_w + rw <= d["maxChunks"] and cur_sz + rs <= d["maxChars"]
                fits_alone = rw <= d["maxChunks"] and rs <= d["maxChars"]
                run_breaks = (not fits_here) and fits_alone
            if cur and (solo or run_breaks or cur_w + weight(g) > d["maxChunks"] or cur_sz + gs > d["maxChars"]
                        or cur[0][0]["kind"] == "table" or (cur[-1][0]["kind"] == "code")):
                pages.append(cur); cur, cur_sz, cur_w = [], 0.0, 0.0
            cur.append(g); cur_sz += gs; cur_w += weight(g)
        if cur:
            pages.append(cur)
        # ページ間で塊の数をならす（最後に1塊だけ残る「孤立」を作らない）
        if len(pages) > 1 and all(g[0]["kind"] == "li" for pg in pages for g in pg):
            flat_g = [g for pg in pages for g in pg]
            k = len(pages)
            target = math.ceil(len(flat_g) / k)
            cap_ok = all(sum(size(b) for g in flat_g[i:i + target] for b in g) <= d["maxChars"] and
                         sum(weight(g) for g in flat_g[i:i + target]) <= d["maxChunks"] for i in range(0, len(flat_g), target))
            if cap_ok:
                pages = [flat_g[i:i + target] for i in range(0, len(flat_g), target)]
        for pi, pg in enumerate(pages):
            lay = choose_layout(pg, per)
            s = {"layout": lay, "title": title, "items": [b for g in pg for b in g]}
            if len(pages) > 1:
                s["contd"] = [pi + 1, len(pages)]
            slides.append(s)

    for b in blocks:
        k = b["kind"]
        if k == "hr":
            continue
        if k == "h1" and not cover_done:
            emit(title_ref, pending)
            pending = []
            slides.append({"layout": "cover", "title": b, "items": []})
            cover_done = True
            title_ref = None
            continue
        nxt = next((x for x in blocks[blocks.index(b) + 1:] if x["kind"] != "hr"), None)
        if k in ("h1", "h2") and use_sections and nxt is not None and nxt["kind"] in ("h3",):
            emit(title_ref, pending); pending = []
            section_no += 1
            slides.append({"layout": "section", "title": b, "items": [], "sectionNo": section_no})
            title_ref = None
            continue
        if k in ("h1", "h2", "h3"):
            emit(title_ref, pending); pending = []
            title_ref = b
            continue
        if k in ("h4", "h5", "h6"):
            pending.append({**b, "kind": "sub"})
            continue
        # 表紙直後で見出しの無い短い段落は表紙のサブタイトルへ
        if slides and slides[-1]["layout"] == "cover" and title_ref is None and not pending and k == "p" \
                and units(b["text"]) <= 90 and "sub" not in slides[-1]:
            slides[-1]["sub"] = b
            continue
        pending.append(b)
    emit(title_ref, pending)

    # sub(h4-6) は li と同じ扱いにできないので list/split で描く
    for s in slides:
        if any(i["kind"] == "sub" for i in s["items"]) and s["layout"] in ("cards", "steps", "statement"):
            s["layout"] = "list"

    # アイコン（ペルソナが minimal なら見出し横のみ）
    deck_used = set()
    for s in slides:
        used = set()
        tt = s["title"]["text"] if s.get("title") else ""
        dflt = ICONMAP["defaults"].get(s["layout"], "LuCircleDot")
        s["icon"] = pick_icon(tt, used, "")  # まず見出しの語で選ぶ
        if not s["icon"]:
            used.discard("")
            s["icon"] = pick_icon(" ".join(i.get("text", "")[:40] for i in s["items"][:2]), used, dflt)
        if s["layout"] == "cards" or (s["layout"] in ("list", "split") and per["icons"] != "minimal"):
            s["itemIcons"] = []
            iused = set()  # 項目どうしでは重複させない（見出しのアイコンとは重なってよい）
            for g in chunks_of(s["items"]):
                s["itemIcons"].append(pick_icon(g[0]["text"], iused, ICONMAP["defaults"]["item"]))
    for i, s in enumerate(slides):
        s["id"] = f"s{i+1:02d}"

    plan = {"source": src["source"], "persona": a.persona, "purpose": a.purpose,
            "profile": {"label": per["label"], "why": per["why"], "purposeLabel": pur["label"], "density": d,
                        "icons": per["icons"], "palette": palette, "fonts": fonts, "grid": grid, "bullets": bullets, "brand": brand_name, "logo": logo_reserve},
            "options": {"pageNo": not a.no_pageno},
            "slides": slides}
    Path(a.out).write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    lay = {}
    for s in slides:
        lay[s["layout"]] = lay.get(s["layout"], 0) + 1
    print(f"[plan] {a.persona} × {a.purpose}{' × ' + brand_name if brand_name else ''}: {len(slides)} slides {lay}")
    print(f"[plan] 1枚あたり 最大{d['maxChunks']}塊 / 約{d['maxChars']}字, 本文{d['bodyPt']}pt（下限{d['floorPt']}pt）")


if __name__ == "__main__":
    main()
