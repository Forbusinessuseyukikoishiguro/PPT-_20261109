#!/bin/bash
# 原文 → 抽出 → 構成 → 生成 → 微調整 → 文字照合 → デザイン点検 を一括で。
#   bash make_deck.sh 要件書.md shinjin training 出力名
#   BRAND=会社ルール.yaml bash make_deck.sh 要件書.md shinjin training 出力名   # 会社独自デザインルールを当てる
# 途中の source.json / plan.json は 出力名_work/ に残る（plan.json を直して build から再実行できる）。
set -euo pipefail
SRC="$1"; PERSONA="${2:-shinjin}"; PURPOSE="${3:-training}"; NAME="${4:-deck}"
S="$(cd "$(dirname "$0")" && pwd)"
W="${NAME}_work"; mkdir -p "$W"
python3 "$S/extract_source.py" "$SRC" -o "$W/source.json"
BR=(); [ -n "${BRAND:-}" ] && BR=(--brand "$BRAND") && python3 "$S/brand.py" check "$BRAND"
python3 "$S/plan_deck.py" "$W/source.json" --persona "$PERSONA" --purpose "$PURPOSE" -o "$W/plan.json" "${BR[@]}" ${EXTRA_PLAN_ARGS:-}
node "$S/build_deck.js" "$W/plan.json" "$W/raw.pptx"
python3 "$S/polish.py" "$W/raw.pptx" -o "$NAME.pptx" --plan "$W/plan.json" --report "$W/polish.json" > "$W/polish.log"; head -1 "$W/polish.log"
if [ -n "${BRAND:-}" ]; then
  python3 "$S/brand.py" apply "$BRAND" "$NAME.pptx" -o "$NAME.pptx" --plan "$W/plan.json" --report "$W/brand.json" > "$W/brand.log"; head -1 "$W/brand.log"
  python3 "$S/brand.py" audit "$BRAND" "$NAME.pptx" --report "$W/brand_audit.json"
fi
python3 "$S/verify_text.py" "$W/source.json" "$NAME.pptx" --report "$W/verify.json"
python3 "$S/check_design.py" "$NAME.pptx" --plan "$W/plan.json" --report "$W/design.json"
