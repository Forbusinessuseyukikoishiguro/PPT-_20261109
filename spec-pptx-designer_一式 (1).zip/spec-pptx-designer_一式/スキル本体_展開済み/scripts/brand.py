#!/usr/bin/env python3
"""会社独自デザインルール（brand YAML）を PPTX に当てる。文字（原文）には触れない。

  python brand.py check brand.yaml                                  # ルール自体の点検
  python brand.py apply brand.yaml in.pptx -o out.pptx [--plan plan.json] [--report r.json]
  python brand.py audit brand.yaml deck.pptx [--report a.json]      # 違反の一覧（直さない）

apply がすること
  colors  ガイドライン外の色 → 許可色へ。plan.json があれば役割どうしで置き換え（主色→主色）、
          無ければ一番近い許可色（CIEDE2000, Sharma et al. 2005）。max_delta_e より遠い色は報告のみ。
  fonts   使用禁止・指定外のフォント名 → head / body / mono
  icons   アイコンの色・丸の色・役割ごとの大きさ（title/row/card/cover）
  images  写真・図：縦横比（中央トリミング、元画像は残る）、角丸、枠線、色の処理（tint/duotone/grayscale）
  logo    ロゴを指定位置へ（濃い地のスライドは白抜きロゴ）
"""
import argparse, io, json, math, re, sys
from collections import Counter, defaultdict
from pathlib import Path

import yaml
from lxml import etree
from pptx import Presentation
from pptx.util import Emu, Inches, Pt

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
q = lambda t: f"{{{A}}}{t}"
IN = 914400
HERE = Path(__file__).resolve().parent
ROLES = ["primary", "accent", "text", "muted", "bg", "surface", "support", "line", "onPrimary", "onAccent", "codeBg", "codeText"]
HEX = re.compile(r"^[0-9A-Fa-f]{6}$")


# ---------------- 読み込み ----------------
def deep_merge(base, over):
    out = dict(base)
    for k, v in (over or {}).items():
        out[k] = deep_merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
    return out


def load(path):
    tpl = yaml.safe_load((HERE.parent / "assets" / "brand_rules.template.yaml").read_text(encoding="utf-8"))
    user = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    b = deep_merge(tpl, user)
    b["_dir"] = str(Path(path).resolve().parent)
    for k in ROLES:
        b["colors"][k] = str(b["colors"][k]).upper().lstrip("#")
    b["colors"]["chart"] = [str(c).upper().lstrip("#") for c in b["colors"].get("chart", [])]
    b["colors"]["forbidden"] = [str(c).upper().lstrip("#") for c in b["colors"].get("forbidden", [])]
    return b


def role(b, v):
    v = str(v)
    return b["colors"][v] if v in b["colors"] and isinstance(b["colors"][v], str) else v.upper().lstrip("#")


def asset(b, p):
    if not p:
        return None
    pp = Path(p)
    return pp if pp.is_absolute() else Path(b["_dir"]) / pp


# ---------------- 色の計算 ----------------
def lum(h):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    r, g, bb = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(bb)


def contrast(a, b):
    x, y = sorted((lum(a), lum(b)), reverse=True)
    return (x + 0.05) / (y + 0.05)


def lab(h):
    def lin(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(int(h[i:i + 2], 16)) for i in (0, 2, 4))
    X = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    Y = (0.2126 * r + 0.7152 * g + 0.0722 * b)
    Z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883
    f = lambda t: t ** (1 / 3) if t > 216 / 24389 else (24389 / 27 * t + 16) / 116
    fx, fy, fz = f(X), f(Y), f(Z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def de2000(h1, h2):
    """CIEDE2000 色差（Sharma, Wu & Dalal, 2005 の式）"""
    L1, a1, b1 = lab(h1); L2, a2, b2 = lab(h2)
    C1, C2 = math.hypot(a1, b1), math.hypot(a2, b2)
    Cb = (C1 + C2) / 2
    G = 0.5 * (1 - math.sqrt(Cb ** 7 / (Cb ** 7 + 25 ** 7)))
    a1p, a2p = (1 + G) * a1, (1 + G) * a2
    C1p, C2p = math.hypot(a1p, b1), math.hypot(a2p, b2)
    h1p = math.degrees(math.atan2(b1, a1p)) % 360
    h2p = math.degrees(math.atan2(b2, a2p)) % 360
    dLp, dCp = L2 - L1, C2p - C1p
    dhp = 0 if C1p * C2p == 0 else (h2p - h1p if abs(h2p - h1p) <= 180 else (h2p - h1p - 360 if h2p > h1p else h2p - h1p + 360))
    dHp = 2 * math.sqrt(C1p * C2p) * math.sin(math.radians(dhp / 2))
    Lbp, Cbp = (L1 + L2) / 2, (C1p + C2p) / 2
    if C1p * C2p == 0:
        hbp = h1p + h2p
    elif abs(h1p - h2p) <= 180:
        hbp = (h1p + h2p) / 2
    else:
        hbp = (h1p + h2p + 360) / 2 if h1p + h2p < 360 else (h1p + h2p - 360) / 2
    T = 1 - 0.17 * math.cos(math.radians(hbp - 30)) + 0.24 * math.cos(math.radians(2 * hbp)) \
        + 0.32 * math.cos(math.radians(3 * hbp + 6)) - 0.20 * math.cos(math.radians(4 * hbp - 63))
    dth = 30 * math.exp(-(((hbp - 275) / 25) ** 2))
    Rc = 2 * math.sqrt(Cbp ** 7 / (Cbp ** 7 + 25 ** 7))
    Sl = 1 + 0.015 * (Lbp - 50) ** 2 / math.sqrt(20 + (Lbp - 50) ** 2)
    Sc, Sh = 1 + 0.045 * Cbp, 1 + 0.015 * Cbp * T
    Rt = -math.sin(math.radians(2 * dth)) * Rc
    return math.sqrt((dLp / Sl) ** 2 + (dCp / Sc) ** 2 + (dHp / Sh) ** 2 + Rt * (dCp / Sc) * (dHp / Sh))


def allowed(b):
    return set(b["colors"][k] for k in ROLES) | set(b["colors"]["chart"])


# ---------------- check ----------------
def cmd_check(b):
    errs, warns = [], []
    for k in ROLES:
        if not HEX.match(b["colors"][k]):
            errs.append(f"colors.{k} = {b['colors'][k]} が16進6桁ではない")
    if errs:
        return errs, warns
    C = b["colors"]; n_t, n_l = b["checks"]["contrast_text"], b["checks"]["contrast_large"]
    pairs = [("text", "bg", n_t), ("text", "surface", n_t), ("muted", "bg", n_t), ("muted", "surface", n_t),
             ("primary", "bg", n_t), ("primary", "surface", n_t), ("onPrimary", "primary", n_t),
             ("onAccent", "accent", n_l), ("codeText", "codeBg", n_t), ("primary", "support", n_l), ("support", "primary", n_l)]
    for x, y, need in pairs:
        r = contrast(C[x], C[y])
        (errs if r < need else []).append(f"{x} {C[x]} / {y} {C[y]} = {r:.2f}:1（{need}:1 必要）")
    ch = C["chart"]
    for i in range(len(ch)):
        for j in range(i + 1, len(ch)):
            d = de2000(ch[i], ch[j])
            if d < 15:
                warns.append(f"chart の {ch[i]} と {ch[j]} が近い（ΔE00={d:.1f}）。系列の区別がつきにくい")
    for f in C["forbidden"]:
        if f in allowed(b):
            errs.append(f"使用禁止色 {f} が許可色にも入っている")
    if de2000(C["primary"], C["accent"]) < 20:
        warns.append(f"主色と差し色が近い（ΔE00={de2000(C['primary'], C['accent']):.1f}）。差し色が目立たない")
    for k in ("file", "file_on_dark"):
        p = asset(b, b["logo"].get(k))
        if p and not p.exists():
            errs.append(f"logo.{k} が見つからない: {p}")
    for r in b["images"]["aspect_ratios"]:
        if not re.match(r"^\d+(\.\d+)?:\d+(\.\d+)?$", str(r)):
            errs.append(f"images.aspect_ratios の {r} が「16:9」形式ではない")
    if b["images"]["treatment"] not in ("none", "duotone", "tint", "grayscale"):
        errs.append("images.treatment は none / duotone / tint / grayscale")
    for ff in (b["fonts"]["head"], b["fonts"]["body"], b["fonts"]["mono"]):
        if ff in b["fonts"].get("forbidden", []):
            errs.append(f"指定フォント {ff} が使用禁止にも入っている")
    return errs, warns


# ---------------- 図形の分類 ----------------
def kind(sh):
    n = sh.name or ""
    for p, k in (("logo:", "logo"), ("icon:", "icon"), ("iconbg:", "iconbg"), ("deco:", "deco"), ("meta:", "meta"), ("photo:", "photo")):
        if n.startswith(p):
            return k
    if sh.shape_type == 13:
        if sh.width < Inches(1.3) and abs(sh.width - sh.height) < Inches(0.08):
            return "icon"
        return "photo"
    return "box"


def icon_role(sh):
    n = sh.name or ""
    if "title-" in n: return "title"
    if "-r" in n.split(":")[-1]: return "row"
    if "-c" in n.split(":")[-1]: return "card"
    if "cover" in n: return "cover"
    return None


def slide_bg(slide):
    bg = slide._element.find(f".//{{{P_NS}}}bg")
    if bg is not None:
        c = bg.find(f".//{q('srgbClr')}")
        if c is not None:
            return c.get("val").upper()
    return "FFFFFF"


def is_title(sh):
    n = sh.name or ""
    return sh.has_text_frame and sh.top is not None and sh.top < Inches(1.3) and (n.startswith(("src:", "rep:")) or (sh.is_placeholder and sh.placeholder_format.type in (1, 3)))


# ---------------- apply ----------------
def map_colors(prs, b, plan, log):
    C = b["colors"]
    ok = allowed(b)
    rolemap = {}
    if plan:
        for k, v in plan["profile"]["palette"].items():
            if k in C:
                rolemap[v.upper()] = C[k]
    cache = {}

    def target(v):
        if v in rolemap:
            return rolemap[v], "役割"
        if v in ok and v not in C["forbidden"]:
            return None, None
        if v not in cache:
            best = min(ok, key=lambda c: de2000(v, c))
            cache[v] = (best, de2000(v, best))
        best, d = cache[v]
        if C["off_palette"] == "report_only" and v not in C["forbidden"]:
            return None, f"報告のみ ΔE{d:.0f}"
        if d > C["max_delta_e"] and v not in C["forbidden"]:
            return None, f"遠すぎるので残す ΔE{d:.0f}"
        return best, f"近い色 ΔE{d:.0f}"

    def text_target(v, under, need):
        # 文字の色は「近い色」より「読めること」を優先：下地とのコントラストを満たす許可色の中で一番近い色
        roles_t = {C[k] for k in ("text", "muted", "primary", "onPrimary", "onAccent", "codeText", "accent")}
        cands = [c for c in roles_t if contrast(c, under) >= need]
        if not cands:
            return C["text"] if contrast(C["text"], under) >= contrast(C["onPrimary"], under) else C["onPrimary"]
        return min(cands, key=lambda c: de2000(v, c))

    for si, s in enumerate(prs.slides, 1):
        sbg = slide_bg(s)
        shapes = list(s.shapes)
        for idx, sh in enumerate(shapes):
            if not sh.has_text_frame:
                continue
            f = fill_of(sh)
            under = f.get("val").upper() if f is not None else sbg
            if f is None and sh.left is not None:
                cx, cy = sh.left + sh.width / 2, sh.top + sh.height / 2
                for o in shapes[:idx]:  # 下にある（先に置かれた）塗り図形のうち、中心を含む一番上のもの
                    of = fill_of(o)
                    if of is not None and o.left is not None and o.left <= cx <= o.left + o.width and o.top <= cy <= o.top + o.height:
                        under = of.get("val").upper()
            if under not in ok and under in rolemap:
                under = rolemap[under]
            elif under not in ok:
                under = min(ok, key=lambda c: de2000(under, c))
            for r in sh._element.iter(q("rPr")):
                e = r.find(f"{q('solidFill')}/{q('srgbClr')}")
                if e is None:
                    continue
                v = e.get("val").upper()
                t, why = target(v)
                if not t:
                    continue
                sz = int(r.get("sz", "1800")) / 100
                need = 3.0 if sz >= 18 or (sz >= 14 and r.get("b") == "1") else 4.5
                if contrast(t, under) < need and v not in rolemap:  # 役割で置き換えた色は設計どおりなので触らない
                    t = text_target(v, under, need); why = "読める色"
                if t != v:
                    e.set("val", t); e.set("_done", "1"); log["colors"].append(f"slide{si}: 文字 {v}→{t}（{why}）")
        for e in s._element.iter(q("srgbClr")):
            if e.get("_done"):
                del e.attrib["_done"]; continue
            v = (e.get("val") or "").upper()
            t, why = target(v)
            if t and t != v:
                e.set("val", t); log["colors"].append(f"slide{si}: {v}→{t}（{why}）")
            elif why and len(log["colors_skip"]) < 200:
                log["colors_skip"].append(f"slide{si}: {v}（{why}）")


MONO = re.compile(r"Mono|Courier|Consolas|UDゴシック$|MS ゴシック|Code", re.I)


def map_fonts(prs, b, log):
    F = b["fonts"]; forb = set(F.get("forbidden", []))
    keep = {F["head"], F["body"], F["mono"]}
    for si, s in enumerate(prs.slides, 1):
        for sh in s.shapes:
            els = []
            if sh.has_text_frame:
                els.append((sh._element, is_title(sh)))
            if getattr(sh, "has_table", False) and sh.has_table:
                els.append((sh._element, False))
            for el, title in els:
                for tag in ("latin", "ea", "cs"):
                    for f in el.iter(q(tag)):
                        tf = f.get("typeface", "")
                        if tf.startswith("+"):
                            continue
                        if tf in keep and tf not in forb:
                            continue
                        new = F["mono"] if MONO.search(tf) else (F["head"] if title else F["body"])
                        if new != tf:
                            f.set("typeface", new); log["fonts"].append(f"slide{si} {sh.name}: {tf}→{new}")


def recolor_blob(blob, hexc):
    from PIL import Image
    im = Image.open(io.BytesIO(blob)).convert("RGBA")
    rgb = tuple(int(hexc[i:i + 2], 16) for i in (0, 2, 4))
    out = Image.new("RGBA", im.size, rgb + (0,)); out.putalpha(im.split()[3])
    bio = io.BytesIO(); out.save(bio, "PNG"); return bio.getvalue()


def replace_blob(slide, pic, data):
    part, rid = slide.part.get_or_add_image_part(io.BytesIO(data))
    blip = pic._element.find(f".//{q('blip')}")
    blip.set(f"{{{R_NS}}}embed", rid)


def fill_of(sh):
    sp = sh._element.find(f".//{{{P_NS}}}spPr")
    if sp is None:
        return None
    c = sp.find(f"{q('solidFill')}/{q('srgbClr')}")
    return c


def apply_icons(prs, b, log):
    I = b["icons"]; C = b["colors"]
    icol = role(b, I["color"]); ccol = role(b, I["circle_color"]); rcol = role(b, I["row_circle_color"])
    sizes = I.get("size_in", {})
    for si, s in enumerate(prs.slides, 1):
        bgs = [x for x in s.shapes if kind(x) == "iconbg"]
        for bgsh in bgs:
            r = icon_role(bgsh)
            c = fill_of(bgsh)
            want = rcol if r == "row" or "-big" in (bgsh.name or "") else ccol
            if contrast(want, slide_bg(s)) < 1.5:  # 濃い地（表紙・中扉）では丸を白抜きに
                want = C["onPrimary"]
            if c is not None and c.get("val") != want and not re.search(r"-st\d", bgsh.name or ""):
                c.set("val", want)
                ln = bgsh._element.find(f".//{q('ln')}//{q('srgbClr')}")
                if ln is not None: ln.set("val", want)
                log["icons"].append(f"slide{si} {bgsh.name}: 丸の色→{want}")
            if r and r in sizes:
                d = Inches(sizes[r])
                if abs(bgsh.width - d) > 3000:
                    cx, cy = bgsh.left + bgsh.width // 2, bgsh.top + bgsh.height // 2
                    bgsh.width = bgsh.height = Emu(int(d)); bgsh.left = Emu(int(cx - d / 2)); bgsh.top = Emu(int(cy - d / 2))
                    log["icons"].append(f"slide{si} {bgsh.name}: 直径→{sizes[r]}in")
        for ic in [x for x in s.shapes if kind(x) == "icon"]:
            cx, cy = ic.left + ic.width / 2, ic.top + ic.height / 2
            host = next((h for h in bgs if h.left <= cx <= h.left + h.width and h.top <= cy <= h.top + h.height), None)
            if host is not None:
                hf = fill_of(host)
                under = hf.get("val") if hf is not None else slide_bg(s)
                fg = C["onPrimary"] if contrast(C["onPrimary"], under) >= contrast(icol, under) else icol
                isz = int(host.width * 0.54)
                ic.width = ic.height = Emu(isz)
                ic.left = Emu(int(host.left + (host.width - isz) / 2)); ic.top = Emu(int(host.top + (host.height - isz) / 2))
            else:
                under = slide_bg(s)
                fg = icol if contrast(icol, under) >= 3 else C["onPrimary"]
            try:
                replace_blob(s, ic, recolor_blob(ic.image.blob, fg))
                log["icons"].append(f"slide{si} {ic.name}: 色→{fg}")
            except Exception as e:
                log["warn"].append(f"slide{si} {ic.name}: 色を変えられない（{e}）")


def ratio_of(r):
    a, c = str(r).split(":")
    return float(a) / float(c)


def treat_blob(blob, b):
    from PIL import Image, ImageOps
    Im = b["images"]; C = b["colors"]
    im = Image.open(io.BytesIO(blob))
    fmt = (im.format or "PNG").upper()
    im = im.convert("RGBA")
    alpha = im.split()[3]
    rgb = im.convert("RGB")
    t = Im["treatment"]
    p = tuple(int(C["primary"][i:i + 2], 16) for i in (0, 2, 4))
    w = tuple(int(C["bg"][i:i + 2], 16) for i in (0, 2, 4))
    if t == "grayscale":
        rgb = ImageOps.grayscale(rgb).convert("RGB")
    elif t == "duotone":
        rgb = ImageOps.colorize(ImageOps.grayscale(rgb), black=p, white=w)
    elif t == "tint":
        over = Image.new("RGB", rgb.size, p)
        rgb = Image.blend(rgb, over, float(Im.get("strength", 0.18)))
    out = rgb.convert("RGBA"); out.putalpha(alpha)
    bio = io.BytesIO()
    if fmt in ("JPEG", "JPG"):
        out.convert("RGB").save(bio, "JPEG", quality=90)
    else:
        out.save(bio, "PNG")
    return bio.getvalue()


def apply_images(prs, b, log):
    Im = b["images"]
    ratios = [ratio_of(r) for r in Im["aspect_ratios"]]
    for si, s in enumerate(prs.slides, 1):
        for pic in [x for x in s.shapes if kind(x) == "photo"]:
            # 1) 枠の縦横比 → 一番近い許可比（幅を保ち、縦の中心を保つ）
            fa = pic.width / pic.height
            best = min(ratios, key=lambda r: abs(math.log(r / fa)))
            if abs(math.log(best / fa)) > 0.02:
                # 上端と幅を保つ（並んだ写真の上端がずれない）。縦が伸びてはみ出すなら高さを保って幅を縮める
                nh = int(pic.width / best)
                if pic.top + nh > prs.slide_height - Inches(0.5):
                    nw = int(pic.height * best); pic.width = Emu(nw)
                else:
                    pic.height = Emu(nh)
                log["images"].append(f"slide{si} {pic.name}: 縦横比 {fa:.2f}→{best:.2f}")
            # 2) 中央トリミング（画像の縦横比 ≠ 枠の縦横比のとき、歪ませずに切る）
            iw, ih = pic.image.size
            ia, fa2 = iw / ih, pic.width / pic.height
            pic.crop_left = pic.crop_right = pic.crop_top = pic.crop_bottom = 0
            if ia > fa2 * 1.001:
                c = (1 - fa2 / ia) / 2; pic.crop_left = pic.crop_right = c
            elif ia < fa2 / 1.001:
                c = (1 - ia / fa2) / 2; pic.crop_top = pic.crop_bottom = c
            # 3) 角丸
            spPr = pic._element.find(f"{{{P_NS}}}spPr")
            geom = spPr.find(q("prstGeom"))
            rad = float(Im.get("corner_radius_in", 0))
            if geom is not None:
                if rad > 0:
                    geom.set("prst", "roundRect")
                    av = geom.find(q("avLst"))
                    if av is None:
                        av = etree.SubElement(geom, q("avLst"))
                    for g in list(av):
                        av.remove(g)
                    gd = etree.SubElement(av, q("gd")); gd.set("name", "adj")
                    gd.set("fmla", f"val {int(min(50000, Inches(rad) / min(pic.width, pic.height) * 100000))}")
                else:
                    geom.set("prst", "rect")
            # 4) 枠線
            bw = float(Im["border"].get("width_pt", 0))
            ln = spPr.find(q("ln"))
            if ln is not None:
                spPr.remove(ln)
            if bw > 0:
                ln = etree.SubElement(spPr, q("ln")); ln.set("w", str(int(Pt(bw))))
                sf = etree.SubElement(ln, q("solidFill")); c = etree.SubElement(sf, q("srgbClr")); c.set("val", role(b, Im["border"]["color"]))
            # 5) 色の処理（1回だけ。済みの印を名前に付ける）
            if Im["treatment"] != "none" and not (pic.name or "").startswith("photo:t:"):
                try:
                    replace_blob(s, pic, treat_blob(pic.image.blob, b))
                    pic.name = "photo:t:" + (pic.name or "img")
                    log["images"].append(f"slide{si} {pic.name}: {Im['treatment']}")
                except Exception as e:
                    log["warn"].append(f"slide{si} {pic.name}: 色の処理ができない（{e}）")
            elif not (pic.name or "").startswith("photo:"):
                pic.name = "photo:" + (pic.name or "img")


def logo_box(b, slide_w_in=13.333, slide_h_in=7.5):
    """ロゴの位置と大きさ（インチ）。builder の予約と apply の配置で同じ計算を使う。"""
    L = b["logo"]; f = asset(b, L.get("file"))
    if not f or L.get("slides", "content") == "none" or not f.exists():
        return None
    from PIL import Image
    iw, ih = Image.open(f).size
    w = float(L["width_in"]); h = w * ih / iw; m = float(L["margin_in"]); u = float(b["layout"].get("grid_unit_in", 0.05))
    pos = L.get("position", "top-right")
    x = m if "left" in pos else slide_w_in - m - w
    y = m if "top" in pos else slide_h_in - m - h
    x = math.floor(x / u) * u if "right" in pos else math.ceil(x / u) * u
    y = math.ceil(y / u) * u if "top" in pos else math.floor(y / u) * u
    return {"x": round(x, 4), "y": round(y, 4), "w": w, "h": round(h, 4), "clear": float(L.get("clear_space_in", 0)), "pos": pos, "slides": L.get("slides", "content")}


def make_room(s, zone, log, si):
    """ロゴの余白に入る図形をよける（文字は変えない。幅を縮めるか、小さな数字を横へずらす）"""
    zx0, zy0, zx1, zy1 = zone
    for o in s.shapes:
        if kind(o) in ("deco", "logo") or o.left is None or o.width is None:
            continue
        if o.width > Inches(12) and o.height > Inches(7):
            continue
        ox0, oy0, ox1, oy1 = o.left, o.top, o.left + o.width, o.top + o.height
        if not (min(zx1, ox1) > max(zx0, ox0) and min(zy1, oy1) > max(zy0, oy0)):
            continue
        if ox0 < zx0 and o.has_text_frame and (zx0 - ox0) > Inches(2):
            o.width = Emu(int(zx0 - ox0)); log["logo"].append(f"slide{si} {o.name}: ロゴの余白のぶん幅を縮めた")
        elif (o.name or "").startswith("meta:") or o.width < Inches(1.5):
            o.left = Emu(int(zx0 - o.width)); log["logo"].append(f"slide{si} {o.name}: ロゴの横へ移動")
        else:
            log["warn"].append(f"slide{si} {o.name}: ロゴの余白と重なる（手で調整）")


def apply_logo(prs, b, log):
    L = b["logo"]
    f = asset(b, L.get("file"))
    if not f or L.get("slides", "content") == "none":
        return
    fd = asset(b, L.get("file_on_dark")) or f
    from PIL import Image
    W, H = prs.slide_width, prs.slide_height
    n = len(prs.slides)
    for si, s in enumerate(prs.slides, 1):
        for sh in list(s.shapes):
            if (sh.name or "").startswith("logo:"):
                sh._element.getparent().remove(sh._element)
        dark = lum(slide_bg(s)) < 0.25
        is_cover = si == 1
        is_section = any((x.name or "") == "meta:secno" for x in s.shapes)
        mode = L.get("slides", "content")
        if mode == "content" and (is_cover or is_section): continue
        if mode == "cover" and not is_cover: continue
        src = fd if dark else f
        lb = logo_box(b, W / IN, H / IN)
        x, y, w, h = (Inches(lb[k]) for k in ("x", "y", "w", "h"))
        cs = Inches(lb["clear"])
        make_room(s, (x - cs, y - cs, x + w + cs, y + h + cs), log, si)
        pic = s.shapes.add_picture(str(src), int(x), int(y), int(w), int(h))
        pic.name = "logo:brand"
        log["logo"].append(f"slide{si}: {'白抜き' if src == fd and dark else '通常'}ロゴ {lb['pos']}")


def apply_theme(path, b, log):
    at = Path("/mnt/skills/public/pptx/scripts/apply_theme.js")
    if not at.exists():
        return
    import subprocess, tempfile
    C = b["colors"]; ch = (C["chart"] + ["0072B2", "009E73", "CC79A7", "56B4E9"])[:4]
    theme = {"name": b["brand"]["name"], "colors": {"dk1": C["text"], "lt1": C["bg"], "dk2": C["primary"], "lt2": C["surface"],
             "accent1": C["primary"], "accent2": C["accent"], "accent3": ch[0], "accent4": ch[1], "accent5": ch[2], "accent6": ch[3],
             "hlink": C["primary"], "folHlink": C["muted"]}}
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as t:
        json.dump(theme, t)
    r = subprocess.run(["node", str(at), path, t.name], capture_output=True, text=True)
    (log["theme"] if r.returncode == 0 else log["warn"]).append("テーマ色を書き込み" if r.returncode == 0 else r.stderr[:200])


# ---------------- audit ----------------
def cmd_audit(b, path):
    prs = Presentation(path)
    C = b["colors"]; ok = allowed(b); out = defaultdict(list)
    fonts_ok = {b["fonts"]["head"], b["fonts"]["body"], b["fonts"]["mono"]}
    ratios = [ratio_of(r) for r in b["images"]["aspect_ratios"]]
    has_logo_rule = bool(asset(b, b["logo"].get("file"))) and b["logo"].get("slides") != "none"
    for si, s in enumerate(prs.slides, 1):
        cols = Counter((e.get("val") or "").upper() for e in s._element.iter(q("srgbClr")))
        for c in cols:
            if c in C["forbidden"]:
                out["forbidden-color"].append(f"slide{si}: 使用禁止色 {c}")
            elif c not in ok:
                near = min(ok, key=lambda x: de2000(c, x))
                out["off-palette"].append(f"slide{si}: {c}（最も近い許可色 {near}, ΔE00={de2000(c, near):.1f}）")
        for f in set(x.get("typeface") for t in ("latin", "ea") for x in s._element.iter(q(t))):
            if f and not f.startswith("+") and (f not in fonts_ok or f in b["fonts"].get("forbidden", [])):
                out["font"].append(f"slide{si}: 指定外フォント {f}")
        photos = [x for x in s.shapes if kind(x) == "photo"]
        if len(photos) > b["images"]["max_per_slide"]:
            out["image-count"].append(f"slide{si}: 写真 {len(photos)} 枚（上限 {b['images']['max_per_slide']}）")
        for p in photos:
            fa = p.width / p.height
            if min(abs(math.log(r / fa)) for r in ratios) > 0.02:
                out["image-aspect"].append(f"slide{si} {p.name}: 縦横比 {fa:.2f} は許可外 {b['images']['aspect_ratios']}")
            iw, ih = p.image.size
            vis_w = iw * (1 - (p.crop_left or 0) - (p.crop_right or 0))
            dpi = vis_w / (p.width / IN)
            if dpi < b["images"]["min_dpi"]:
                out["image-dpi"].append(f"slide{si} {p.name}: 実効 {dpi:.0f}dpi（下限 {b['images']['min_dpi']}）")
        logos = [x for x in s.shapes if kind(x) == "logo"]
        mode = b["logo"].get("slides", "content")
        is_cover = si == 1; is_section = any((x.name or "") == "meta:secno" for x in s.shapes)
        need = has_logo_rule and (mode == "all" or (mode == "content" and not (is_cover or is_section)) or (mode == "cover" and is_cover))
        if need and not logos:
            out["logo"].append(f"slide{si}: ロゴが無い")
        cs = Inches(float(b["logo"].get("clear_space_in", 0)))
        for lg in logos:
            lb = (lg.left - cs, lg.top - cs, lg.left + lg.width + cs, lg.top + lg.height + cs)
            for o in s.shapes:
                if o._element is lg._element or kind(o) in ("deco", "logo") or o.left is None:
                    continue
                if o.width > prs.slide_width * 0.9 and o.height > prs.slide_height * 0.9:
                    continue
                ob = (o.left, o.top, o.left + o.width, o.top + o.height)
                if min(lb[2], ob[2]) > max(lb[0], ob[0]) and min(lb[3], ob[3]) > max(lb[1], ob[1]):
                    out["logo-clearspace"].append(f"slide{si}: ロゴの余白に {o.name} が入っている"); break
        for bgsh in [x for x in s.shapes if kind(x) == "iconbg"]:
            r = icon_role(bgsh); want = b["icons"]["size_in"].get(r) if r else None
            if want and abs(bgsh.width / IN - want) > 0.01:
                out["icon-size"].append(f"slide{si} {bgsh.name}: 直径 {bgsh.width/IN:.2f}in（ルール {want}in）")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["check", "apply", "audit"])
    ap.add_argument("brand"); ap.add_argument("deck", nargs="?")
    ap.add_argument("-o", "--out"); ap.add_argument("--plan"); ap.add_argument("--report")
    ap.add_argument("--only", default="colors,fonts,icons,images,logo,theme")
    a = ap.parse_args()
    b = load(a.brand)
    if a.cmd == "check":
        errs, warns = cmd_check(b)
        print(f"[brand check] {'PASS' if not errs else 'FAIL'}  {b['brand']['name']}")
        for e in errs: print("  ✗", e)
        for w in warns: print("  △", w)
        sys.exit(0 if not errs else 1)
    if not a.deck:
        sys.exit("deck.pptx を指定してください")
    if a.cmd == "audit":
        out = cmd_audit(b, a.deck)
        n = sum(len(v) for v in out.values())
        keys = ["forbidden-color", "off-palette", "font", "logo", "logo-clearspace", "icon-size", "image-aspect", "image-dpi", "image-count"]
        print(f"[brand audit] {'PASS' if n == 0 else 'NEEDS FIX'}  " + "  ".join(f"{k}:{len(out[k])}" for k in keys))
        for k in keys:
            for m in out[k][:10]: print(f"  [{k}] {m}")
            if len(out[k]) > 10: print(f"  [{k}] …ほか {len(out[k]) - 10} 件")
        if a.report: Path(a.report).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
        return
    errs, _ = cmd_check(b)
    if errs:
        print("[brand apply] ルールに誤りがあるので中止。先に brand.py check を通す"); [print("  ✗", e) for e in errs]; sys.exit(1)
    plan = json.loads(Path(a.plan).read_text(encoding="utf-8")) if a.plan else None
    prs = Presentation(a.deck)
    log = defaultdict(list)
    ops = set(a.only.split(","))
    if "colors" in ops: map_colors(prs, b, plan, log)
    if "fonts" in ops: map_fonts(prs, b, log)
    if "icons" in ops: apply_icons(prs, b, log)
    if "images" in ops: apply_images(prs, b, log)
    if "logo" in ops: apply_logo(prs, b, log)
    out = a.out or a.deck
    prs.save(out)
    if "theme" in ops: apply_theme(out, b, log)
    print(f"[brand apply] {b['brand']['name']} -> {out}  " + "  ".join(f"{k}:{len(v)}" for k, v in log.items() if k not in ("colors_skip",)))
    for k in ("colors", "fonts", "images", "logo", "warn"):
        for m in log[k][:6]: print(f"  [{k}] {m}")
        if len(log[k]) > 6: print(f"  [{k}] …ほか {len(log[k]) - 6} 件")
    for m in log["colors_skip"][:5]: print(f"  [colors 残した] {m}")
    if a.report: Path(a.report).write_text(json.dumps(log, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
