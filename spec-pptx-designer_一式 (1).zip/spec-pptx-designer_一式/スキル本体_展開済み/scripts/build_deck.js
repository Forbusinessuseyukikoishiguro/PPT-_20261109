#!/usr/bin/env node
// plan.json → deck.pptx（pptxgenjs）。文字は plan の runs をそのまま置くだけで、足しも削りもしない。
//   node build_deck.js plan.json deck.pptx
//
// 置く図形にはすべて objectName を付ける。verify_text.py はこの名前で原文と照合する。
//   src:b004,b005   原文ブロック（1ブロック = 1段落）
//   src:b005#2      文末で分けた段落・コードの2番目の部品
//   src:b010@0,9,10 表の行（0 = 見出し行の繰り返し）
//   rep:b003        続きスライドで繰り返した見出し（原文と同一）
//   meta:pageno / meta:contd / meta:stepno   数字だけ（原文以外の文字は数字と / のみ許可）
//   icon:* / iconbg:* / deco:* / panel:*     文字を持たない図形
const fs = require("fs");
const path = require("path");
const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Lu = require("react-icons/lu");

const [, , planPath, outPath = "deck.pptx"] = process.argv;
if (!planPath) { console.error("usage: node build_deck.js plan.json deck.pptx"); process.exit(2); }
const plan = JSON.parse(fs.readFileSync(planPath, "utf8"));
const P = plan.profile.palette, D = plan.profile.density, F = plan.profile.fonts, G = plan.profile.grid;
const W = G.slideW, H = G.slideH, MX = G.marginX, CW = W - 2 * MX;
const COLW = (CW - (G.cols - 1) * G.gutter) / G.cols;
const cols = (n) => n * COLW + (n - 1) * G.gutter;
const Y0 = G.contentTop, Y1 = G.contentBottom, CH = Y1 - Y0;
const LS = 1.1;                 // 行間倍率（PowerPoint の「倍数」）
const LH = (pt) => pt * 1.2 * LS / 72;   // 1行の高さ(in)
const warnings = [];
const snap = (v) => Math.round(v / G.unit) * G.unit;

// ---------- 文字幅の見積もり（全角=1em、半角≒0.56em） ----------
function units(s) {
  let u = 0;
  for (const ch of s) {
    if (ch === "\n") continue;
    const c = ch.codePointAt(0);
    const wide = (c >= 0x1100 && (c <= 0x115f || (c >= 0x2e80 && c <= 0xa4cf) || (c >= 0xac00 && c <= 0xd7a3) ||
      (c >= 0xf900 && c <= 0xfaff) || (c >= 0xfe30 && c <= 0xfe4f) || (c >= 0xff00 && c <= 0xff60) || (c >= 0xffe0 && c <= 0xffe6) ||
      (c >= 0x3000 && c <= 0x303f) || (c >= 0x1f300 && c <= 0x1faff))) || (c >= 0x2460 && c <= 0x27bf);
    u += wide ? 1.0 : (ch === " " ? 0.32 : 0.56);
  }
  return u;
}
function linesOf(text, pt, wIn, mono = false) {
  let n = 0;
  const per = Math.max(1, (wIn * 0.94) * 72 / pt);
  for (const seg of text.split("\n")) {
    const u = mono ? [...seg].reduce((a, ch) => a + (units(ch) >= 1 ? 1 : 0.6), 0) : units(seg);
    n += Math.max(1, Math.ceil(u / per));
  }
  return n;
}
// paras: [{text, indent(in)}]
function heightOf(paras, pt, wIn, opt = {}) {
  let h = 0;
  paras.forEach((p, i) => {
    h += linesOf(p.text, pt * (p.scale || 1), wIn - (p.indent || 0), opt.mono) * LH(pt * (p.scale || 1));
    if (i < paras.length - 1) h += pt * 0.45 / 72;
  });
  return h;
}
function fitPt(paras, wIn, hIn, maxPt, minPt, opt = {}) {
  for (let pt = maxPt; pt >= minPt; pt -= 1) if (heightOf(paras, pt, wIn, opt) <= hIn) return pt;
  return null;
}

// ---------- アイコン（Lucide のみ・色と線幅を全体で統一） ----------
const iconCache = {};
async function icon(name, hex) {
  const key = name + hex;
  if (iconCache[key]) return iconCache[key];
  const C = Lu[name] || Lu.LuCircleDot;
  if (!Lu[name]) warnings.push(`icon ${name} が無いので LuCircleDot に置換`);
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(C, { color: "#" + hex, size: 256, strokeWidth: 2 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  return (iconCache[key] = "image/png;base64," + buf.toString("base64"));
}
async function iconInCircle(slide, name, x, y, d, fill, fg, tag) {
  slide.addShape("ellipse", { x: snap(x), y: snap(y), w: d, h: d, fill: { color: fill }, line: { color: fill, width: 0 }, objectName: `iconbg:${tag}` });
  const s = d * 0.54;
  slide.addImage({ data: await icon(name, fg), x: snap(x) + (d - s) / 2, y: snap(y) + (d - s) / 2, w: s, h: s, objectName: `icon:${tag}` });
}

// ---------- 原文 runs → pptxgenjs の段落（文字は1字も変えない） ----------
const BUL = (plan.profile.bullets || ["●", "–", "・"]).map((c) => ({ code: c.codePointAt(0).toString(16).toUpperCase().padStart(4, "0") }));
function labelSplit(runs) {
  // 「目的：〜」のような見出し語を太字にするだけ（文字は同じ）。先頭 run が地の文のときのみ。
  if (!runs.length || runs[0].b || runs[0].code || runs[0].link) return runs;
  const m = runs[0].t.match(/^([^\n：:]{1,18}?[：:])(.*)$/s);
  if (!m) return runs;
  if (m[2] === "") return runs.length > 1 ? [{ ...runs[0], b: true, label: true }, ...runs.slice(1)] : runs;
  return [{ ...runs[0], t: m[1], b: true, label: true }, { ...runs[0], t: m[2] }, ...runs.slice(1)];
}
function para(block, o = {}) {
  // 1ブロック = 1段落。ブロック内の改行は <a:br/>（softBreakBefore）にして段落を増やさない。
  let runs = block.runs.map((r) => ({ ...r }));
  if (o.label && (block.kind === "li" || block.kind === "p")) runs = labelSplit(runs);
  const out = [];
  runs.forEach((r) => {
    const segs = r.t.split("\n");
    segs.forEach((seg, si) => {
      const ro = {
        bold: !!(r.b || o.bold), italic: !!r.i,
        color: r.label ? (o.labelColor || P.primary) : (r.code && !o.mono ? (o.codeColor || P.primary) : (o.color || P.text)),
        fontFace: r.code || o.mono ? F.mono : F.body,
      };
      if (r.link) ro.hyperlink = { url: r.link };
      if (si > 0) ro.softBreakBefore = true;
      if (seg === "" && si === 0 && segs.length > 1) { out.push({ text: "", options: ro, _empty: true }); return; }
      out.push({ text: seg, options: ro });
    });
  });
  const first = out[0].options;
  const lvl = block.kind === "li" ? Math.min(block.level || 0, 2) : 0;
  if (block.kind === "li" && !o.noBullet) {
    first.bullet = block.ordered ? { type: "number", indent: G.bulletHang * 72 } : { ...BUL[lvl], indent: G.bulletHang * 72 };
    if (lvl > 0) first.indentLevel = lvl;
  }
  if (block.kind === "sub") { out.forEach((x) => { x.options.bold = true; x.options.color = P.primary; }); }
  first.paraSpaceAfter = (o.pt || 18) * 0.45;
  first.lineSpacingMultiple = LS;
  first.align = o.align || "left";
  out.forEach((x) => { if (o.pt) x.options.fontSize = o.pt * (o.scale || 1); });
  return out;
}
function paras(blocks, o) {
  const arr = [];
  blocks.forEach((b, i) => {
    const p = para(b, o);
    if (i < blocks.length - 1) p[p.length - 1].options.breakLine = true;
    arr.push(...p);
  });
  return arr.filter((x) => !(x._empty && x.text === "" && false));
}
function srcName(blocks) {
  return "src:" + blocks.map((b) => b.id + (b.part ? "#" + b.part : "")).join(",");
}
function metric(blocks, extraIndent = 0) {
  return blocks.map((b) => ({ text: b.text, indent: (b.kind === "li" ? G.bulletHang + Math.min(b.level || 0, 2) * G.indentStep : 0) + extraIndent }));
}
function textBox(slide, blocks, x, y, w, h, o) {
  slide.addText(paras(blocks, o), { x: snap(x), y: snap(y), w: snap(w), h: snap(h), margin: 0, valign: o.valign || "top", isTextBox: true, objectName: srcName(blocks), fit: "none" });
}

// ---------- ロゴの予約領域（brand YAML のロゴと重ねない） ----------
const LOGO = plan.profile.logo;
function logoOn(slideKind) {
  if (!LOGO) return false;
  const m = LOGO.slides;
  return m === "all" || (m === "content" && !["cover", "section"].includes(slideKind)) || (m === "cover" && slideKind === "cover");
}
function clip(x, y, w, h, slideKind) {
  // 予約領域と重なるなら、右端をロゴの手前までに縮めた幅を返す
  if (!logoOn(slideKind)) return w;
  const zx = LOGO.x - LOGO.clear, zy0 = LOGO.y - LOGO.clear, zy1 = LOGO.y + LOGO.h + LOGO.clear;
  if (y < zy1 && y + h > zy0 && x + w > zx && x < zx) return zx - x;
  return w;
}
const nearLogo = (top) => LOGO && LOGO.pos.includes(top ? "top" : "bottom") && LOGO.pos.includes("right");

// ---------- 共通：タイトル・番号 ----------
let pageNo = 0;
async function frame(slide, s, dark = false) {
  pageNo++;
  if (s.title) {
    const d = 0.6;
    await iconInCircle(slide, s.icon, MX, 0.5, d, P.primary, P.onPrimary, `title-${s.id}`);
    const tx = MX + d + 0.25;
    const contdX = logoOn(s.layout) && nearLogo(true) ? LOGO.x - LOGO.clear - 0.9 : W - MX - 0.9;
    const tw = Math.min(CW - d - 0.25 - 1.0, clip(tx, 0.45, CW, 0.75, s.layout), contdX - 0.15 - tx);
    const tp = fitPt([{ text: s.title.text }], tw, 0.95, D.titlePt, D.titlePt - 8) || D.titlePt - 8;
    if (!fitPt([{ text: s.title.text }], tw, 0.95, D.titlePt, D.titlePt - 8)) warnings.push(`${s.id}: タイトルが長い（2行超の見込み）`);
    slide.addText(paras([s.title], { pt: tp, bold: true, color: P.text }).map((r) => { r.options.fontFace = F.head; return r; }),
      { x: snap(tx), y: 0.45, w: snap(tw), h: 0.75, margin: 0, valign: "middle", isTextBox: true, objectName: (s.contd && s.contd[0] > 1 ? "rep:" : "src:") + s.title.id });
    if (s.contd) slide.addText(`${s.contd[0]}/${s.contd[1]}`, { x: snap(contdX), y: 0.6, w: 0.9, h: 0.45, margin: 0, align: "right", valign: "middle", fontSize: 14, color: P.muted, fontFace: F.body, isTextBox: true, objectName: "meta:contd" });
  }
  const pnX = logoOn(s.layout) && nearLogo(false) ? LOGO.x - LOGO.clear - 1.0 : W - MX - 1.0;
  if (plan.options.pageNo) slide.addText(String(pageNo), { x: snap(pnX), y: 7.0, w: 1.0, h: 0.3, margin: 0, align: "right", valign: "middle", fontSize: 11, color: dark ? P.onPrimary : P.muted, fontFace: F.body, isTextBox: true, objectName: "meta:pageno" });
}
function groups(items) {
  const gs = []; let cur = null;
  for (const b of items) {
    if (b.kind === "li" && (b.level || 0) > 0 && cur && cur[0].kind === "li") cur.push(b);
    else { cur = [b]; gs.push(cur); }
  }
  return gs;
}
const shadow = () => ({ type: "outer", blur: 8, offset: 2, angle: 90, color: "000000", opacity: 0.10 });

// ---------- レイアウト ----------
const L = {};
L.cover = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.primary }; pageNo++;
  sl.addShape("ellipse", { x: 8.9, y: -1.2, w: 6.2, h: 6.2, fill: { color: P.onPrimary, transparency: 92 }, line: { color: P.primary, width: 0 }, objectName: "deco:c1" });
  sl.addShape("ellipse", { x: 10.4, y: 3.9, w: 4.2, h: 4.2, fill: { color: P.accent, transparency: 80 }, line: { color: P.primary, width: 0 }, objectName: "deco:c2" });
  await iconInCircle(sl, s.icon, MX, 1.45, 0.9, P.onPrimary, P.primary, `cover`);
  const tw = 8.4;
  const tp = fitPt([{ text: s.title.text }], tw, 2.1, 44, 30) || 30;
  sl.addText(paras([s.title], { pt: tp, bold: true, color: P.onPrimary }).map((r) => { r.options.fontFace = F.head; return r; }),
    { x: MX, y: 2.65, w: tw, h: 2.1, margin: 0, valign: "top", isTextBox: true, objectName: "src:" + s.title.id });
  if (s.sub) {
    const sp = fitPt([{ text: s.sub.text }], tw, 1.2, 22, 16) || 16;
    textBox(sl, [s.sub], MX, 4.95, tw, 1.2, { pt: sp, color: P.onPrimary });
  }
};
L.section = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.primary }; pageNo++;
  sl.addShape("ellipse", { x: 9.6, y: 1.2, w: 5.2, h: 5.2, fill: { color: P.onPrimary, transparency: 93 }, line: { color: P.primary, width: 0 }, objectName: "deco:c1" });
  sl.addText(String(s.sectionNo).padStart(2, "0"), { x: MX, y: 1.9, w: 3, h: 1.3, margin: 0, fontSize: 72, bold: true, color: P.support, fontFace: F.head, isTextBox: true, objectName: "meta:secno" });
  const tp = fitPt([{ text: s.title.text }], 9.5, 2.0, 40, 28) || 28;
  sl.addText(paras([s.title], { pt: tp, bold: true, color: P.onPrimary }).map((r) => { r.options.fontFace = F.head; return r; }),
    { x: MX, y: 3.35, w: 9.5, h: 2.0, margin: 0, valign: "top", isTextBox: true, objectName: "src:" + s.title.id });
  if (plan.options.pageNo) sl.addText(String(pageNo), { x: W - MX - 1.0, y: 7.0, w: 1.0, h: 0.3, margin: 0, align: "right", fontSize: 11, color: P.onPrimary, fontFace: F.body, isTextBox: true, objectName: "meta:pageno" });
};
L.heading = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.surface }; pageNo++;
  await iconInCircle(sl, s.icon, MX, 2.35, 1.1, P.primary, P.onPrimary, `heading-${s.id}`);
  const tp = fitPt([{ text: s.title.text }], 9.8, 1.8, 38, 26) || 26;
  sl.addText(paras([s.title], { pt: tp, bold: true, color: P.text }).map((r) => { r.options.fontFace = F.head; return r; }),
    { x: MX + 1.5, y: 2.3, w: 9.8, h: 1.8, margin: 0, valign: "top", isTextBox: true, objectName: "src:" + s.title.id });
  if (plan.options.pageNo) sl.addText(String(pageNo), { x: W - MX - 1.0, y: 7.0, w: 1.0, h: 0.3, margin: 0, align: "right", fontSize: 11, color: P.muted, fontFace: F.body, isTextBox: true, objectName: "meta:pageno" });
};

function listPt(items, w, h, withIcons, cap) {
  const gs = groups(items), icd = 0.5, gap = 0.24, tx = withIcons ? 0.78 : 0;
  for (let p = Math.min(cap || 99, D.bodyPt + (gs.length <= 3 ? 2 : 0)); p >= D.floorPt; p--) {
    const tot = gs.reduce((a, g) => a + Math.max(heightOf(metric(g), p, w - tx), withIcons ? icd : 0), 0) + gap * (gs.length - 1);
    if (tot <= h) return p;
  }
  return null;
}
async function listRows(sl, s, items, x, y, w, h, withIcons, cap) {
  const gs = groups(items);
  const icd = 0.5, gap = 0.24;
  const tx = withIcons ? 0.5 + 0.28 : 0;
  const maxPt = Math.min(cap || 99, D.bodyPt + (gs.length <= 3 ? 2 : 0)), minPt = D.floorPt;
  let pt = null;
  for (let p = maxPt; p >= minPt; p--) {
    const tot = gs.reduce((a, g) => a + Math.max(heightOf(metric(g), p, w - tx), withIcons ? icd : 0), 0) + gap * (gs.length - 1);
    if (tot <= h) { pt = p; break; }
  }
  if (!pt) { pt = minPt; warnings.push(`${s.id}: 本文が下限 ${minPt}pt でも入りきらない見込み → plan でスライドを分ける`); }
  const totH = gs.reduce((a, g) => a + Math.max(heightOf(metric(g), pt, w - tx), withIcons ? icd : 0), 0) + gap * (gs.length - 1);
  let cy = y + Math.max(0, (h - totH) * 0.4);
  for (let gi = 0; gi < gs.length; gi++) {
    const g = gs[gi];
    const gh = Math.max(heightOf(metric(g), pt, w - tx), withIcons ? icd : 0);
    if (withIcons) {
      const ic = (s.itemIcons && s.itemIcons[gi]) || "LuCircleCheck";
      const firstLine = LH(pt);
      await iconInCircle(sl, ic, x, cy + (firstLine - icd) / 2, icd, P.support, P.primary, `${s.id}-r${gi}`);
    }
    const noBullet = withIcons && g[0].kind === "li" && (g[0].level || 0) === 0;
    const blocks = noBullet ? g.map((b, i) => (i === 0 ? { ...b, _nb: true } : { ...b, level: Math.max(0, (b.level || 0) - 1) })) : g;
    const arr = [];
    blocks.forEach((b, i) => {
      const p = para(b, { pt, label: true, noBullet: !!b._nb });
      if (i < blocks.length - 1) p[p.length - 1].options.breakLine = true;
      arr.push(...p);
    });
    sl.addText(arr, { x: snap(x + tx), y: snap(cy), w: snap(w - tx), h: snap(gh + 0.1), margin: 0, valign: "top", isTextBox: true, objectName: srcName(g), fit: "none" });
    cy += gh + gap;
  }
}

L.list = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  const withIcons = plan.profile.icons !== "minimal" && groups(s.items).length <= 6 && groups(s.items).every((g) => g[0].kind === "li");
  await listRows(sl, s, s.items, MX, Y0, CW, CH, withIcons);
};
L.split = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  let k = 0; while (k < s.items.length && s.items[k].kind !== "li") k++;
  const lead = s.items.slice(0, k), rest = s.items.slice(k);
  const lw = cols(5), pad = 0.32;
  sl.addShape("roundRect", { x: MX, y: Y0, w: lw, h: CH, rectRadius: 0.12, fill: { color: P.surface }, line: { color: P.surface, width: 0 }, objectName: "panel:lead" });
  const rx = MX + lw + 0.45, rw = W - MX - rx;
  const ricons = plan.profile.icons !== "minimal" && groups(rest).length <= 5;
  // 左右で本文の大きさをそろえる（同じ階層の文字は同じ大きさ＝類同）
  const lp0 = fitPt(metric(lead), lw - 2 * pad, CH - 2 * pad, D.bodyPt, D.floorPt);
  const rp0 = listPt(rest, rw, CH - 0.05, ricons);
  if (!lp0) warnings.push(`${s.id}: 左の段落が入りきらない見込み`);
  const pt = Math.min(lp0 || D.floorPt, rp0 || D.floorPt);
  textBox(sl, lead, MX + pad, Y0 + pad, lw - 2 * pad, CH - 2 * pad, { pt, label: true });
  await listRows(sl, s, rest, rx, Y0 + 0.05, rw, CH - 0.05, ricons, pt);
};
L.statement = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  const w = cols(8);
  const pt = fitPt(metric(s.items), w, CH - 0.6, D.bodyPt + 8, D.floorPt) || D.floorPt;
  const hh = Math.min(CH, heightOf(metric(s.items), pt, w) + 0.2);
  textBox(sl, s.items, MX, Y0 + (CH - hh) / 2, w, hh, { pt, label: true, color: P.text });
  const d = 2.7;
  sl.addShape("ellipse", { x: snap(W - MX - d), y: snap(Y0 + (CH - d) / 2), w: d, h: d, fill: { color: P.support }, line: { color: P.support, width: 0 }, objectName: `iconbg:${s.id}-big` });
  const isz = d * 0.46;
  sl.addImage({ data: await icon(s.icon === "LuQuote" ? "LuQuote" : s.icon, P.primary), x: snap(W - MX - d) + (d - isz) / 2, y: snap(Y0 + (CH - d) / 2) + (d - isz) / 2, w: isz, h: isz, objectName: `icon:${s.id}-big` });
};
L.cards = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  const gs = groups(s.items), n = gs.length;
  const rows = n <= 4 ? 1 : 2, per = Math.ceil(n / rows), gap = 0.3, pad = 0.3, icd = 0.6;
  const cw = (CW - (per - 1) * gap) / per;
  const ch = rows === 1 ? CH : (CH - gap) / 2;
  const stack = rows === 1; // 1段なら アイコンを上、2段なら左
  const tw = stack ? cw - 2 * pad : cw - 2 * pad - icd - 0.22;
  const th = stack ? ch - 2 * pad - icd - 0.25 : ch - 2 * pad;
  const ms = gs.map((g) => metric(g.map((b, i) => (i === 0 ? { ...b, kind: "p" } : { ...b, level: Math.max(0, (b.level || 0) - 1) }))));
  let pt = null;
  for (let p = D.bodyPt + 2; p >= D.floorPt; p--) if (ms.every((m) => heightOf(m, p, tw) <= th)) { pt = p; break; }
  if (!pt) { pt = D.floorPt; warnings.push(`${s.id}: カードの文字が入りきらない見込み → list に変えるか分ける`); }
  // 1段のときは、カードの高さを中身に合わせて詰める（下の空白を残さない）
  const need = Math.max(...ms.map((m) => heightOf(m, pt, tw)));
  const realCh = stack ? Math.min(ch, Math.max(need + 2 * pad + icd + 0.25 + 0.15, CH * 0.55)) : ch;
  const yOff = stack ? (CH - realCh) * 0.4 : 0;
  for (let i = 0; i < n; i++) {
    const r = Math.floor(i / per), c = i % per;
    const x = MX + c * (cw + gap), y = Y0 + yOff + r * (ch + gap);
    sl.addShape("roundRect", { x: snap(x), y: snap(y), w: snap(cw), h: snap(realCh), rectRadius: 0.1, fill: { color: P.surface }, line: { color: P.line, width: 0.75 }, shadow: shadow(), objectName: `panel:card${i}` });
    const ic = (s.itemIcons && s.itemIcons[i]) || "LuCircleCheck";
    const g = gs[i].map((b, k) => (k === 0 ? { ...b, _head: true } : { ...b, level: Math.max(0, (b.level || 0) - 1) }));
    const arr = [];
    g.forEach((b, k) => {
      const hasLabel = !!b._head && /^[^\n：:]{1,18}?[：:]./s.test(b.text) && !(b.runs[0].b || b.runs[0].code || b.runs[0].link);
      const p = para(b, { pt, label: hasLabel, noBullet: !!b._head, bold: !!b._head && !hasLabel });
      if (hasLabel) { p[0].options.breakLine = false; }
      if (k < g.length - 1) p[p.length - 1].options.breakLine = true;
      arr.push(...p);
    });
    if (stack) {
      await iconInCircle(sl, ic, x + pad, y + pad, icd, P.primary, P.onPrimary, `${s.id}-c${i}`);
      sl.addText(arr, { x: snap(x + pad), y: snap(y + pad + icd + 0.25), w: snap(tw), h: snap(realCh - 2 * pad - icd - 0.25), margin: 0, valign: "top", isTextBox: true, objectName: srcName(gs[i]) });
    } else {
      await iconInCircle(sl, ic, x + pad, y + pad, icd, P.primary, P.onPrimary, `${s.id}-c${i}`);
      sl.addText(arr, { x: snap(x + pad + icd + 0.22), y: snap(y + pad), w: snap(tw), h: snap(th), margin: 0, valign: "top", isTextBox: true, objectName: srcName(gs[i]) });
    }
  }
};
L.steps = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  const gs = groups(s.items), n = gs.length, d = 0.8, gap = 0.3;
  const segW = (CW - (n - 1) * gap) / n;
  const tw0 = segW - 0.05;
  const ms0 = gs.map((g) => metric(g.map((b, k) => (k === 0 ? { ...b, kind: "p" } : { ...b, level: Math.max(0, (b.level || 0) - 1) }))));
  let need0 = 0; for (let p = D.bodyPt; p >= D.floorPt; p--) { need0 = Math.max(...ms0.map((m) => heightOf(m, p, tw0))); if (need0 <= CH - d - 0.6) break; }
  const cy = Y0 + Math.max(0.25, (CH - (d + 0.35 + need0)) * 0.4);
  for (let i = 0; i < n - 1; i++) {
    const x1 = MX + i * (segW + gap) + d + 0.12, x2 = MX + (i + 1) * (segW + gap) - 0.12;
    sl.addShape("line", { x: snap(x1), y: snap(cy + d / 2), w: snap(x2 - x1), h: 0, line: { color: P.line, width: 2, endArrowType: "triangle" }, objectName: `deco:arrow${i}` });
  }
  const tw = segW - 0.05, th = Y1 - (cy + d + 0.35);
  const ms = gs.map((g) => metric(g.map((b, k) => (k === 0 ? { ...b, kind: "p" } : { ...b, level: Math.max(0, (b.level || 0) - 1) }))));
  let pt = null;
  for (let p = D.bodyPt; p >= D.floorPt; p--) if (ms.every((m) => heightOf(m, p, tw) <= th)) { pt = p; break; }
  if (!pt) { pt = D.floorPt; warnings.push(`${s.id}: 手順の文字が入りきらない見込み`); }
  for (let i = 0; i < n; i++) {
    const x = MX + i * (segW + gap);
    sl.addShape("ellipse", { x: snap(x), y: snap(cy), w: d, h: d, fill: { color: i === n - 1 ? P.accent : P.primary }, line: { color: P.bg, width: 0 }, objectName: `iconbg:${s.id}-st${i}` });
    sl.addText(String(i + 1), { x: snap(x), y: snap(cy), w: d, h: d, margin: 0, align: "center", valign: "middle", fontSize: 24, bold: true, color: i === n - 1 ? P.onAccent : P.onPrimary, fontFace: F.head, isTextBox: true, objectName: "meta:stepno" });
    const g = gs[i].map((b, k) => (k === 0 ? { ...b, _head: true } : { ...b, level: Math.max(0, (b.level || 0) - 1) }));
    const arr = [];
    g.forEach((b, k) => {
      const p = para(b, { pt, label: true, noBullet: !!b._head, bold: !!b._head && !/[：:]/.test(b.text.slice(0, 19)) });
      if (k < g.length - 1) p[p.length - 1].options.breakLine = true;
      arr.push(...p);
    });
    sl.addText(arr, { x: snap(x), y: snap(cy + d + 0.35), w: snap(tw), h: snap(th), margin: 0, valign: "top", isTextBox: true, objectName: srcName(gs[i]) });
  }
};
L.table = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  const lead = s.items.filter((b) => b.kind !== "table"), tb = s.items.find((b) => b.kind === "table");
  let y = Y0;
  if (lead.length) {
    const lp = fitPt(metric(lead), CW, 1.2, D.bodyPt, D.floorPt) || D.floorPt;
    const lh = heightOf(metric(lead), lp, CW) + 0.1;
    textBox(sl, lead, MX, y, CW, lh, { pt: lp, label: true }); y += lh + 0.25;
  }
  const sel = tb.rowsel || tb.rows.map((_, i) => i);
  const rows = sel.map((i) => tb.rows[i]), rruns = sel.map((i) => (tb.rows_runs ? tb.rows_runs[i] : tb.rows[i].map((t) => [{ t }])));
  const nc = Math.max(...rows.map((r) => r.length));
  const num = (t) => /^[\s¥$€￥+\-−]?[\d,.]+\s*(%|円|件|名|人|時間|分|日|h|ms|GB|MB)?$/.test(t.trim());
  const isNumCol = [...Array(nc)].map((_, c) => rows.slice(1).length > 0 && rows.slice(1).every((r) => !r[c] || num(r[c])));
  const wts = [...Array(nc)].map((_, c) => Math.min(Math.max(...rows.map((r) => units(r[c] || ""))), 40) + 3);
  const tot = wts.reduce((a, b) => a + b, 0);
  const colW = wts.map((v) => +(CW * v / tot).toFixed(3));
  const availH = Y1 - y;
  let pt = null;
  const minT = Math.max(12, D.floorPt - 4);
  for (let p = D.bodyPt; p >= minT; p--) {
    const hh = rows.reduce((a, r) => a + Math.max(...r.map((t, c) => linesOf(t || "", p, colW[c] - 0.2))) * LH(p) + 0.16, 0);
    if (hh <= availH) { pt = p; break; }
  }
  if (!pt) { pt = minT; warnings.push(`${s.id}: 表が入りきらない見込み → tableRows を下げて plan し直す`); }
  const al = tb.align || [];
  const data = rows.map((r, ri) => r.map((t, c) => {
    const cellRuns = (rruns[ri] && rruns[ri][c]) || [{ t: t || "" }];
    const txt = cellRuns.map((cr) => ({ text: cr.t, options: { bold: ri === 0 || !!cr.b, fontFace: cr.code ? F.mono : F.body, fontSize: pt, color: ri === 0 ? P.onPrimary : P.text } }));
    return { text: txt.length ? txt : "", options: {
      fill: { color: ri === 0 ? P.primary : (ri % 2 === 0 ? P.surface : P.bg) },
      align: al[c] === "right" || isNumCol[c] ? "right" : (al[c] === "center" ? "center" : "left"),
      valign: "middle", fontSize: pt, margin: [0.06, 0.1, 0.06, 0.1].map((v) => v * 72),
      border: [{ type: "none" }, { type: "none" }, { pt: 0.75, color: P.line }, { type: "none" }],
    } };
  }));
  sl.addTable(data, { x: MX, y: snap(y), w: CW, colW, fontFace: F.body, fontSize: pt, objectName: `src:${tb.id}@${sel.join(",")}`, autoPage: false });
};
L.code = async (pres, s) => {
  const sl = pres.addSlide(); sl.background = { color: P.bg }; await frame(sl, s);
  const lead = s.items.filter((b) => b.kind !== "code"), cb = s.items.find((b) => b.kind === "code");
  let y = Y0;
  if (lead.length) {
    const lp = fitPt(metric(lead), CW, 1.5, D.bodyPt, D.floorPt) || D.floorPt;
    const lh = heightOf(metric(lead), lp, CW) + 0.1;
    textBox(sl, lead, MX, y, CW, lh, { pt: lp, label: true }); y += lh + 0.25;
  }
  const pad = 0.3, maxH = Y1 - y;
  const pt = fitPt([{ text: cb.text }], CW - 2 * pad, maxH - 2 * pad, 20, 12, { mono: true });
  const ph = Math.min(maxH, Math.max(1.6, heightOf([{ text: cb.text }], pt || 12, CW - 2 * pad, { mono: true }) * (1.0 / LS) + 2 * pad + 0.1));
  sl.addShape("roundRect", { x: MX, y: snap(y), w: CW, h: snap(ph), rectRadius: 0.1, fill: { color: P.codeBg }, line: { color: P.codeBg, width: 0 }, objectName: "panel:code" });
  if (!pt) warnings.push(`${s.id}: コードが入りきらない見込み → codeLines を下げる`);
  const p = para(cb, { pt: pt || 12, mono: true, color: P.codeText });
  p.forEach((r) => { r.options.lineSpacingMultiple = 1.0; });
  sl.addText(p, { x: MX + pad, y: snap(y) + pad, w: CW - 2 * pad, h: snap(ph) - 2 * pad, margin: 0, valign: "top", isTextBox: true, objectName: srcName([cb]) });
};

(async () => {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE";
  pres.theme = { headFontFace: F.head, bodyFontFace: F.body };
  pres.title = plan.source;
  for (const s of plan.slides) {
    const fn = L[s.layout] || L.list;
    if (!L[s.layout]) warnings.push(`${s.id}: 未知の layout ${s.layout} → list`);
    await fn(pres, s);
  }
  await pres.writeFile({ fileName: outPath });
  // テーマの色も揃える（PowerPoint で後から色を変える人のため）。pptx スキルがあれば使う。
  const at = "/mnt/skills/public/pptx/scripts/apply_theme.js";
  if (fs.existsSync(at)) {
    try {
      await require(at).applyTheme(outPath, { name: plan.profile.brand || `spec-deck ${plan.persona}`, colors: {
        dk1: P.text, lt1: P.bg, dk2: P.primary, lt2: P.surface, accent1: P.primary, accent2: P.accent,
        accent3: "0072B2", accent4: "009E73", accent5: "CC79A7", accent6: "56B4E9", hlink: P.primary, folHlink: P.muted } });
    } catch (e) { warnings.push("theme: " + e.message); }
  }
  console.log(`[build] ${plan.slides.length} slides -> ${outPath}`);
  warnings.forEach((w) => console.log("[build] WARN", w));
})();
