#!/usr/bin/env python3
"""原文（要件書・README・仕様書）を「文字を変えずに」ブロックへ分解して source.json に書き出す。

使い方:
  python extract_source.py 要件書.md   -o source.json
  python extract_source.py 仕様書.docx -o source.json
  python extract_source.py README.txt  -o source.json [--heading-regex '^(■|【.+】)']

ここで消えるのは「書式の記号」だけ（Markdown の # - 1. ** ` [ ](url) | ``` > など）。
文字・句読点・全角半角・語順・改行位置は一切変えない。記号を外した結果は
source.json の blocks[].runs に入り、verify_text.py が最後に一字一句照合する。

ブロックの種類 (kind):
  h1..h6 見出し / p 段落 / li 箇条書き(level, ordered) / table 表(rows) / code コード / quote 引用 / hr 区切り
"""
import argparse, json, re, sys
from pathlib import Path

INLINE = re.compile(r"(\*\*(?P<b>.+?)\*\*|__(?P<b2>.+?)__|`(?P<c>[^`]+)`|\[(?P<lt>[^\]]+)\]\((?P<lu>[^)\s]+)\)|(?<![\*\w])\*(?P<i>[^*\n]+?)\*(?![\*\w]))")


def parse_inline(s):
    """インライン記法を runs に。文字は変えず、記号だけ外す。"""
    runs, pos = [], 0
    for m in INLINE.finditer(s):
        if m.start() > pos:
            runs.append({"t": s[pos:m.start()]})
        if m.group("b") is not None or m.group("b2") is not None:
            runs.append({"t": m.group("b") or m.group("b2"), "b": True})
        elif m.group("c") is not None:
            runs.append({"t": m.group("c"), "code": True})
        elif m.group("lt") is not None:
            runs.append({"t": m.group("lt"), "link": m.group("lu")})
        elif m.group("i") is not None:
            runs.append({"t": m.group("i"), "i": True})
        pos = m.end()
    if pos < len(s):
        runs.append({"t": s[pos:]})
    return [r for r in runs if r["t"] != ""] or [{"t": ""}]


def plain(runs):
    return "".join(r["t"] for r in runs)


class Builder:
    def __init__(self):
        self.blocks = []

    def add(self, kind, **kw):
        b = {"id": f"b{len(self.blocks)+1:03d}", "kind": kind}
        b.update(kw)
        if "runs" in b:
            b["text"] = plain(b["runs"])
        self.blocks.append(b)
        return b


def split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|") and not line.endswith("\\|"):
        line = line[:-1]
    cells = re.split(r"(?<!\\)\|", line)
    return [c.strip().replace("\\|", "|") for c in cells]


def from_markdown(text):
    B = Builder()
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    i = 0
    # YAML front matter は本文ではないので除外（除外した事実は notes に残す）
    notes = []
    if lines and lines[0].strip() == "---":
        for j in range(1, len(lines)):
            if lines[j].strip() == "---":
                notes.append(f"front matter {j+1} 行を除外")
                i = j + 1
                break
    para = []

    def flush():
        nonlocal para
        if para:
            # 段落内の改行は原文どおり \n で保持（勝手に連結しない）
            B.add("p", runs=parse_inline("\n".join(para)))
            para = []

    list_indent_unit = None
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if s.startswith("```") or s.startswith("~~~"):
            flush()
            fence = s[:3]
            lang = s[3:].strip()
            buf = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith(fence):
                buf.append(lines[i])
                i += 1
            B.add("code", lang=lang, runs=[{"t": "\n".join(buf), "code": True}])
            i += 1
            continue
        if s == "":
            flush(); i += 1; continue
        m = re.match(r"^(#{1,6})\s+(.*?)\s*#*\s*$", s)
        if m:
            flush()
            B.add(f"h{len(m.group(1))}", runs=parse_inline(m.group(2)))
            i += 1; continue
        if re.match(r"^(\*\s*){3,}$|^(-\s*){3,}$|^(_\s*){3,}$", s):
            flush(); B.add("hr", runs=[{"t": ""}]); i += 1; continue
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\s*\|?\s*:?-{2,}", lines[i+1]):
            flush()
            header = split_row(s)
            aligns = []
            for c in split_row(lines[i+1]):
                aligns.append("right" if c.endswith(":") and not c.startswith(":") else "center" if c.startswith(":") and c.endswith(":") else "left")
            rows = [header]
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            B.add("table", rows=[[plain(parse_inline(c)) for c in r] for r in rows],
                  rows_runs=[[parse_inline(c) for c in r] for r in rows], align=aligns,
                  runs=[{"t": "\n".join("\t".join(plain(parse_inline(c)) for c in r) for r in rows)}])
            continue
        m = re.match(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$", ln)
        if m:
            flush()
            ind = len(m.group(1).replace("\t", "    "))
            if ind and list_indent_unit is None:
                list_indent_unit = 2 if ind < 4 else 4
            level = ind // (list_indent_unit or 2)
            ordered = m.group(2)[0].isdigit()
            body = m.group(3)
            check = None
            cm = re.match(r"^\[( |x|X)\]\s+(.*)$", body)
            if cm:
                check = cm.group(1).lower() == "x"; body = cm.group(2)
            # 箇条書きの継続行（字下げされた次行）を同じ項目に \n で保持
            j = i + 1
            while j < len(lines) and lines[j].strip() and not re.match(r"^\s*([-*+]|\d+[.)])\s+", lines[j]) \
                    and (len(lines[j]) - len(lines[j].lstrip())) > ind and not lines[j].strip().startswith(("#", "|", "```")):
                body += "\n" + lines[j].strip(); j += 1
            kw = dict(level=level, ordered=ordered, runs=parse_inline(body))
            if ordered:
                kw["marker"] = m.group(2)
            if check is not None:
                kw["checked"] = check
            B.add("li", **kw)
            i = j; continue
        if s.startswith(">"):
            flush()
            buf = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                buf.append(re.sub(r"^\s*>\s?", "", lines[i])); i += 1
            B.add("quote", runs=parse_inline("\n".join(buf)))
            continue
        para.append(s)
        i += 1
    flush()
    return B.blocks, notes


def from_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path)
    B = Builder()
    body = d.element.body
    # 「表題」スタイルがあれば 見出し1 は h2 として扱う（表紙 → 中扉 → スライドの3段にそろえる）
    has_title = any((p.style is not None and p.style.name == "Title") for p in d.paragraphs)
    off = 1 if has_title else 0
    for el in body.iterchildren():
        tag = el.tag.split("}")[-1]
        if tag == "p":
            p = Paragraph(el, d)
            txt = p.text
            if not txt.strip():
                continue
            style = (p.style.name or "") if p.style is not None else ""
            runs = []
            for r in p.runs:
                if r.text:
                    rr = {"t": r.text}
                    if r.bold: rr["b"] = True
                    if r.italic: rr["i"] = True
                    runs.append(rr)
            if plain(runs) != txt:  # ハイパーリンク等で runs が欠けた場合は原文を優先
                runs = [{"t": txt}]
            m = re.match(r"(Heading|見出し)\s*(\d)", style)
            if style == "Title":
                B.add("h1", runs=runs)
            elif m:
                B.add(f"h{min(int(m.group(2)) + off, 6)}", runs=runs)
            else:
                numpr = el.find(".//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}numPr")
                lm = re.search(r"List (Bullet|Number|Paragraph)\s*(\d)?", style)
                if numpr is not None or lm:
                    lvl = 0
                    if numpr is not None:
                        il = numpr.find("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ilvl")
                        if il is not None:
                            lvl = int(il.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val", "0"))
                    elif lm and lm.group(2):
                        lvl = int(lm.group(2)) - 1
                    B.add("li", level=lvl, ordered=bool(lm and lm.group(1) == "Number"), runs=runs)
                else:
                    B.add("p", runs=runs)
        elif tag == "tbl":
            t = Table(el, d)
            rows = [[c.text for c in r.cells] for r in t.rows]
            B.add("table", rows=rows, rows_runs=[[[{"t": c}] for c in r] for r in rows],
                  align=["left"] * (len(rows[0]) if rows else 0),
                  runs=[{"t": "\n".join("\t".join(r) for r in rows)}])
    return B.blocks, []


def from_text(text, heading_regex=None):
    B = Builder()
    hre = re.compile(heading_regex) if heading_regex else None
    for chunk in re.split(r"\n\s*\n", text.replace("\r\n", "\n")):
        lines = [l.rstrip() for l in chunk.split("\n") if l.strip()]
        if not lines:
            continue
        if hre and len(lines) == 1 and hre.search(lines[0]):
            B.add("h3", runs=[{"t": lines[0]}])
        else:
            B.add("p", runs=[{"t": "\n".join(lines)}])
    return B.blocks, []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", default="source.json")
    ap.add_argument("--heading-regex", default=None, help="txt用: 1行だけの段落を見出し扱いにする正規表現")
    a = ap.parse_args()
    p = Path(a.src)
    ext = p.suffix.lower()
    if ext in (".md", ".markdown"):
        blocks, notes = from_markdown(p.read_text(encoding="utf-8"))
    elif ext == ".docx":
        blocks, notes = from_docx(p)
    elif ext in (".txt", ".text", ""):
        blocks, notes = from_text(p.read_text(encoding="utf-8"), a.heading_regex)
    else:
        sys.exit(f"未対応の形式: {ext}（PDFは `pdftotext -layout x.pdf x.txt` してから .txt で渡す）")
    out = {"source": p.name, "notes": notes, "blocks": blocks}
    Path(a.out).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    kinds = {}
    for b in blocks:
        kinds[b["kind"]] = kinds.get(b["kind"], 0) + 1
    chars = sum(len(b.get("text", "")) for b in blocks)
    print(f"[extract] {len(blocks)} blocks / {chars} chars -> {a.out}  {kinds}")
    for n in notes:
        print("[extract] note:", n)


if __name__ == "__main__":
    main()
