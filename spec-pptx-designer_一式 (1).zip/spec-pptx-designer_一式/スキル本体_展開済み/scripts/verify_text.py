#!/usr/bin/env python3
"""原文（source.json）とスライド（deck.pptx）の文字を一字一句照合する。改変ゼロでなければ終了コード 1。

  python verify_text.py source.json deck.pptx [--report verify.json]

確認すること
  1. 原文のブロックがすべてスライドにある（抜け落ちゼロ）
  2. 各ブロックの文字が原文と完全一致（全角半角・句読点・空白・改行位置まで）
  3. 文末で分けたブロックは、部品をつなぐと原文と完全一致
  4. 表は全セルが一致し、全行がどこかのスライドに載っている
  5. 原文に無い文字がスライドに無い（名前の無い文字図形、meta に数字以外が入っている、を検出）
  6. 原文の順序どおりに並んでいる
polish.py で手直しした後や、PowerPoint で手作業した後にも必ずもう一度流す。
"""
import argparse, json, re, sys
from pathlib import Path
from pptx import Presentation

META_OK = re.compile(r"^[0-9０-９/／\s]*$")


def ptext(p):
    return "".join(r.text for r in p.runs) if False else p.text.replace("\v", "\n").replace("\x0b", "\n")


def show(s, n=60):
    s = s.replace("\n", "⏎")
    return s if len(s) <= n else s[:n] + "…"


def first_diff(a, b):
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y:
            return i
    return min(len(a), len(b)) if len(a) != len(b) else -1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source"); ap.add_argument("deck"); ap.add_argument("--report", default=None)
    a = ap.parse_args()
    src = json.loads(Path(a.source).read_text(encoding="utf-8"))
    blocks = {b["id"]: b for b in src["blocks"]}
    order = {b["id"]: i for i, b in enumerate(src["blocks"])}
    prs = Presentation(a.deck)

    errors, warns = [], []
    seen_whole = set()
    parts = {}       # id -> {partno: text}
    table_rows = {}  # id -> set(rows)
    seq = []

    def expect(bid, got, where, part=None):
        if bid not in blocks:
            errors.append(f"{where}: 原文に無いブロック {bid}"); return
        b = blocks[bid]
        if part:
            parts.setdefault(bid, {})[part] = got
            seq.append(bid); return
        exp = b["text"]
        if got != exp:
            i = first_diff(got, exp)
            errors.append(f"{where}: {bid} が原文と不一致（{i}文字目）\n    原文: {show(exp[max(0,i-10):])}\n    PPT : {show(got[max(0,i-10):])}")
        seen_whole.add(bid); seq.append(bid)

    for si, slide in enumerate(prs.slides, 1):
        for sh in slide.shapes:
            name = sh.name or ""
            where = f"slide{si} [{name}]"
            if sh.has_table if hasattr(sh, "has_table") else False:
                m = re.match(r"^src:(b\d+)@([\d,]+)$", name)
                if not m:
                    errors.append(f"{where}: 名前の無い表（原文との対応が取れない）"); continue
                bid, rows = m.group(1), [int(x) for x in m.group(2).split(",")]
                b = blocks.get(bid)
                if not b:
                    errors.append(f"{where}: 原文に無い表 {bid}"); continue
                tbl = sh.table
                for ri, srcr in enumerate(rows):
                    for ci, exp in enumerate(b["rows"][srcr]):
                        try:
                            got = tbl.cell(ri, ci).text.replace("\v", "\n")
                        except IndexError:
                            errors.append(f"{where}: {bid} 行{srcr} 列{ci} が無い"); continue
                        if got != exp:
                            errors.append(f"{where}: {bid} 行{srcr} 列{ci} 不一致\n    原文: {show(exp)}\n    PPT : {show(got)}")
                table_rows.setdefault(bid, set()).update(rows)
                seq.append(bid)
                continue
            if not sh.has_text_frame:
                continue
            paras = [ptext(p) for p in sh.text_frame.paragraphs]
            alltext = "\n".join(paras)
            if name.startswith("meta:"):
                if not META_OK.match(alltext):
                    errors.append(f"{where}: meta に数字以外の文字「{show(alltext)}」（原文に無い文字の追加）")
                continue
            if name.startswith("rep:"):
                bid = name[4:]
                if bid in blocks and alltext != blocks[bid]["text"]:
                    errors.append(f"{where}: 繰り返し見出し {bid} が原文と不一致")
                continue
            if name.startswith("src:"):
                ids = name[4:].split(",")
                if len(paras) != len(ids):
                    errors.append(f"{where}: 段落数 {len(paras)} ≠ ブロック数 {len(ids)}（段落の結合・分割が起きている）")
                    continue
                for ref, got in zip(ids, paras):
                    if "#" in ref:
                        bid, pn = ref.split("#"); expect(bid, got, where, part=int(pn))
                    else:
                        expect(ref, got, where)
                continue
            if alltext.strip():
                errors.append(f"{where}: 原文と対応しない文字「{show(alltext)}」（追加された文字の可能性）")

    # 分割部品の結合チェック
    for bid, pd in parts.items():
        b = blocks[bid]
        joined = ("\n" if b["kind"] == "code" else "").join(pd[k] for k in sorted(pd))
        if joined != b["text"]:
            i = first_diff(joined, b["text"])
            errors.append(f"{bid}: 分割部品をつないだ文字が原文と不一致（{i}文字目）\n    原文: {show(b['text'][max(0,i-10):])}\n    PPT : {show(joined[max(0,i-10):])}")
        seen_whole.add(bid)
    for bid, rs in table_rows.items():
        allr = set(range(len(blocks[bid]["rows"])))
        if rs != allr:
            errors.append(f"{bid}: 表の行 {sorted(allr - rs)} がどのスライドにも無い")
        seen_whole.add(bid)

    missing = [bid for bid, b in blocks.items() if b["kind"] != "hr" and bid not in seen_whole]
    for bid in missing:
        errors.append(f"{bid}: スライドに無い（抜け落ち）「{show(blocks[bid]['text'])}」")

    # 順序
    last = -1
    for bid in seq:
        if bid in order:
            if order[bid] < last:
                warns.append(f"{bid}: 原文より前に出ている（順序の入れ替え）")
            last = max(last, order[bid])

    total = sum(1 for b in blocks.values() if b["kind"] != "hr")
    ok = not errors
    print(f"[verify] {'PASS' if ok else 'FAIL'}  原文 {total} ブロック / 一致 {total - len(missing)} / 不一致・追加 {len(errors) - len(missing)} / 抜け {len(missing)}")
    for e in errors:
        print("  ✗", e)
    for w in warns:
        print("  △", w)
    if a.report:
        Path(a.report).write_text(json.dumps({"pass": ok, "errors": errors, "warnings": warns}, ensure_ascii=False, indent=1), encoding="utf-8")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
