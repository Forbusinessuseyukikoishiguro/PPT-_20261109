# 色彩学の根拠 → 配色規則

## 目次
1. 配色の骨格（主色・補助・差し色・背景）
2. コントラスト（読めること）
3. 色覚の多様性（誰でも区別できること）
4. 色の印象（ペルソナ別の主色）
5. 調和（似た色相＋明度差）
6. 注意して扱う研究
7. 参考文献・規格

## 1. 配色の骨格
| 役割 | キー | 使いどころ | 面積の目安 |
|---|---|---|---|
| 背景 | bg / surface | スライド地・カード地 | 6〜7割 |
| 主色 | primary | 表紙・中扉・見出し語・アイコンの丸・表の見出し行 | 2〜3割 |
| 補助 | support / line | 行頭アイコンの丸・罫線 | 1割 |
| 差し色 | accent | 1枚に1か所（手順の最後・表紙装飾） | ごく少し |
| 文字 | text / muted / onPrimary / onAccent | 本文・補足・濃い地の上の文字 | — |

有彩色の塗りはデッキ全体で6色以内（`check_design.py color`）。

## 2. コントラスト
- 規格：WCAG 2.2（W3C, 2023）達成基準 1.4.3 — 本文 4.5:1 以上、大きい文字（18pt 以上、または 14pt 以上の太字）3:1 以上。1.4.11 — アイコンなど意味のある図形 3:1 以上。日本では JIS X 8341-3:2016 が WCAG 2.0 と一致。
- 文字色と背景色の組み合わせは、読みやすさと印象の評価に影響する（Hall & Hanna, 2004）。
- 実装：`check_design.py --palettes` が profiles.json の全ペルソナの組み合わせを判定、`check_design.py deck.pptx` が実際の文字・アイコンを判定（アイコンは画像の線の色を読み取って下地と比べる）。

## 3. 色覚の多様性
- 日本の男性の約5%は色の見え方が一般と異なる。赤と緑だけで区別させない（Wong, 2011）。
- 色だけに意味を持たせない：手順の最後は色に加えて位置と番号でも示す。表の数値は色ではなく右揃えと罫線で区別する。
- 系列が多い図表は Okabe–Ito 配色（テーマの accent3〜6 に設定済み）を使う。順序のある値は単一色相の明度段階（Harrower & Brewer, 2003）。

## 4. 色の印象（ペルソナ別の主色の理由）
- 色の印象（暖かい・重い・活動的など）は少数の次元で安定して測れる（Ou, Luo, Woodcock & Wright, 2004）。色は文脈しだいで心理的機能に影響する（Elliot & Maier, 2014）。
- 好みは、その色から連想される物の好ましさで説明できる（Palmer & Schloss, 2010）。深い青緑・紺・緑は「水・空・植物」と結び付きやすく、法人研修の主色として無難。
- 割り当て：新人 = 深い青緑（落ち着き＋親しみ）、エンジニア = 青みのスレート（中立・情報優先）、決裁者 = 紺＋金（重み・信頼）、業務部門 = 緑（安心・前進）、資格 = 藍（体系・集中）、顧客 = 深い青＋コーラル（信頼＋印象）。
- 会社のブランド色があれば、それが最優先（profiles.json の palette を差し替え、`--palettes` で再判定）。

## 5. 調和
- 色の組み合わせの調和は、色相が近く明度に差がある組み合わせで高く評価されやすい（Schloss & Palmer, 2011）。
- 規則：surface・support・line は主色と同じ色相で明度だけを上げた色。差し色だけ色相を離す。

## 6. 注意して扱う研究
- 「赤は細部の注意、青は創造性を高める」（Mehta & Zhu, 2009）は追試で一貫しない結果も報告されている。このスキルでは色で成績が上がるとは主張せず、可読性・区別しやすさ・一貫性の根拠だけに色を使う。研修で受講者に説明するときも同様に扱う。

## 7. 参考文献・規格
- Elliot, A. J., & Maier, M. A. (2014). Color psychology: Effects of perceiving color on psychological functioning in humans. *Annual Review of Psychology, 65*, 95–120.
- Hall, R. H., & Hanna, P. (2004). The impact of web page text-background colour combinations on readability, retention, aesthetics and behavioural intention. *Behaviour & Information Technology, 23*(3), 183–195.
- Harrower, M., & Brewer, C. A. (2003). ColorBrewer.org: An online tool for selecting colour schemes for maps. *The Cartographic Journal, 40*(1), 27–37.
- Mehta, R., & Zhu, R. (2009). Blue or red? Exploring the effect of color on cognitive task performances. *Science, 323*(5918), 1226–1229.
- Ou, L.-C., Luo, M. R., Woodcock, A., & Wright, A. (2004). A study of colour emotion and colour preference. Part I: Colour emotions for single colours. *Color Research & Application, 29*(3), 232–240.
- Palmer, S. E., & Schloss, K. B. (2010). An ecological valence theory of human color preference. *PNAS, 107*(19), 8877–8882.
- Sharma, G., Wu, W., & Dalal, E. N. (2005). The CIEDE2000 color-difference formula: Implementation notes, supplementary test data, and mathematical observations. *Color Research & Application, 30*(1), 21–30.（brand.py が会社の許可色へ寄せるときの色差）
- Schloss, K. B., & Palmer, S. E. (2011). Aesthetic response to color combinations: Preference, harmony, and similarity. *Attention, Perception, & Psychophysics, 73*(2), 551–571.
- Wong, B. (2011). Points of view: Color blindness. *Nature Methods, 8*(6), 441.
- 規格：W3C (2023) WCAG 2.2 / JIS X 8341-3:2016。配色セット：Okabe, M., & Ito, K. (2008) Color Universal Design（Web 資料・査読なし）。
