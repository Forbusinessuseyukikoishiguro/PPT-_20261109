# 認知科学の根拠 → このスキルのデザイン規則

文字を変えられない制約の中で、デザインだけで「読みやすさ・覚えやすさ」を上げるための規則と、その根拠。
外部の資料に引用するときは、必ず原典（DOI）を確認してから使う。

## 目次
1. 作業記憶と「1枚あたりの塊」
2. 熟達度で密度を変える（ペルソナ別の根拠）
3. 分割注意と近接（絵と言葉を隣に）
4. 合図（signaling）— 文字を変えずに要点を示す
5. 前注意的な目立ち — 差し色は1色
6. ゲシュタルト — 整列・近接・類同
7. 行の長さと文字の大きさ
8. 参考文献

## 1. 作業記憶と「1枚あたりの塊」
- 短期的に保持できるのは約4つの塊（Cowan, 2001）。古典的な「7±2」（Miller, 1956）は、塊のまとめ方しだいで変わる上限として読む。
- 規則：1枚の塊数 `maxChunks` を persona ごとに 3〜6 に設定（初学者・決裁者は少なく）。塊 = 第1階層の箇条書き1項目（子を含む）、段落1つ、表1つ、コード1つ。
- 実装：`plan_deck.py` が塊を数えてページを分け、ページ間で数をならす（1塊だけ残る孤立ページを作らない）。

## 2. 熟達度で密度を変える
- 初学者に効く補助（説明の重複、図と文の併記）は、熟達者には余計な処理となり学習を下げる＝熟達度逆転効果（Kalyuga, Ayres, Chandler & Sweller, 2003）。
- 規則：`shinjin`/`nontech` はアイコン・番号・カードを厚く、`engineer` は密度を上げ行頭アイコンを省く（`icons: minimal`）。

## 3. 分割注意と近接
- 図と、それを説明する文が離れていると、読み手は頭の中で統合する負荷を負う（Chandler & Sweller, 1991; Sweller, 1988）。
- 規則：アイコンは対応する文の左隣（行頭）か真上（カード）に置き、`polish.py icons` で1行目の文字の中心に合わせる。

## 4. 合図（signaling）
- 構造を示す手がかり（見出し・番号・強調）は、本質的でない処理を減らす（Mayer & Moreno, 2003）。
- 規則（文字は変えない）：
  - 「目的：〜」のように「：」の前が18字以内なら、その見出し語を主色の太字にする（文字は同じ、書式だけ）。
  - 番号付きの箇条書き（3〜6項目）は手順図（steps）にする。番号は書式記号なので図形として描く。
- 言葉と絵の二重符号化（Paivio, 1991）を、アイコン＋文で利用する。アイコンは意味の補助で、装飾目的の絵は置かない。

## 5. 前注意的な目立ち
- 色などの単一特徴は、探さなくても目に飛び込む（Treisman & Gelade, 1980）。目立つ色が複数あると、どれも目立たなくなる。
- 規則：差し色（accent）は1色だけ。手順の最後の丸、表紙の装飾など、1枚に1か所まで。

## 6. ゲシュタルト（整列・近接・類同）
- 近いもの・似たものは1つのまとまりとして知覚される（Wagemans et al., 2012）。
- 規則：12列グリッド・0.05in 格子に置く／同じ役割の図形は同じ大きさ・同じ位置／左端の種類を減らす。
- 実装：`polish.py grid, align, title, icons`。`check_design.py` が左端の種類・格子外れ・タイトル位置のぶれを数える。

## 7. 行の長さと文字の大きさ
- 画面上の読みでは、行の長さが読みの速さと理解に影響する（Dyson, 2004）。極端に長い行・極端に狭い段組はどちらも避ける。
- 規則：本文は 14〜22pt（persona×purpose 別、下限 14pt）、タイトル 28〜34pt。下限で入らなければ文字を小さくせずスライドを分ける。デッキ内の本文サイズは揃える（1枚だけ大きい・小さいを作らない）。
- 本文は左揃え（中央揃えは行頭が揃わず読みにくい）。中央は数字の丸の中だけ。

## 8. 参考文献（査読付き論文）
- Chandler, P., & Sweller, J. (1991). Cognitive load theory and the format of instruction. *Cognition and Instruction, 8*(4), 293–332.
- Cowan, N. (2001). The magical number 4 in short-term memory: A reconsideration of mental storage capacity. *Behavioral and Brain Sciences, 24*(1), 87–114.
- Dyson, M. C. (2004). How physical text layout affects reading from screen. *Behaviour & Information Technology, 23*(6), 377–393.
- Kalyuga, S., Ayres, P., Chandler, P., & Sweller, J. (2003). The expertise reversal effect. *Educational Psychologist, 38*(1), 23–31.
- Mayer, R. E., & Moreno, R. (2003). Nine ways to reduce cognitive load in multimedia learning. *Educational Psychologist, 38*(1), 43–52.
- Miller, G. A. (1956). The magical number seven, plus or minus two. *Psychological Review, 63*(2), 81–97.
- Paivio, A. (1991). Dual coding theory: Retrospect and current status. *Canadian Journal of Psychology, 45*(3), 255–287.
- Sweller, J. (1988). Cognitive load during problem solving: Effects on learning. *Cognitive Science, 12*(2), 257–285.
- Treisman, A. M., & Gelade, G. (1980). A feature-integration theory of attention. *Cognitive Psychology, 12*(1), 97–136.
- Wagemans, J., Elder, J. H., Kubovy, M., Palmer, S. E., Peterson, M. A., Singh, M., & von der Heydt, R. (2012). A century of Gestalt psychology in visual perception: I. Perceptual grouping and figure–ground organization. *Psychological Bulletin, 138*(6), 1172–1217.
