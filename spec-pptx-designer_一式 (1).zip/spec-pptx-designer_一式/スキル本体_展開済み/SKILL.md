---
name: spec-pptx-designer
description: "Turn 要件定義書・README・仕様書・設計書・研修資料の原稿 (Markdown / Word / テキスト / PDF) into a corporate-training-grade PowerPoint (.pptx) WITHOUT changing a single character — 文字は一字一句そのまま、改変禁止 — while the design is chosen by persona and purpose (新人・エンジニア・決裁者・業務部門・資格受講者・顧客 × 登壇・研修・配布・レビュー) on the basis of cognitive science, human-centered design (ISO 9241-210) and peer-reviewed color research, with WCAG contrast checks. Applies a company design-rule YAML (会社独自デザインルール: ブランド色, フォント, ロゴ, アイコン, 写真の縦横比・角丸・色の処理) to new or existing decks and audits violations. Also fine-tunes any existing .pptx: インデント統一, 行と列の整列（左端・上端・カード間隔・グリッド吸着・タイトル位置）, アイコンの大きさ・位置・色の統一, 表の揃え. Use this skill whenever someone says 「要件書をスライドに」「READMEをPPTに」「仕様書からパワポ」「文字は変えずにデザインだけ」「原文のままスライド化」「研修用のPPTを作って」「PPTの見た目を整えて」「インデントやアイコンを揃えて」「会社のデザインルールに合わせて」「ブランドガイドラインどおりに」「画像を社内ルールに」, or hands over a spec/README and asks for slides, even if they do not mention design theory."
---

# spec-pptx-designer（原文そのまま × 認知科学デザインの PPT）

原文の文字は **1字も変えない**。変えてよいのは「どこに・どんな形で・どんな色と大きさで置くか」だけ。
変えていないことは最後に `verify_text.py` が一字一句照合して証明する。PASS するまで納品しない。

最初に `/mnt/skills/public/pptx/SKILL.md` を読む（pptxgenjs の落とし穴と画像化QAの手順はそちらが正）。
根拠を説明するとき・規則を変えるときは `references/` を読む：
- `references/hcd-and-fidelity.md` — **改変禁止の定義（してよい／いけない）**、入りきらないときの判断順、HCD の進め方
- `references/cognitive-science.md` — 塊の数・熟達度・分割注意・合図・ゲシュタルト（査読論文つき）
- `references/color-science.md` — 配色の骨格・WCAG・色覚多様性・色の印象（査読論文つき）

## 0. 聞くこと（足りないときだけ、まとめて1回）
1. **誰が見るか**（persona）と **どう使うか**（purpose）。下の表から選んでもらう。言われなければ推測して、推測したことを一言書く。
2. 会社・ブランドの色やフォントの指定があるか（あれば palette を差し替える）
3. 映す環境（社外PCでUDフォントが無い可能性があれば `--font meiryo`）

| persona | 対象 | 1枚の塊 | 本文 |
|---|---|---|---|
| shinjin | 新人・初学者 | 4 | 20pt |
| engineer | 現場エンジニア | 6 | 16pt |
| executive | 管理職・決裁者 | 3 | 22pt |
| nontech | 業務部門・DX/AI説明 | 4 | 20pt |
| cert | 資格研修の受講者 | 5 | 18pt |
| client | 顧客・提案先 | 4 | 20pt |

| purpose | 使い方 | 密度 |
|---|---|---|
| live | 登壇（講師が話す） | 少なめ |
| training | 研修教材（話す＋読む） | 標準 |
| handout | 配布・事前に読む | 多め（本文-2pt） |
| review | 仕様レビュー会 | やや多め |

## 1. 一括実行（ふつうはこれだけ）
```bash
S=/mnt/skills/user/spec-pptx-designer/scripts   # 置き場所に合わせる
bash $S/make_deck.sh 要件定義書.md shinjin training 要件定義書_研修版
```
PDF は先に `pdftotext -layout x.pdf x.txt`。テキストの見出しは `--heading-regex '^(■|【.+】)'` を extract に渡す。

中で動く5段階（個別に流してもよい）：
| 段階 | スクリプト | すること |
|---|---|---|
| 抽出 | `extract_source.py` | 書式記号だけ外してブロック化（見出し・段落・箇条書き(階層)・表・コード・引用）。文字はそのまま |
| 構成 | `plan_deck.py` | 塊を数えてスライドに分け、レイアウトとアイコンを選ぶ。長い段落は文末でだけ分け、つなげて原文と一致を確認 |
| 生成 | `build_deck.js` | 12列グリッド・0.05in格子で配置。全図形に名前（`src:` 原文 / `rep:` 見出しの繰り返し / `meta:` 数字だけ / `icon:` など） |
| 微調整 | `polish.py` | sanitize・indent・grid・align・title・icons・table（下の §3） |
| 照合 | `verify_text.py` | 抜け・不一致・追加・順序を検出。**FAIL なら原因を直して作り直す** |
| 点検 | `check_design.py` | コントラスト・アイコンのコントラスト・文字サイズ下限・余白・重なり・密度・整列・アイコン統一・色数・タイトル位置 |

## 2. 目で見て直す（必須）
pptx スキルの手順で画像にし、全スライドを見る。機械が見逃すもの：
- カードや手順の中で、1語が不自然な位置で折り返している → plan.json で layout を list に、またはカード数を減らす
- 1枚だけ極端に空いている／詰まっている → plan.json でスライドを統合・分割
- アイコンの意味が内容と合わない → plan.json の `icon` / `itemIcons` を `assets/icon_keywords.json` の Lucide 名に差し替え

**plan.json で直してよいのは `layout`・`icon`・`itemIcons`・スライドの統合と分割（items の移動）だけ。`runs` と `text` は触らない。**
直したら `build_deck.js` → `polish.py` → `verify_text.py` → `check_design.py` をもう一度。

`build_deck.js` が `WARN … 入りきらない見込み` を出したら、`references/hcd-and-fidelity.md §3` の順（レイアウト変更 → 分割 → 文末分割 → 下限まで縮小）で直す。**文字を削る・短くするは選択肢に無い。**

レイアウト（plan が自動で選ぶ。手で変えてもよい）：
`cover` 表紙 / `section` 中扉 / `heading` 見出しだけの節 / `statement` 短い段落を大きく / `cards` 2〜6項目をカード / `steps` 番号付き3〜6項目を手順図 / `split` 段落＋箇条書きの2段組 / `list` 行頭アイコン付き箇条書き / `table` 表（数値列は右揃え、長い表は見出し行を繰り返して分割） / `code` コード

## 3. 既存の PPTX を整えるだけのとき（微調整機能）
人が作ったデッキにもそのまま使える。文字には触れない。
```bash
python3 $S/polish.py 既存.pptx -o 既存_整形.pptx --report polish.json            # 全部
python3 $S/polish.py 既存.pptx -o out.pptx --only indent,icons --icon-color 0E6464  # 一部だけ
python3 $S/check_design.py out.pptx                                                # 前後で比べる
```
| 機能 | 中身 |
|---|---|
| sanitize | 段落途中に紛れた `<a:pPr>` を除く（箇条書き記号が消える原因） |
| indent | 階層ごとに 左余白 = 0.30in + 階層×0.35in、ぶら下げ 0.30in に統一。記号を ● – ・ に、色を主色・85% に統一 |
| grid | 位置・大きさを 0.05in 格子へ |
| align | 0.12in 以内でずれた左端・上端（同じ高さの図形どうし）を揃える。同じ大きさのカード3枚以上は間隔を均等化 |
| title | タイトルの位置と大きさを最頻値に揃える（名前が無ければ上部で一番大きい文字をタイトルとみなす） |
| icons | 役割ごとに大きさを統一（丸付き＝丸の直径ごと、丸なし＝近い大きさどうし）、丸の中心へ、行頭アイコンは右の文字の1行目の中心へ。`--icon-color` で線の色も統一 |
| table | セル余白を統一、数値列を右揃え、見出し行を太字 |
既存デッキの文字が変わっていないことを示したいときは、整形前後を `markitdown` で書き出して `diff` する（差分ゼロ）。

## 4. 会社独自デザインルール（brand YAML）
会社のガイドライン（色・フォント・ロゴ・アイコン・写真の扱い）を YAML 1つにまとめ、新規デッキにも既存デッキにも当てる。
ひな形は `assets/brand_rules.template.yaml`（全項目に説明つき）。書いてない項目はひな形の値になる。
```bash
cp $S/../assets/brand_rules.template.yaml 会社ルール.yaml   # 色・ロゴのパスなどを書き換える
python3 $S/brand.py check 会社ルール.yaml                   # ルール自体の点検（WCAG・差し色の目立ち・系列色の近さ・ロゴの有無）
BRAND=会社ルール.yaml bash $S/make_deck.sh 要件書.md client training 提案資料   # 新規：色・フォント・余白・記号・ロゴ枠を最初から反映
python3 $S/brand.py apply 会社ルール.yaml 既存.pptx -o 既存_社内ルール.pptx      # 既存：画像と色を合わせる
python3 $S/brand.py audit 会社ルール.yaml 既存_社内ルール.pptx                  # 違反の一覧（直さない）
```
| apply の項目 | 中身 |
|---|---|
| colors | ガイドライン外の色を許可色へ。plan.json があれば役割どうし（主色→主色）、無ければ CIEDE2000 で一番近い色。文字の色は下地とのコントラストを満たす色を優先。`max_delta_e` より遠い色は残して報告、使用禁止色は必ず置き換え |
| fonts | 使用禁止・指定外のフォント名 → head（タイトル）/ body / mono |
| icons | アイコンの線の色・丸の色・役割ごとの直径（title/row/card/cover）。濃い地では丸を白抜きに |
| images | 写真・図：許可された縦横比へ（上端と幅を保つ、中央トリミング、元画像は保持）、角丸、枠線、色の処理 tint / duotone / grayscale（1回だけ） |
| logo | 指定位置へ配置。濃い地は白抜きロゴ。余白（clear space）に入る文字枠は幅を縮め、ページ番号などは横へよける |
| theme | PowerPoint のテーマ色も会社の色に（後から PowerPoint で色を選ぶ人のため） |

audit が見るもの：使用禁止色・許可外の色・指定外フォント・ロゴの有無と余白・アイコン直径・写真の縦横比・実効解像度（min_dpi）・1枚の写真の枚数。
解像度不足は機械では直せない（元画像を差し替えてもらう）。納品時に該当スライドを伝える。
apply の後も必ず `verify_text.py`（文字は変わっていない）と `check_design.py`（コントラスト）を流す。

## 5. 納品のときに書くこと（短く）
- persona × purpose と、その選び方の理由を1〜2文（`plan.json` の `profile.why` を元に）
- `verify` の結果（例：原文 32 ブロック・一致 32・追加 0・抜け 0）と `design` の結果
- 原文の誤字や表記ゆれに気づいたら「スライドは原文どおり」と添えて場所を伝える（直さない）
- 使用フォント（BIZ UDPゴシック）が相手の環境に無い可能性

## 6. カスタマイズ
- **会社の色・ロゴ・写真の扱い**：§4 の brand YAML（profiles.json は触らなくてよい）
- **ペルソナ追加**：`assets/profiles.json` の personas に足す → `python3 $S/check_design.py --palettes` が全組み合わせを WCAG で判定（NG のまま使わない）
- **アイコンの語**：`assets/icon_keywords.json`。Lucide（`react-icons/lu`）だけを使い、線の様式を揃える。名前は `node -e "console.log(!!require('react-icons/lu').LuXxx)"` で存在確認
- **グリッド・インデント幅**：`profiles.json` の `grid`

## 依存
pptxgenjs, react, react-dom, react-icons, sharp（node） / python-pptx, lxml, Pillow, PyYAML（python） / LibreOffice と pdftoppm（画像化QA）。pptx スキルの `apply_theme.js` があればテーマ色も書き込む。
